People and Environment in Our Supply Chain

2024 ANNUAL PROGRESS REPORT

## 'We think that the best products in the world ought to be the best products for the world.'

Tim Cook  |  CEO

2

## A letter from Sabih Khan

At Apple, our teams are constantly innovating to create the best technology. And a crucial part of that is creating the best supply chain we possibly can - working with companies around the world, and keeping people and the planet at the center of everything we do.

This work is built on more than 15 years of expertise, as we collaborate across our company and beyond our doors. Together, we innovate to protect our environment, reduce emissions, and improve stewardship of natural resources at every stage. We work with leading independent experts to uphold the highest labor and human rights standards, so that the people who help build Apple products have a safe, healthy work environment where their rights are respected and their voices are heard. And we go even further to drive opportunity and invest in their success.

A great example is our Supplier Employee Development Fund, which we launched two years ago. Every day since, teams at Apple have worked to grow its impact. We've created more ways for people, throughout our supply chain, to learn valuable new skills, understand their rights, and prepare for the jobs of tomorrow. That includes more than 4.6 million education and training sessions on workplace rights, coding, robotics, leadership development, and much more - bringing the total number of people impacted to more than seven million since we launched our first education programs in 2008.

Alongside this work, we've continued to create more channels for people throughout our supply chain to share feedback and shape their work environment. Our teams engaged with more than 1.4 million people about their workplace experiences in 2023. Based on that feedback, we worked with our suppliers to make tangible improvements in areas like employee communication, facility upgrades, food-service options, transportation, and more. But that's not the only way we ensure our high standards are met.

Our Supplier Code of Conduct sets leading standards requiring everything from safe and respectful workplace conditions, to rigorous environmental protections. We are constantly working to ensure these standards are met, holding our suppliers accountable and addressing issues quickly and comprehensively. This is an area where we will not compromise - and every day, our teams work diligently to help build a supply chain that reflects our values.

We continue to drive progress in our work to build a better future for people and the planet. Apple 2030 is our plan to be carbon neutral across our entire footprint by the end of the decade, and a crucial part of that work is the energy our suppliers use to make our products.

Today, more than 320 of our suppliers have committed to transitioning to 100% renewable energy for their Apple production. Our suppliers have saved 76 billion gallons of freshwater, and eliminated three million metric tons of waste from manufacturing. We've made progress toward our goal to one day make our products using only recycled and renewable materials - which now make up 22% of our products. And we continue to require our suppliers to responsibly source all the materials - recycled or otherwise - that go into our products.

The progress we've made represents the teamwork, commitment, and innovation of teams across Apple and our supply chain partners around the world. Together, we've made extraordinary progress, but there will always be more to do. That's why we are determined to continue raising the bar - driving improvements for people and the environment throughout our supply chain.

## - Sabih Khan

Sabih leads Appleʼs global supply chain, which includes Environment and Supply Chain Innovation.

<!-- image -->

## Table of contents

## 2023 in review

2023: By the numbers  ခ

## The Apple Supplier Employee Development Fund  ခ

Protecting the planet we all share  ခ

<!-- image -->

1

## How we build products

- ⦁ The Apple supply chain
- ⦁ Apple values
- ⦁ The highest standards. Applied everywhere.
- ⦁ Working in partnership

<!-- image -->

4

## How we're moving toward a circular supply chain

- ⦁ Innovating toward recycled and renewable materials
- ⦁ Responsible sourcing of materials
- ⦁ Addressing challenges through collaboration

2

## How we support people in our supply chain

- ⦁ Responsible labor recruitment
- ⦁ Worker voice and workplace rights training
- ⦁ Supporting fair wages and working hours
- ⦁ Health and safety
- ⦁ Education and development
- ⦁ Supporting communities

<!-- image -->

5

## How we're creating change through shared action

- ⦁ Sharing tools and resources to drive progress
- ⦁ Partnerships

<!-- image -->

3

## How we work with suppliers

- ⦁ Responsible procurement
- ⦁ Supplier assessments
- ⦁ Capability building
- ⦁ Supplier accountability

<!-- image -->

6

## Additional resources

- ⦁ Reports and filings
- ⦁ How we prevent forced labor in our supply chain
- ⦁ Understanding assessment results
- ⦁ Endnotes

## 2023 in review

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Apple Watch assembly, Vietnam; HomePod assembly, Vietnam; iMac assembly, Ireland; Mac Pro assembly, United States; iPhone assembly,

CLOCKWISE FROM TOP LEFT: China mainland

## 2023: By the numbers

<!-- image -->

## Labor and human rights

## 28M+

supplier employees trained on their workplace rights since 2008, with more than two million trained in 2023

## 1.4M+

supplier employees engaged on their workplace experience in 2023, including more than 516,000 people surveyed, over 65,000 people interviewed as part of supplier assessments, and more than 830,000 people reached as part of grievance channel awareness campaigns

## /dollarsign34.5M+

in recruitment fees paid back by suppliers to more than 37,700 employees since 2008 due to Apple's zero fees policy

## 1.1M+

supplier employees covered by the Apple Responsible Labor Recruitment Due Diligence Toolkit training

## 1.4M+

supplier employees' working hours reviewed weekly to verify compliance with our standards

## 90+

human rights and environmental defenders and organizations supported by Apple, reaching millions of people around the world

## 0

instances found where people were forced to work in our supply chain in 2023

<!-- image -->

## Environment

## 320+

suppliers committed to transitioning to 100% renewable energy for Apple production to date, representing over 16 gigawatts of renewable energy operational in the Apple supply chain

## 22%

of product mass shipped in 2023 composed of recycled and renewable materials 1

## 76B+

gallons of freshwater saved by suppliers through our Clean Water program since 2013, with participants saving more than 12 billion gallons in 2023 and achieving a 42% reuse rate 2

## 185+

supplier facilities Zero Waste-assured by UL Solutions, with more than 350 supplier facilities participating in our zero waste program across 13 countries and regions 3

<!-- image -->

## Health, safety, and education

## 4.5M+

supplier employees reached by our health and wellness education programs since 2017

## 7M+

supplier employees who have participated in technical training, professional development, and enrichment courses since 2008

## 25K+

participants in Apple's automation technician training program to date, with 17,000 participants in 2023

## 45K+

participants in Apple's Swift coding program since 2017; five apps developed and launched by supplier employees on the App Store in 2023

<!-- image -->

## Supplier performance

## 893

independent, third-party assessments focused on the requirements of our Supplier Code of Conduct (Code) and 251 smelter, refiner, and materials manufacturer assessments conducted in the 2023 reporting period 4

## 50+

countries and regions where assessments were conducted

## 100%

of smelters and refiners of cobalt and lithium - key materials contained in batteries - assessed through third-party audits in calendar year 2023, marking eight consecutive years of 100% participation for cobalt and four for lithium

## 100%

of tin, tantalum, tungsten, and gold (3TG) smelters and refiners participated in third-party assessments for 9 consecutive years

## 11%

of prospective suppliers evaluated for their ability to meet our Code prevented from entering our supply chain since 2020

## 25

manufacturing supplier facilities and 231 smelters, refiners, and manufacturers of materials removed from our supply chain for failing to meet our standards since 2009

2023

|

2023: By the numbers

7 7

Apple Watch assembly, Vietnam

## The Apple Supplier Employee Development Fund

At Apple, people are at the center of everything we do and every decision we make. Our number one priority is providing a safe and healthy workplace where people are treated with respect and dignity. This means making sure supplier employees know their rights and how to speak up if they aren't being respected, as well as providing them with opportunities to accelerate their personal and professional growth.

Education is a powerful equalizing force and an Apple value, and our commitment to it extends throughout our supply chain. We provide supplier employees with learning and development opportunities that increase their awareness of workplace rights, amplify their voices, and build the skills needed for the jobs of today and tomorrow.

In 2022, we announced a /dollarsign50 million Supplier Employee Development Fund (SEDF) to expand on 15 years of labor and human rights, education, and skill-building programs for people across our supply chain and in surrounding communities. SEDF includes new and expanded partnerships with leading workplace rights advocates, universities, and nonprofits to empower and educate supplier employees around the world. We're continuing to scale the impact of SEDF as part of our ongoing work to put people first, broadening the reach of its programs and tools to more employees in more countries and regions.

To learn more about our progress across SEDF programs, refer to the sections of this report that cover responsible labor recruitment on page 20 , worker voice and workplace rights training on page 22 , health and safety on page 25 , and education and development on page 28 .

<!-- image -->

committed by Apple to expand programs designed to improve workplace experiences and educational opportunities for people in our supply chain

## /dollarsign 50M

<!-- image -->

SEDF education and training sessions delivered since launch

4.6M+

2023

|

2023: By the numbers

9 9

## Protecting the planet we all share

Environmental rights are human rights. At Apple, we're acting with urgency to protect our planet's resources and be a leader in the fight against climate change. Across our work, we're also committed to being a force for equity, taking action to empower communities that have been disproportionately impacted by climate change.

## Apple 2030

Apple's worldwide corporate operations have been carbon neutral since 2020, and we've committed to being carbon neutral across our supply chain and the lifecycle of each of our products by 2030.

Our journey to Apple 2030 starts with our goal to first reduce our scope 1, 2, and 3 emissions by 75 percent compared with 2015 and then invest in high-quality carbon removal solutions for the remaining emissions. 5 We're already well on our way, having reduced emissions by over 50 percent since 2015, even as our business has grown.

We also continue to increase our use of recycled and renewable materials, which are typically less carbon-intensive than their primary alternatives. This helps us achieve progress toward our 2030 carbon neutrality goal, as well as our goal to one day make all of our products using only recycled and renewable materials.

## Environmental stewardship in the supply chain

As we build products that enrich the lives of people around the world, we also want to minimize their environmental impact while safeguarding the local environments where we and our suppliers operate. That's why our environmental strategy covers the stages of the product lifecycle across our supply chain.

Our manufacturing supply chain accounted for 59 percent of our gross carbon footprint in 2023, and 99 percent of our water use. We work with our suppliers to take steps to reduce their environmental impact while also becoming better stewards of the resources we share. Our suppliers are required to address the management of regulated substances, stormwater, wastewater, air emissions, and waste, as well as pollution prevention, resource use, and environmental permits. We support our suppliers in meeting these requirements through dedicated programs, tools, and resources.

## Supply chain decarbonization

Reaching our carbon neutrality goal means we must significantly reduce emissions across our manufacturing processes, from material processing, to component manufacturing, to final product assembly. T o make this happen, we're driving energy efficiency initiatives and transitioning our entire supply chain to 100 percent renewable energy, because electricity usage makes up the majority of our supply chain's carbon footprint.

We're addressing supplier emissions through targeted programs that have evolved with our goals and strategy, such as our Supplier Clean Energy Program and Supplier Energy Efficiency Program, which focus on decarbonizing electricity usage at our supplier sites and making them as energy-efficient as possible.

In October 2022, we shared the expectation with the executives of our major manufacturing and logistics partners that their companies decarbonize their entire Apple footprint by 2030, including all their scope 1 and 2 emissions associated with Apple production. And last year, we updated our Supplier Code of Conduct to require suppliers to transition to renewable energy in the manufacturing of Apple products. So far, more than 320 global suppliers, making up 95 percent of our direct manufacturing spend, have committed to using 100 percent renewable electricity for all of their Apple production by the end of this decade.

## Circularity and recycling

We aim to create products that make greater use of circular supply chains by sourcing recycled and renewable materials, designing long-lasting and durable products, and developing recycling innovations to improve how we recover materials at the end of a product's useful life. Circularity helps unlock the potential of the materials in our products so that they can be used again and again, making the best use of finite resources and enabling us to design and build the next generation of devices to be even better for people and the planet.

In 2023, we accelerated progress toward our ambition to build products using 100 percent recycled and renewable materials by announcing that by 2025, we plan to use 100 percent recycled cobalt in all Apple-designed batteries, 6 100 percent recycled rare earth elements in magnets in Apple devices, 7 and 100 percent recycled tin soldering and gold plating in all Apple-designed printed circuit boards. 8

Innovation is central to realizing the potential of recycling - not just for Apple products but throughout our industry. Austin, Texas is home to our Material Recovery Lab (MRL), which develops new recycling technologies and processes that maximize the recovery of key materials during recycling. The techniques developed at the MRL are intended to be used at scale in our partners' recycling and material processing centers around the world. We also operate an asset recovery center in Santa Clara Valley, California and work with best-in-class recyclers capable of recovering materials at high rates with the best environmental and safety performance.

## Zero waste

Apple is committed to eliminating waste at every stage of the product lifecycle, from the time a product is designed and manufactured to the time it's ultimately recycled. Through our Zero Waste program, our suppliers are required to implement a plan for identifying waste, develop a method for quantifying and monitoring their landfill diversion rate, set waste reduction goals, and maintain progress toward sending zero waste to landfill.

We also provide support for our suppliers in verifying their zero waste efforts, including through UL (Underwriters Laboratories), a leading industry certification body that requires at least 90 percent diversion of waste through methods other than waste-to-energy. To date, more than 185 of our supplier facilities are Zero Waste-assured by UL Solutions, including all final assembly sites for major Apple products. Achieving this level of performance across our supply chain requires innovative new materials and recycling strategies to address the infrastructure and technology challenges we face with waste reduction today.

## Water

Access to clean, safe water is a basic human right. Our supply chain accounts for 99 percent of Apple's total water footprint, and we have a responsibility and an opportunity to engage our suppliers to protect and preserve this critical resource for future generations.

Our industry-leading Clean Water program helps our suppliers become stewards of the water resources where they operate by conserving water, promoting water reuse, and preventing water pollution within our supply chain.

We also work to understand local water needs through our partnership with the Alliance for Water Stewardship (AWS), the leading water stewardship organization creating collaboration among businesses, non-governmental organizations (NGOs), and the public sector to improve the sustainability of local water resources. As a member of AWS, we're committed to the adoption and promotion of the AWS Standard, the first global framework for measuring responsible water stewardship across social, cultural, environmental, and economic criteria. Together with AWS, we're providing our suppliers and the broader industry with the tools and resources needed to address water use more holistically, creating positive impact across supplier facilities and the water basins where they operate.

## Smarter chemistry

The safety of the people in our supply chain, our customers, and the planet is our top priority, which is why we help our suppliers select safer chemicals to use in our products and manufacturing processes. Our industry-leading work to prioritize the use of safer alternative chemicals at supplier facilities helps protect the health and safety of people across our supply chain. It also supports a circular supply chain by both minimizing the recirculation of potentially harmful substances and enabling higher rates of recycling and material recovery to extend the useful life of our products.

Our approach to environmental stewardship takes into consideration our entire business, including our corporate operations and supply chain. In addition to this brief summary of our supply chain environmental

Protecting the planet we all share programs, a comprehensive review of Apple's broader environmental strategy and progress can be found in our 2024 Environmental Progress Report and our Environment website .

<!-- image -->

## Apple Racial Equity and Justice Initiative Impact Accelerator

Low-income and historically marginalized communities too often bear the brunt of the effects of climate change. Through the Impact Accelerator, we extend access to opportunities for communities of color as we continue our strategic work and investments in environmental sectors such as renewable energy, carbon removal, recycling innovation, and smarter chemistry.

Part of our Racial Equity and Justice Initiative (REJI), the Apple Impact Accelerator is a threemonth program designed to accelerate the progress of participating Black-, Hispanic/ Latinx-, and Indigenous-owned businesses that share our commitment to the environment. Offering customized training and access to Apple experts, the Impact Accelerator supports businesses that have the potential to drive innovation and positive outcomes in our supply chain - so that together, we can work to support communities disproportionately impacted by environmental issues.

After completion, alumni receive ongoing professional support, including access to Apple experts and invitations to networking events through Apple's Supplier Success community. Alumni companies can also be considered for future business opportunities with Apple.

<!-- image -->

2023

|

Protecting the planet we all share Supplier solar array installation, Switzerland

## How we build products

The Apple supply chain ခ

Apple values ခ

The highest standards. Applied everywhere. ခ

Working in partnership ခ

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## The Apple supply chain

We believe business can and should be a force for good. That's why we put people first at every step of our supply chain, from designing and building our products to delivering and recycling them.

We design our products in California and work with a global network of suppliers to bring them to life. Our supply chain spans more than 50 countries and regions, with millions of people and thousands of innovative businesses around the world working together to build the best products and services.

Everything that goes into designing, building, delivering, supporting, and recycling Apple products is part of our global supply chain, including the companies that provide raw materials to our suppliers, our manufacturing and recycling partners, and the companies that support our logistics, services, and retail operations.

As Apple's business continues to grow and expand to new areas, so does our responsibility to people and the planet. In recent years, we've expanded our engagement to suppliers supporting newer areas of our business, including those that work with our content services, such as Apple TV+ and Apple Fitness+.

<!-- image -->

## Apple values

## Apple's more than 150,000 employees are dedicated to making the best products on earth and leaving the world better than we found it.

We lead with our values. This means putting people at the center of everything we do, by empowering them with accessible technology, being a force for equity and opportunity, creating an inclusive and diverse work environment, and respecting the human rights of everyone whose lives we reach, including the people who make our products and the communities where our suppliers operate.

We embed our values in every decision we make, including the suppliers we choose to work with, the materials we select for our products, and the processes and equipment we use to make them. We hold ourselves and our suppliers to the same high standards of labor and human rights, health and safety, environmental protection, ethics, and management systems - and those high standards apply everywhere our suppliers operate.

By upholding our values everywhere our business reaches and sharing our tools and the lessons we've learned with others to empower them do the same, we're accelerating progress across industries and around the world.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Racial Equity and Justice

Supply Chain Innovation

Inclusion and Diversity

Accessibility

Education

Privacy

Environment

## The highest standards. Applied everywhere.

Our ongoing work to care for people and the planet across our supply chain starts with setting and upholding the highest standards for labor and human rights, health and safety, the environment, management systems, and ethics. Our standards apply globally, regardless of where people live or work or which job they do.

We work closely with experts across Apple to rigorously evaluate and update our requirements every year to reflect emerging risks, legal requirements, and industry best practices. We also engage with supplier employees, civil society organizations, academic experts, and program partners to ensure our requirements reflect the needs of the people working across our supply chain and the most current and robust international labor and human rights, health and safety, and environmental standards.

We regularly communicate our policies and requirements to Apple employees, people across our supply chain, and business partners so that everyone who works with us is aware of our expectations and how seriously we take them.

## Apple Human Rights Policy

Apple's Human Rights Policy outlines how we treat everyone, including our customers, employees, suppliers, and people across every level of our supply chain. Our Human Rights Policy establishes our commitment and approach to respecting internationally recognized human rights in our business and supply chain, based on the United Nations Guiding Principles on Business and Human Rights (UNGPs).

[To learn more, refer to our United Nations Guiding Principles on Business and Human Rights: 2024 Mapping of the Apple Supply Chain .](http://www.supplychainreports.apple/Apple-UNGP-Mapping)

## Apple Supplier Code of Conduct and Supplier Responsibility Standards

The Apple Supplier Code of Conduct (Code) and Supplier Responsibility Standards (Standards) outline our strict requirements for our suppliers. First released in 2005, our Code and Standards are published on our website and communicated to our suppliers in 18 languages on SupplierCare, our supplier communication platform.

Together, the Code and Standards outline Apple's labor and human rights, health and safety, environment, ethics, and management systems requirements for our suppliers, including those related to anti-discrimination and abuse, prevention of forced and underage labor, working hours management, wages, benefits, contracts, compliance with all laws regarding freedom of association and collective bargaining, and the responsible sourcing of materials.

All of our suppliers must both abide by our policies and applicable laws and apply them to their own supply chains, no matter where they operate or what type of goods, services, or labor they provide to Apple.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## Working in partnership

Creating meaningful impact for people, the environment, and communities around the world requires collaborating with others to design, scale, and share sustainable solutions for some of our most complex challenges. Our aim is always to be the ripple in the pond that creates broader change, which means the progress we make can't stop at our own supply chain.

We're proud to partner with industry associations, civil society organizations, and multistakeholder initiatives around the world to promote best practices, listen and learn from others' perspectives and experiences, and scale innovative solutions helping everyone achieve lasting progress more quickly.

.

Learn more about our partnerships on page 53

<!-- image -->

## How we support people in our supply chain

Responsible labor recruitment ခ

Worker voice and workplace rights training ခ

Supporting fair wages and working hours ခ

Health and safety ခ

Education and development ခ

Supporting communities ခ

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| How we support people in our supply chain

## How we support people in our supply chain

The work that happens across our supply chain is only possible due to the millions of talented and dedicated people all over the world who are part of it.

Our work to support the people in our supply chain begins before we start building products. We directly engage with our suppliers and their employees on an ongoing basis so people feel safe on the job, are aware of their rights and how to speak up if they're not being respected, and have opportunities to learn and grow. By listening carefully to people across our supply chain and putting them at the center of the decisions we make, we're able to continuously pursue new opportunities - big and small - to improve the workplace experience.

<!-- image -->

<!-- image -->

CLOCKWISE FROM TOP LEFT: Recycling, United States; component manufacturing, Switzerland; iPad assembly, Vietnam; recycling, Singapore

<!-- image -->

<!-- image -->

## Responsible labor recruitment

## Our work to create safe, healthy, and respectful workplaces for the people in our supply chain starts long before we select a supplier.

Our Supplier Code of Conduct (Code) and Supplier Responsibility Standards (Standards) and the protections they provide apply equally to all workers, regardless of a person's job, their geographic location, or how they were hired. We require our suppliers' labor recruitment processes to be free and fair, and if we have reason to believe that any unethical recruitment practice has taken place, we take action.

## Mapping labor recruitment in our supply chain

The foundation of our responsible labor recruitment strategy is an understanding of our supply chain - not just our suppliers but also the third-party labor agencies they use to hire people. We've been leaders in creating new standards, tools, and practices to identify our suppliers' labor agencies, continually building upon and expanding our mapping efforts. Since 2019, we've mapped more than 2,100 labor agencies supporting more than 1,400 supplier facilities in 40 countries and regions.

## Tools and capability building

In order for the workplace to be a respectful, supportive environment, everyone who plays a part in the labor recruitment process must be knowledgeable about and accountable for protecting labor and human rights.

The Apple Responsible Labor Recruitment Due Diligence Toolkit (Recruitment Toolkit), developed in partnership with the International Organization for Migration (IOM), the United Nations (UN) agency focused on promoting safe, humane, and orderly migration, provides suppliers and their labor agencies with easy-to-use tools that help them perform the due diligence and record keeping necessary to hire people fairly and ethically, mitigating forced labor risks from the start of the employment journey.

Each year, we deliver training sessions on the Recruitment Toolkit that are customized to the specific needs of individual suppliers and their labor agencies. In 2023, we delivered Recruitment Toolkit training sessions in six languages across 16 countries and regions, reaching companies representing more than 1.1 million supplier employees globally. This effort helps confirm that as people are hired, all of our requirements for responsible labor recruitment are being met.

We're proud of our leading responsible labor recruitment program and the progress we've made in our own supply chain through the use of the Recruitment Toolkit. We want to share the best practices we've honed over many years to help everyone achieve progress more rapidly - including companies beyond the electronics manufacturing industry. This includes partnering with leading global organizations to scale our Recruitment T oolkit internationally.

Last year, we helped IOM scale its toolkit to other industries and stakeholder groups around the world. This included pilots in Saudi Arabia and Canada, where employers or government agencies were trained on how to use IOM's toolkit.

## No recruitment fees

We believe that no one should have to pay for the opportunity to work. We've been leaders in establishing policies that prohibit suppliers and their labor agencies from charging workers fees connected to their recruitment or employment - even if charging such fees is legal in the supplier's operating country or the worker's home country.

If we discover that any worker has paid recruitment fees to an Apple supplier or labor agency at any point during their employment journey, we require our suppliers to promptly repay them. We then verify full and timely repayment through an independent, third-party auditor. Since 2008, /dollarsign34.5 million in recruitment fees have been repaid to over 37,700 workers by our suppliers. In 2023, /dollarsign263,870 in recruitment fees were repaid to 53 workers.

## Supporting Foreign Contract Workers throughout their recruitment journey

Foreign Contract Workers are people who travel between countries to work. While they make up only approximately one percent of the people in our supply chain, they face a higher risk of being charged fees in the process of securing a job, which we do not allow.

Our work to ensure free and fair recruitment processes across our supply chain begins well before a Foreign Contract Worker arrives at a supplier facility. It involves driving awareness of responsible recruitment practices and workplace rights, monitoring and assessing both direct suppliers and third-party labor agencies, and holding suppliers accountable when we do find issues.

<!-- image -->

## Worker voice and workplace rights training

People deserve to be treated with dignity and to know their rights. They must be able to speak up if those rights are not being respected - and know that if they do, we'll listen and act. We're committed to amplifying the voices of people at each level of our supply chain and using what we learn to support our suppliers in strengthening their operations and providing the best possible experience for their employees.

## Training supplier employees on their rights

The respect and safeguarding of worker rights starts with awareness and training. When people are trained on their rights, worker satisfaction improves, and workplace issues can be identified earlier and resolved faster.

Our Code and Standards require our suppliers to train their employees on their workplace rights. The training is generally conducted during new employee orientation and covers international labor standards; local labor laws; environment, health, and safety (EHS) standards; and the protections required by our Code and Standards.

We invest in new tools and technologies to help our suppliers more effectively train their employees on their rights. This includes working with educational technology platforms to deliver digital rights awareness trainings to supplier employees via their mobile devices. These platforms provide real-time feedback that we use to address potential issues and areas of knowledge that need additional reinforcement. We adjust content as needed to make sure the trainings continue to increase people's knowledge of and confidence in exercising their workplace rights.

Since 2008, over 28 million supplier employees have been trained on their workplace rights. In 2023 alone, suppliers trained over 2 million workers at more than 200 sites in 12 countries and regions and in 27 languages on their workplace rights.

## Listening to supplier employees

Effective supplier employee feedback and ongoing employee-management communication are essential to respecting worker rights and maintaining safe and healthy workplaces. We're committed to listening to and amplifying the voices of the people in our supply chain, and we take action to address their feedback.

We learn from supplier employees about their workplace experience through the feedback channels we make publicly available as well as the anonymous surveys and in-depth interviews we conduct during supplier assessments. These open channels of communication help us proactively identify potential issues and opportunities for workplace improvement.

<!-- image -->

## Supplier employee interviews

Each year, the independent, third-party auditing firms we work with to conduct supplier assessments interview tens of thousands of supplier employees in their local languages - and without their managers or cameras present - to determine whether their experiences on the job align with our observations during assessments. Interview participation is completely voluntary, and we keep responses confidential. In 2023, we interviewed over 65,000 people as part of supplier assessments.

## Learn more about supplier assessments on page 38 .

All interviewees are provided with information on how to reach us afterward with any concerns, and those who are willing to be contacted receive a follow-up phone call to make sure they didn't experience retaliation as a result of their participation. Last year, more than 35,000 of these follow-up calls were made.

## Surveys

We also use anonymous surveys to understand supplier employee workplace satisfaction. In 2023, we anonymously surveyed more than 516,000 employees at over 300 supplier facilities across Brazil, Canada, China mainland, Colombia, India, Indonesia, Italy, Japan, Malaysia, Mexico, Nicaragua, the Philippines, Poland, Portugal, Singapore, South Korea, Spain, T aiwan, Thailand, the United Kingdom (UK), the United States (U.S.), and Vietnam about their workplace experience - over 12 percent more people than we surveyed in 2022.

Using survey responses, we work with our suppliers to develop plans to address employee needs and concerns. In 2023, more than 7,100 actions were taken, including expanding transportation options, improving food-service offerings, and increasing the speed and efficiency of other workplace services.

## Grievance hotlines

In addition to requiring suppliers to provide grievance channels for their employees - and helping make those channels more efficient and effective - we also provide ways for people to reach out to Apple directly, anonymously, and in any language to raise concerns about potential issues in our supply chain.

In 2023, we continued an ongoing awareness campaign to promote our grievance hotlines, reaching more than 830,000 supplier employees at 35 key supplier sites through methods such as flyers, posters, and video messages. Last year, we received more than 30 calls from supplier employees who reported issues such as unsatisfactory living conditions and delayed payment of signing bonuses by labor agencies. These issues were quickly addressed and resolved with supplier management.

## Worker voice dashboard

In 2023, we introduced a centralized worker voice dashboard to collect, monitor, and analyze worker sentiment from internal and external channels. This gives teams across Apple more visibility into the supply chain workplace experience, allowing us to spot trends in feedback more effectively and identify and respond to potential issues before they escalate. The worker voice dashboard also drives more informed decision-making when it comes to implementing capability-building programs and providing remedy to workers who may have been impacted by a supplier's violation of our Code.

More than 400 opportunities for improvement were identified and successfully addressed through the worker voice dashboard in 2023, on topics including maintenance for employee dormitories, dining experiences, employee communication, and payment and bonus discrepancies.

## Advancing employee-management communication

We work with our suppliers to improve employeemanagement communication, especially for smaller or newer supplier facilities that are still working to develop their infrastructure. Our ongoing partnership with the Sustaining Competitive and Responsible Enterprises (SCORE) Academy, an International Labour Organization (ILO) licensed service provider, engages supplier employees directly in decision-making and facilitates greater dialogue and problem-solving among employees and their managers.

Launched at supplier facilities in China mainland in 2021, SCORE Academy allows supplier management to collaborate with employees and their recognized representatives on solutions for workplace issues, including those related to health and safety, productivity, and harassment prevention.

<!-- image -->

supplier employees engaged on their workplace experience, including more than 516,000 people surveyed, over 65,000 people interviewed as part of supplier assessments, and more than 830,000 people reached as part of grievance channel awareness campaigns

<!-- image -->

## The worker voice dashboard in action

Last year, the worker voice dashboard highlighted an influx of social media posts about a facility that had required employees to take unpaid leave as a result of changes in production schedules. Workers also reported this issue through our third-party grievance hotlines.

We quickly investigated the employees' concerns and confirmed the violation of our standards, which was the result of a misinterpretation of leave policy requirements. The supplier immediately corrected the issue to ensure employees' next paychecks wouldn't be impacted. The supplier was also required to review, update, and retrain management on its policies to ensure compliance with both legal and Apple requirements. We conducted onsite investigations and employee interviews to verify that the issue had been addressed, remedy was provided to impacted employees, and the required steps had been taken to prevent a reoccurrence of the violation.

## Supporting fair wages and working hours

Time for rest and relaxation is important for physical and mental health and well-being. Our Code and Standards restrict workweeks for supplier employees to 60 hours (including overtime) and require at least one day off every seven days. Any exceptions to this policy, while rare, require prior authorization from Apple management. All overtime must be voluntary and paid at a premium rate, in line with applicable laws and regulations.

These requirements are a key focus of our supplier assessments, which include extensive reviews of employee records, payroll information, contracts, and data on working hours. We also require suppliers to report data on employee working hours throughout the year, with priority suppliers reporting on a weekly basis. In 2023, we received weekly data on working hours for an average of 1.4 million people across more than 380 supplier facilities, with reporting suppliers maintaining compliance with our standards across more than 96 percent of workweeks in 2023.

.

Learn more about supplier assessments on page 38

## Living wage

'Living Wage' is an important topic in our industry, and many others. In 2023, we undertook an exercise to more deeply understand wages in our supply chain above and beyond our Code requirements, which already mandate that all wages must meet local legal requirements and be paid on time. Understanding wage distribution is a critical part of our commitment to upholding peoples' right to be treated with dignity and respect. We're working with teams across Apple and external partners including the Responsible Business Alliance (RBA), ILO, and the Fair Wage Network to collect and map wage data in key countries and regions across our supply chain. We are using this data to inform the global conversation on a universally agreed upon definition and calculation methodology, while identifying the tools, resources, and support we need to develop for our suppliers to make the most impact for workers around the world.

<!-- image -->

<!-- image -->

## Health and safety

The health and safety of the people in our supply chain comes first - now and always. Our Code and Standards include extensive requirements for the safe handling of chemicals, fire safety, indoor air quality, emergency preparedness, health and safety permits, living and working conditions, and incident management.

We regularly review and communicate these requirements to our suppliers, as well as those laid out in additional policies and standards, such as the Apple Regulated Substances Specification (RSS) , which outlines our requirements and restrictions on the use of certain chemicals in our products, packaging, and manufacturing processes.

As we evaluate prospective suppliers and develop new products, manufacturing techniques, and production processes, we review and update our health and safety standards as necessary. In 2023, we introduced a new requirement for our suppliers to establish a system for managing safety risks in machines used to design and build Apple products. We also revised our standard focused on employee dormitory and dining conditions, adding additional requirements to better manage health, safety, and sanitation in employee living spaces.

## Building a culture of safety

A workplace culture that values health and safety requires everyone to be knowledgeable about the necessary measures to keep them safe. That's why we provide our suppliers with tools and resources to support them in building and maintaining a culture that puts health and safety at the forefront every day.

In 2023, we launched a new Safety Culture Maturity Checklist Tool that was distributed to over 1,100 supplier sites, as well as piloted onsite consultations on safety culture at nine supplier sites in China mainland. These consultations resulted in more than 240 improvement actions, including improved signage, the establishment of 'safety dojos' (experiential training rooms), and at one facility, the launch of a new initiative for employees to suggest ways to improve workplace safety.

We also use our SupplierCare platform to provide suppliers with the latest in safety best practices and training resources to educate their teams on how to implement our strict standards. Our suppliers receive regular training from Apple experts on machine safety awareness, safe work procedures, workplace hazard awareness, and other workplace safety topics.

Learn more about capability building on page 42 .

## Machine safety

As we continue to drive innovation in our products, the machines used to build them must also advance, which is why we're always reviewing and strengthening our machine safety programs to help keep the people who operate manufacturing equipment safe on the job. We start at the earliest stages of product design, helping suppliers select and obtain safer equipment that conforms to our Machine Safety Standard.

Once machines are installed in supplier facilities, we keep suppliers up to date on our requirements and associated risks through dedicated training materials shared on SupplierCare. These trainings cover topics such as the use of safety devices, inspection basics, and hazards associated with moving parts. In 2023, we launched a new, enhanced version of our machine safety training to provide expanded guidance on the safe operation and maintenance of advanced manufacturing equipment. The training has been completed by over 760 supplier sites around the world.

Regular inspections of equipment and evaluations of safety procedures help us confirm that machines remain in safe working condition and the necessary safety protocols are in place and being followed. In 2023, we completed onsite safety inspections of over 2,600 machines at more than 100 key supplier sites around the world. After machinery is inspected, we offer recommendations for corrective measures and work with suppliers to develop action plans for any additional actions needed.

## Smarter chemistry

Chemicals are required for many of our products' manufacturing processes. Keeping workers and customers safe is a top priority for us, which is why we focus on identifying and selecting the safest materials for use in the manufacturing of our products and confirm that proper safety measures are in place to protect supplier employees, surrounding communities, and the planet from chemical hazards.

While we always prioritize eliminating unsafe materials and using preferred alternatives in our suppliers' facilities, in some cases, those materials aren't yet available. When safer alternatives don't yet exist or can't be procured, our suppliers turn to other safety measures, including isolating people from the hazard, changing the way they work, and protecting them with personal protective equipment (PPE).

## Driving industry change

As we strive to create change beyond our own supply chain, we work with others to help make the use of safer materials the industry norm. We collaborate with standardsetting bodies, trade associations, and non-governmental organizations (NGOs) to develop tools, standards, and mechanisms that drive the identification and adoption of safer chemicals. We then share our learnings and best practices - from the criteria we've set for chemicals to the tools we've developed for our own suppliers - to support industrywide change.

In 2023, we:

- ⦁ Concluded our third year of participation in the Clean Electronics Production Network's (CEPN) Toward Zero Exposure (TZE) program, a public platform for companies across the electronics industry to commit to and report on their efforts to eliminate workers' exposure to hazardous chemicals in manufacturing
- ⦁ Helped the RBA host training sessions to educate workers at thousands of companies on how to control exposure to hazardous chemicals at work
- ⦁ Worked with ChemFORWARD to launch ChemWorks, an open-access platform that helps accelerate the adoption of safer cleaners and degreasers by providing resources for formulators to screen and optimize their products with verified safer chemicals

For more information on smarter chemistry, refer to our 2024 Environmental Progress Report and Environment website .

## Our approach to smarter chemistry

<!-- image -->

## Upholding strict safety standards

We uphold strict chemical safety standards that often go beyond regulatory requirements in order to protect worker health and the environment. These requirements are outlined in our Code and Standards and RSS .

<!-- image -->

## Implementing safer alternatives

We use data from our suppliers to identify substances that carry increased risk and offer opportunities for replacement with safer alternatives.

## U.S. EPA Safer Choice Partner of the Year

In 2023, we were honored to receive a U.S. Environmental Protection Agency (EPA) Safer Choice Partner of the Year Award for the third time in four years, in recognition of our work to advance the use of safer cleaners and degreasers.

<!-- image -->

<!-- image -->

## Designing our products with safety in mind

We intentionally design our products and manufacturing processes to use safer materials, and we give our suppliers access to the information and resources they need to select preferred materials from the start.

<!-- image -->

## Mapping chemicals in our supply chain

We require our suppliers to share information about the chemicals used at their facilities to help us map the materials in our supply chain.

2

How we support people in our supply chain

|

Health and safety Apple Education Hub, China mainland

## Education and development

Education is a powerful equalizing force, and we're committed to providing opportunities for the people in our supply chain to learn and grow. We're proud to invest in the people working in our supply chain, creating opportunities for them to manage their health, become leaders, and build the skills needed for the jobs of today and tomorrow.

## The Apple Education Hub

In 2022, we launched the Apple Education Hub as part of our Supplier Employee Development Fund (SEDF), expanding on our long-standing supplier employee education programs that have been in operation since 2008. The Apple Education Hub builds on the momentum of existing initiatives, adds exciting new offerings, and provides a platform for people in our supply chain and their communities to learn the skills needed to focus on their health, well-being, and job advancement. Since its launch, supplier employees have participated in both in-person and virtual learning and development programs across a range of topics, including leadership development, coding, robotics, advanced manufacturing, and health and wellness.

As part of this commitment, we opened a physical home for the Apple Education Hub at Zhejiang University in China mainland, which offers a state-of-the-art learning lab where supplier employees can receive both hands-on and virtual educational experiences. This dedicated space also hosts workshops for curriculum development, trainings for the supplier teams responsible for training programs in their facilities, and forums on topics such as smart manufacturing for Apple suppliers and business partners.

## Expanding learning opportunities in the United States

In 2022, as part of the launch of the Apple Education Hub, we made a major investment in workforce development, including expanding the educational offerings available to supplier employees in the United States. Focusing on our diverse supplier base that spans industries such as manufacturing, services, recycling, and technical support, we've continued creating programs tailored to the needs of supplier employees across the country.

Our partnership with the Council for Adult and Experiential Learning (CAEL) - a U.S. nonprofit that supports the creation of education-to-career pathways to enable equitable economic mobility - has enabled our program expansion by connecting supplier employees to tailored educational opportunities, such as professional development, technical skills, and spoken and written English. Collaboration, combined with the introduction of new program curriculum, has led to double the number of suppliers participating in the program since last year.

In 2023, we launched our Lean Manufacturing Training program, available in English and Spanish, at key recycler facilities in the United States. Lean manufacturing is a management philosophy used to optimize efficiency and quality. We worked to adapt the lean manufacturing principles for recycling providers, helping participating suppliers improve their capabilities, proactively mitigate safety issues, and bolster their engagement in environmental stewardship practices.

We also offer English language training to all janitorial suppliers supporting our U.S. offices and Apple Store locations. This hybrid in-person and virtual training opportunity is job-specific, providing participants with skills directly relevant to their roles.

<!-- image -->

supplier employees offered access to education on topics such as nutrition, mental wellbeing, reproductive health, and early disease detection since 2017

## 4.5M+

## Health education

We're committed to cultivating a supply chain where people can thrive - inside and outside work. This means providing the people in our supply chain with the tools needed to focus on their physical and mental health. Since 2017, through new employee orientation sessions, Apple Education Hub programs, and other specialized training opportunities, we've helped make health education and resources available to more than 4.5 million people on topics such as nutrition, mental well-being, reproductive health, and early disease detection.

Our health education initiatives are tailored to meet the needs of local supplier employee populations, equipping them with important knowledge and skills to take control of their own health, which they can then share with their communities to multiply the impact.

We work with local partners around the world to evolve our health education programs based on supplier and employee needs and feedback. For example, last year we piloted new learning initiatives at supplier facilities in China mainland that covered health-related topics, aptly timed with cultural affinity moments such as International Women's Day and Mental Health Awareness Month.

## Mental health support

Mental well-being is a critical component of overall health. When mental health is a priority, workplace environments foster higher levels of employee satisfaction and retention. We work to provide our suppliers the resources they need to support their employees' mental health, including trainings, toolkits, and support from leading experts.

In 2022, we partnered with a prominent university in China mainland to enhance our holistic approach to health and wellness by conducting a four-week pilot on mindfulness and positive management training with select line leaders and production managers. Based on the positive results of that pilot, we expanded the program to over 3,900 employees across 33 supplier sites in 2023.

We also encourage our suppliers to set up mental health volunteer systems that promote peer-to-peer mental health support. We've developed resources to help volunteers gain basic knowledge of mental health and build the skills and emotional competencies needed to support their fellow employees, including a training program and a selfreflection system whereby volunteers check in daily for 100 days on a mobile app to take inventory of their emotions and complete activities to promote positive feelings, such as meditating or praising a colleague. The aim of these resources is to build self-awareness of volunteers' own feelings and stressors so they can better support their colleagues' mental health needs. In 2023, we expanded this initiative to 2,400 supplier employees.

To supplement this effort, we developed a mental health management toolkit to help suppliers provide better mental health support to their employees. The toolkit includes guidance on workplace mental health management and volunteer operations, selecting employee assistance programs (EAPs), and supporting people in moments of crisis.

## Supporting health education in Vietnam and India

In 2023, we continued to expand our long-standing supplier employee health education program in Vietnam and India. This program has evolved to include training on a number of different health topics, including reproductive health, prenatal and postnatal care, menstrual hygiene management, sexually transmitted infections and diseases, and genderbased violence. We also offered customized mental health training sessions for frontline leaders and supervisors on topics such as stress management, communication, conflict resolution, and crisis management. Last year, more than 8,000 people in Vietnam and 15,000 people in India took advantage of these services.

<!-- image -->

## Assessing our impact: Mental health volunteers

Measuring the impact of our learning and development programs on supplier employees is critical to understanding their effectiveness and opportunities for improvement. We engage leading academic institutions and use methodical, scientific methods to test and assess the quality and impact of the programs we offer the people in our supply chain, including our mental health volunteers initiative.

Last year, we worked with a prominent university in China mainland to design and implement an assessment to evaluate the ability of our mental health volunteers program to create effective peer-to-peer mental health support networks in our supplier facilities. We separated participants into three groups to test whether the resources we provided to mental health volunteers drove their own mental health awareness and development, as well as the resulting impact on the peers they supported.

We're surveying 1,200 mental health volunteers and over 11,000 other employees within the volunteers' spheres of influence four times throughout volunteers' participation in the training program and self-reflection system. We'll use the results to identify trends and opportunities to strengthen this program, tailoring our approach to ensure we're maximizing the value of peer networks to improve employee mental health across our supply chain.

## Personal and professional development

Through the Apple Education Hub, people across our supply chain are able to access technical education and resources on topics such as personal development, leadership, computer science, coding, robotics, recycling, and advanced manufacturing. These curated learning opportunities support the development of a more skilled and empowered workforce, as well as the advancement of manufacturing processes and technology across our suppliers' facilities. Since 2008, over seven million people across our supply chain have participated in professional development and enrichment training opportunities.

## Cultivating leadership and capability

Over the past seven years, more than 48,000 employees have participated in Apple's technical trainings, including our Line Leader and Automation Technician programs. Additionally, more than 9,000 trainees have taken part in our vocational education programs, with many moving into technical or management positions at supplier facilities soon after graduating. We've also organized over 260 capability-building activities for our trainers themselves, providing them with the skills needed to more rapidly scale our supplier employee learning and development programs.

Our Line Leader program trains supplier employees in production management, so they can advance into management roles. The training is tailored to participants' specific jobs and features real-life work scenarios and relevant case studies. Due to the continuing popularity of the Line Leader program, we're working to bring more capacity for this training online. In 2023, we piloted new online training modules with three supplier facilities in China mainland, and we plan to expand the program to India in 2024.

Our Automation Technician Training program is offered to supplier employees who are excited to kick-start their careers and learn the ins and outs of machine maintenance and troubleshooting. The program's curriculum is codeveloped with our suppliers to make the content as relevant as possible to the machinery and processes used across our supply chain. Last year, nearly 17,000 employees participated in this program across more than 40 supplier sites.

## Empowering people with disabilities

Our Vocational Education for Persons with Disabilities program seeks to drive professional growth opportunities for people who may have challenges working in standard manufacturing environments. While programs like this are more widely found in industries that primarily employ office and technical workers, manufacturing has been slower to adopt them, which is why we're taking action to create opportunities in our own supply chain.

The program provides employment opportunities for people with disabilities by leveraging a broader range of recruitment channels and then mapping candidates to available positions that best match their capabilities. Since 2022, 24 supplier facilities in China mainland have signed on to participate in this program, providing job opportunities for thousands of workers.

Once employees are hired at supplier facilities, our work to build an inclusive culture continues. We host workplace trainings for employees with disabilities, conduct accessibility assessments that identify and remove obstacles, and support effective communication between workers and their managers. For example, we offer sign language training in facilities where workers who are deaf or hard of hearing are employed. Peers of program participants also receive inclusion training to enable them to better support their coworkers, and industrial engineers are taught how to design more welcoming, comfortable workplaces.

We're supporting the expansion of this program by hosting inclusion workshops at the supplier management level and training 'inclusion ambassadors,' frontline workers who act as intermediaries between supplier management and workers with disabilities. We also organize forums for participating suppliers to share best practices and learn from one another as they scale the program at their facilities. By the end of 2023, we expanded the program to India, and we plan to expand to Vietnam in 2024.

## 48K+

supplier employees have participated in Apple's technical trainings, including our Line Leader and Automation Technician programs After graduating from high school in rural China mainland, Qijun Zhao immediately entered the workforce to earn money to support his family. But Qijun was born with a physical disability impacting his upper limbs, and he wasn't sure what career opportunities existed for him or what his workplace experience would look like.

<!-- image -->

Apple's Vocational Education for Persons with Disabilities program was designed to support people like Qijun not only providing access to career opportunities in manufacturing for people with disabilities, but also fostering a more inclusive and accessible workplace culture.

In 2022, the Vocational Education for Persons with Disabilities program launched at the Apple supplier facility where Qijun worked in China mainland, driving workplace improvements to make all employees feel safe, included, and supported. These improvements included inclusivity workshops for management, barrier-free communication and sign language trainings for employees, and tea sessions for workers to have honest conversations and build relationships.

Qijun wanted to be part of the positive change happening at his company. He realized he could use his experiences to help his colleagues with disabilities, inspiring him to shift his professional focus and move departments within his facility to work on Apple's Vocational Education for Persons with Disabilities program.

'As a person with a disability, I understand the desire to be seen and acknowledged,' said Qijun. 'When I saw lots of people with disabilities showing themselves and being active in the community, I felt so encouraged. I felt things have changed. It's time for me to do some things for the community, for people with disabilities.'

As part of his work for Apple's Vocational Education for Persons with Disabilities program, Qijun took sign language classes, hosted an inclusion-themed conference at his facility, and, perhaps most importantly, sat down and listened to the stories, experiences, and needs of his peers with disabilities. He even started a basketball team for employees with different disabilities working across various functions sitewide, breaking down silos and building community and camaraderie among his colleagues. In 2023, Qijun got promoted to a leadership role within the program at his facility.

With the help of incredible people like Qijun, Apple's Vocational Education for People with Disabilities program can continue to drive access, opportunity, and inclusion for people with disabilities across our supply chain.

'When I saw lots of people with disabilities showing themselves and being active in the community, I felt so encouraged. I felt things have changed. It's time for me to do some things for the community, for people with disabilities.'

## Expanding coding education

Coding is a critical skill for many of the advanced roles in our supply chain and across the electronics industry. Since 2017, we've offered training to supplier employees on Apple's Swift coding language, which has generated more interest with every passing year.

In our Swift coding program, advanced students attend five weeks of webinars and two weeks of classroom training. They gain valuable experience, learning to accurately solve real-world challenges as they develop their own apps. Facility Information T echnology departments are also involved in advanced curriculum reviews, and they offer feedback on case studies and student work. Once they graduate from this training, many employees move from production positions to technology and automation jobs at the same facilities.

Since 2017, nearly 40,000 supplier employees have graduated from the program, and 19 apps built in the program have been published on the App Store, achieving the high bar required, with five published in 2023 alone. We also held our first app contest last year, with 13 supplier facilities participating and 43 apps submitted. The winners of the contest included Knife Sharpening, an app to record, track, and manage tool and equipment use; BomAssistant, an intelligent selection assistant software for the electronic control of automation equipment; and E-Check, an app that helps factories conduct electronic point inspections on their mobile devices by simply scanning a QR code that automatically uploads inspection parameters and identifies potential hazards. A pilot program for BomAssistant has already been rolled out at one of our supplier facilities in China mainland.

Each year, our Swift coding program evolves and expands as we incorporate feedback from students and suppliers. In 2023, we began providing training on a broader set of computer science skills, including algorithms and design thinking, giving students the opportunity to graduate from the program with a more well-rounded skill set.

## Developing technical skills for advanced manufacturing

Providing opportunities for workers to gain valuable technical expertise benefits both suppliers and their employees by improving career mobility and advancement opportunities while strengthening suppliers' operational capabilities and efficiency.

Our technical training program includes courses on robotics, machine vision, mobile device repair, and industrial computer tools and software. Last year, we continued to scale this program, expanding to 28 supplier sites and reaching over 21,000 supplier employees.

PlanTime is an app created by a participant in our Swift coding program that enables teams to track project processes and progress.

<!-- image -->

## Supporting communities

We feel a deep sense of responsibility to everyone our supply chain reaches, including the communities where our supplier employees live and work - to respect their rights, be a force for equity and opportunity, and protect the planet we all share. Whether we're working with educators, nonprofits, or the global developer community, we believe in using our technology, expertise, and voice to help make a difference.

## Supporting human rights and environmental defenders

Last year, we supported more than 90 organizations, including human rights and environmental defenders, working to bring about real change on the ground on issues ranging from social and economic rights in mining communities, to the prevention of modern slavery, to media freedom.

In 2023, we renewed our seven-year-long partnership with the Fund for Global Human Rights (the Fund) in support of human rights, labor, and environmental defenders in the Democratic Republic of the Congo (DRC) and the Philippines who work on a range of issues, including the rights of mining communities, inclusive economic growth, judicial advocacy, environmental justice, and the rule of law, as well as health and safety for mining communities. We supported the Fund's work with 16 local grantees carrying out multifaceted work to improve human rights, including groups in the DRC supporting mining reform, land rights, economic empowerment, and children's rights. We also supported a new initiative focused on climate change and human rights that will include work to build out the Fund's climate justice grant-making strategy.

As a former recipient of its Stop Slavery Award, Apple has continued its partnership with the Thomson Reuters Foundation, which uniquely uses the combined power of journalism, the law, and data intelligence to strengthen free, fair, and informed societies. We've supported the foundation's work over the past four years to foster inclusive economies and promote human rights by strengthening responses and preventing abuses related to labor rights within businesses' operations and supply chains, which has included the training of 75 civil society organizations on new trends in the field of responsible business.

We also support the Thomson Reuters Foundation's TrustLaw program, the world's largest pro bono network, which provides legal guidance, research, training, tools, and resources to human rights and environmental defenders in 188 countries around the globe.

<!-- image -->

<!-- image -->

We're committed to safeguarding the rights of everyone in our supply chain and the communities where they live and work. A focus of this work in recent years has been the communities that Foreign Contract Workers - people who travel between countries for work - call home. Many of these communities are especially vulnerable to the worst impacts of climate change, including extreme weather events, which have created catastrophic outcomes such as the involuntary displacement of people.

In 2023, Apple and IOM piloted a climate resilience program in Ginitligan, a small community in the Philippines from which our suppliers' labor agencies hire workers and which is at a greater risk of being affected by natural disasters brought about by a changing climate.

After assessing Ginitligan's specific needs and vulnerabilities, we learned that typhoons, which are linked to climate change, have had a disastrous impact on the community, causing significant involuntary migration in recent years.

In collaboration with IOM and with input from local leaders and governments, community members, and other development partners and rights-holders, we used this information to develop local, community-driven solutions that offer clear benefits for Ginitligan and its people based on their specific needs. This work has helped enhance the community's resilience against climate change-induced migration while also providing economic development opportunities to an often underserved economy.

For Ginitligan resident Teodolfo, these projects came at a critical time. Teodolfo and his family, like many others in the area, faced a relentless cycle of rebuilding their home - often paying others to do so - after each typhoon. He relied on his daughter, Teresita, who is based in Manila, for financial support to help their family prepare for and rebuild after disasters, including to repair their house entirely when it was damaged by Typhoon Rolly in 2020. But after becoming part of the resilient shelter project, Teodolfo and his family noticed significant improvements in their comfort, privacy, and sense of safety before, during, and after typhoons.

'The resilient shelter is a big help,' said T eodolfo. 'Our house is now bigger and better compared to our house before. I do not have to repair our roof or cover it with tarpaulins to prevent water from leaking during a typhoon. We also do not have to cover holes on our walls for our privacy. We feel a lot safer here.'

Learnings from this pilot will benefit people beyond our own supply chain, which is why we're supporting IOM in creating a framework that, when published, will help convene companies, communities, governments, and development partners, helping us build resilience against climate change-induced migration together.

## How we support the development of community-driven solutions alongside the IOM

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## Resilient shelter construction

IOM constructed typhoon-resilient shelters equipped with essential amenities such as built-in toilets, kitchens, and rainwater catchment systems. These shelters reduce the damage done by typhoons and the need for people to migrate to find new housing as a result.

## Skills training

Many Ginitligan residents working abroad were forced to use part of their remittance to pay for the repeated repair of their families' homes due to the destructive effects of typhoons. That's why the Technical Education and Skills Development Authority (TESDA), the government entity focused on the technical education and skills development of the Filipino workforce, developed and administered carpentry and masonry training, equipping participants with practical skills they could use to both improve and diversify their livelihoods and repair their shelters after a typhoon.

## Coastal cleanup

To reduce migration caused by environmental degradation, IOM coordinated community-led coastal cleanup activities, including a cluster beautification contest.

## Safe migration campaign

IOM provided Ginitligan residents with learning sessions and materials about the safe migration process, including the programs and services IOM makes available to Foreign Contract Workers and their families. These resources promote safe and informed migration practices, helping protect human rights and reduce risks, should community members choose to migrate.

## How we work with suppliers

Responsible procurement ခ

Supplier assessments ခ

Capability building ခ

Supplier accountability ခ

<!-- image -->

<!-- image -->

3

<!-- image -->

<!-- image -->

<!-- image -->

|

How we work with suppliers

## How we work with suppliers

Our responsibility to people and the planet begins before we start building a product, which is why we take a continuous and holistic approach to supplier engagement, starting with our supplier selection process and continuing throughout the entirety of our business relationship with them.

While this includes regular, rigorous assessments and holding suppliers accountable when issues arise in their facilities, we go well beyond these moments in time to understand our suppliers' performance in upholding our standards. We invest heavily in capability building, on-demand training, and the development of tools, resources, and expertise, which we make available to our suppliers to support their continual improvement.

<!-- image -->

## Responsible procurement

Before a prospective supplier enters our supply chain, we assess their ability to meet our standards and identify areas for improvement.

## Assessing supplier performance prior to production

Before and after awarding business to a supplier, we conduct independent, third-party assessments of their factories to make sure they're in compliance with our Supplier Code of Conduct (Code) and Supplier Responsibility Standards (Standards) and, if needed, address any environment, health, and safety (EHS) and labor and human rights risks. If we do find potential issues, we work with the prospective supplier to correct them before awarding business or beginning mass production.

These assessments look at every detail of a supplier's operations through worker and management interviews, detailed site walk-throughs, and thorough reviews of documentation. In 2023, we conducted 123 assessments prior to awarding business and beginning mass production, addressing issues related to permit requirements, wastewater management, chemical management, emergency preparedness and response, and fire and machine safety. Through our early engagement efforts, 11 percent of prospective suppliers have been prevented from entering our supply chain since 2020 for being unable or unwilling to meet the requirements of our Code and Standards.

## Onboarding Review process

Once suppliers have been awarded business and as they prepare to ramp up production, our Onboarding Review (OBR) process provides training and guidance from Apple experts to strengthen their awareness and ability to meet the requirements of our Code and Standards in key areas such as responsible labor recruitment and health and safety. Our onboarding program also includes monitoring supplier hiring plans and labor recruitment practices, as well as supporting suppliers as they establish labor and human rights policies and procedures, trainings, and employee grievance systems.

As a result of the training and guidance they received, 100 percent of the suppliers participating in the OBR process in 2023 improved their supplier assessment scores, and 92 percent improved so significantly that they achieved 'high performer' assessment classification.

Learn more about our supplier performance scoring system on page 59 .

<!-- image -->

## Supplier assessments

We assess supplier performance against our requirements through a rigorous assessment program - and if we find areas where our standards are not being met, we hold our suppliers accountable and help them make long-lasting changes to improve their operations.

In the 2023 reporting period, we conducted 1,564 assessments of our suppliers, including assessments focused on the requirements of our Code and Standards, unannounced visits and investigations, and issue-focused audits to validate performance in specific areas such as working hours compliance, hiring practices, labor agency management, and health and safety management.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

CLOCKWISE FROM TOP LEFT: Product personalization, United States; fiber-based packaging production, Austria; Studio Display assembly, China mainland; HomePod assembly, Vietnam

## Code of Conduct assessments

Each year, through our Code of Conduct assessment process, suppliers are evaluated against more than 500 criteria to verify their performance and identify areas for improvement. These assessments are conducted globally by independent, third-party auditing firms that are accredited to meet international auditing standards. Apple employees are also often present during assessments to verify that our protocol is followed and the auditors don't experience interference. In the 2023 reporting period, we conducted 893 independent, third-party assessments focused on the requirements of our Code.

Code of Conduct assessments include a thorough review of supplier operations - from workplace conditions to hiring practices - via site walk-throughs and detailed reviews of documentation. We also hear directly from supplier employees about their workplace experience through confidential interviews and anonymous surveys.

Learn more about employee interviews and surveys on page 23 .

## Unannounced assessments and investigations

Every year, as part of our assessment program, we conduct unannounced assessments and visits, including to investigate supplier employees' concerns and verify risks identified through predictive analytics. We may also conduct an unannounced investigation to confirm the necessary changes have been made following the discovery of Code violations. In 2023, 203 unannounced assessments - where the supplier facility was given zero advance notice of our arrival - were conducted globally.

## Renewable energy audits

We require suppliers to set renewable energy use targets and make progress aligned with Apple's 2030 carbon neutrality goal. As part of our Code of Conduct assessment process, we validate the electricity usage reported by suppliers, their methodology for calculating their Apple production footprint, and all renewable energy procurement documentation. If an auditor finds inaccuracies in a supplier's data, the supplier is required to complete a Corrective Action Plan (CAP), and the matter is escalated to Apple and supplier leadership. In 2023, we conducted 94 such audits in six countries and regions.

Learn more about Corrective Action Plans on page 43 .

## Zero Waste verification audits

We work with UL (Underwriters Laboratories), the certifying body behind the Zero Waste certification, to implement Zero Waste standards across our supply chain. Last year, we introduced a new type of assessment to verify suppliers' compliance with the Zero Waste framework, including through the validation of self-reported waste data. We piloted this assessment during renewable energy audits we conducted at 10 supplier sites in four countries and regions, and we plan to expand further in 2024.

## Recycler audits

We verify our recyclers' compliance with our Code and Standards through independent, third-party assessments, assessing 98 recycler sites in 2023. All of our recyclers in North America are certified by either e-Stewards® or R2, the electronics industry's leading certifications for assessing the environmental, worker health, and security practices of entities managing used electronics.

## Issue-focused audits

In addition to our annual Code of Conduct assessments, our suppliers, their labor agencies, and other entities in our supply chain may receive supplemental assessments focused on one or more specific issues as a result of particular risk factors or in response to an allegation.

We select suppliers for these focused audits based on a number of factors, including geography, previous assessment performance, materials and processes used, worker population, and planned spending. In 2023, 153 issue-focused audits were conducted, including those focused on working hours compliance, hiring practices, labor agency management, and specific health and safety issues.

## Materials audits

While Apple does not directly purchase, procure, or source primary minerals, we maintain strict standards for the responsible sourcing of the materials that end up in our products. In 2023, 100 percent of the identified tin, tantalum, tungsten, gold (3TG), cobalt, and lithium smelters, refiners, and manufacturers in our supply chain participated in third-party assessments to verify compliance with our standards and aid in identifying social, environmental, human rights, and governance risks deeper in our supply chain. This marks nine consecutive years of 100 percent compliance for 3TG, eight consecutive years for cobalt, and four consecutive years for lithium.

Learn more about smelters, refiners, and manufacturers of primary materials on page 48 .

## Third-party industry assessments

In addition to assessments of our own production lines and capability-building efforts conducted by thirdparty auditors, we require many of our suppliers to also undergo the RBA's Validated Assessment Program (VAP), a facility-wide, third-party assessment widely used by the industry. VAP assessments evaluate a facility's operations, including - but also beyond Apple production lines. This combined effort works to prevent violations of our Code and Standards beyond our own supply chain. Last year, a total of 100 VAP assessments were completed at Apple supplier sites.

## What's included in a Code of Conduct assessment/questionmark

## Management interviews

We interview supplier management to confirm that proper management practices and systems are in place as required by our Code and Standards.

## Extensive document review

We thoroughly review employee records, payroll information, contracts, and policy documentation.

## Employee interviews

We interview supplier employees in their native language and without management or cameras present to confirm that our observations match their experiences.

## Site walk-throughs

Detailed inspections examine chemical safety, fire safety, indoor air quality, machine safety, environmental controls, and personal protective equipment (PPE), among many other requirements.

<!-- image -->

<!-- image -->

<!-- image -->

Our supply chainʼs average performance on Code of Conduct assessments in 2023, by evaluation category

<!-- image -->

<!-- image -->

<!-- image -->

## Year-over-year Code of Conduct assessment performance

<!-- image -->

Audits in our supply chain in 2023

<!-- image -->

<!-- image -->

Of the five Core Violations discovered in 2023, four were falsification violations resulting from improperly reported working hours data, and one was a health and safety violation related to machine safety practices that did not meet our standards.

<!-- image -->

## How we safeguard our assessment process

## Our assessments are conducted globally.

-  Apple Code of Conduct assessments, including surprise assessments, are conducted globally. Since 2007, our assessments have covered approximately 94 percent of Apple's direct manufacturing spend. In 2023, we conducted independent, third-party assessments in more than 50 countries and regions.
-  We publish and annually update our Supplier List, which covers at least 98 percent of our direct spend for materials, manufacturing, and assembly of our products worldwide.
-  As required by our Code and Standards, suppliers cannot have operations in, recruit labor directly or indirectly from, or source materials, products, or services directly or indirectly from regions where Apple and third parties cannot access and conduct a comprehensive, independent evaluation of the supplier's compliance with our Code and Standards.

## We maintain robust safeguards against assessment interference.

-  All assessments globally are conducted by independent, third-party auditing firms that are accredited to meet international auditing standards. Many of the firms that conduct our assessments are also those certified to meet the standards of the Responsible Business Alliance. Apple employees are also often present for assessments to verify that our protocol is followed.
-  We prohibit interference of any kind in our assessment process and require that interviews conducted as part of assessments take place in confidential places with no managers or cameras present. Apple partners with auditing firms that provide local auditors with native language capability so that no language barrier exists between the supplier employee being interviewed and the auditor.
-  Retaliation in any form is a Core Violation   of our Code, and last year, more than 35,000 follow-up phone calls were made to verify that supplier employees who participated in interviews did not experience retaliation as a result of their participation. 10
-  In 2023, auditors did not report any experiences of interference from supplier management, local officials, or any other entities.
-  We provide anonymous hotlines where supplier employees can contact Apple directly, accessible at any time and in any language, should they experience retaliation or have any other concern about their workplace experience.
-  In 2021, we launched a third-party grievance hotline awareness campaign. In 2023, the campaign reached more than 830,000 supplier employees.

## We investigate the reports we receive.

-  In addition to thoroughly assessing our suppliers' performance in upholding our standards, we also receive reports from the press, governments, civil society, and people in our supply chain, and we encourage the public to report concerns via our public website . We investigate the reports we receive and frequently have Apple teams onsite within 24-48 hours.

## We consistently raise the bar.

-  We regularly revisit all of our supplier requirements, consistently raising the bar that suppliers must meet in order to continue doing business with us, and share the updates publicly.

## Capability building

We work with suppliers on an ongoing basis to support their continued growth and improvement and help them meet our high standards. This includes not only helping them expediently correct any noncompliance and strengthen their management systems, but also providing training, tools, resources, and one-on-one support.

## Supplier training

Through SupplierCare and in-person engagement, we provide training to suppliers to increase their awareness and capabilities related to new requirements, emerging risks, and gaps identified by our assessment data and predictive analytics. These trainings include topics such as health and safety ( learn more on page 25 ), machine safety ( learn more on page 25 ), and responsible labor recruitment ( learn more on page 20 ) - and we're continually expanding their scope.

For example, in 2022, we introduced a new clean air capability-building program designed to support suppliers in better managing their air emissions and improving air quality in their communities. Last year, we expanded the program to include training courses and guidance from Apple experts on how to abate fluorinated greenhouse gases (F-GHGs), the largest contributors of direct emissions in our supply chain. We engaged more than 1,000 supplier sites in this program, helping them develop projects that reduced their emissions of air pollutants by 130 tons.

## Subject Matter Expert program

Apple employs dedicated supply chain and manufacturing experts with robust experience to help our suppliers solve technical and management challenges. Our Subject Matter Expert (SME) program sends these Apple experts onsite to supplier facilities to help define customized capability-building plans for corrective action and general workplace improvement. Our experts connect directly with suppliers using tools such as one-on-one assistance and customized online learning through illustrated, self-paced manuals that provide instruction and requirements for the areas of our Code and Standards commonly encountered in daily operations.

Engagement and capability building with Apple SMEs support suppliers' ability to better comply with our requirements. In 2023, more than 40 supplier facilities took advantage of this program, with the most requested topics being labor recruitment management, thirdparty labor agency management, wage and benefit management, and air emissions management.

<!-- image -->

<!-- image -->

## Supplier accountability

We hold our suppliers accountable at every stage of our business relationship with them. If we discover violations of our requirements during an assessment, investigation, or as a result of regular business engagement, we require suppliers to promptly implement a plan to correct the problem and provide remedy to affected employees.

Following the identification of an issue or incident, we discuss findings with the supplier at their facility and work with them to create a Corrective Action Plan (CAP). This includes providing the supplier with feedback and identification of issues and then working with them to conduct the required root-cause analysis and implement preventive measures. As part of this process, our capability-building team provides suppliers with training on industry best practices, guidance for resolving identified issues, and support to strengthen their management systems and prevent the issue from reoccurring.

During this period, 30-, 60-, and 90-day check-ins with Apple are required to address any questions encountered during the remediation process and provide clarification, awareness, and training where needed. Once the CAP has been fulfilled, we verify that all corrective actions have been completed to our standards through our Corrective Action Verification (CAV) process. Our CAP and CAV processes successfully closed 95.9 percent of findings in 2023.

We view removing a supplier from our supply chain as a last resort, because in our experience, it does not provide workers with needed remedy and could allow violations to continue elsewhere in the industry. However, in the event that a supplier is unwilling or unable to correct violations and improve their operations to meet our requirements - despite our investment of time and engagement they risk removal from our supply chain. Since 2009, we have removed 25 manufacturing supplier facilities and 231 smelters, refiners, and manufacturers of materials from our supply chain for failing to meet our standards.

To learn more about how we hold suppliers accountable to our requirements and remediate violations of our Code and Standards, refer to our United Nations Guiding Principles on Business and Human Rights: 2024 Mapping of the Apple Supply Chain .

<!-- image -->

## How we're moving toward a circular supply chain

Innovating toward recycled and renewable materials ခ

Responsible sourcing of materials ခ

Addressing challenges through collaboration ခ

<!-- image -->

<!-- image -->

<!-- image -->

4

<!-- image -->

<!-- image -->

|

How we're moving toward a circular supply chain

## How we're moving toward a circular supply chain

The decisions we make about the materials we use and how they're sourced can have major implications on not only the environment, but also the rights, dignity, and well-being of the people working across our supply chain.

As we move toward our goal to use only recycled and renewable materials in our products and packaging, we maintain strict standards for the responsible sourcing of all materials - whether primary or recycled - while supporting the rights and safety of the people working and living in mining communities around the world.

<!-- image -->

<!-- image -->

Recycling, Singapore; materials recovered by Daisy, Appleʼs iPhone disassembly robot, United States; Apple Watch

CLOCKWISE FROM TOP LEFT: assembly, Vietnam

<!-- image -->

## Innovating toward recycled and renewable materials

We design our products to use materials that are sourced in a way that's better for people and the planet. In 2023, 22 percent of the materials we shipped in products came from recycled or renewable sources. 1

This work requires innovation. We're continuing to develop and find new sources of recycled and renewable content, as well as innovate new approaches to recycling materials, in order to close the loop within our supply chain and beyond. The benefits of this change will be felt beyond our own supply chain, from the people who use and interact with our products, to the markets in which we operate, to communities around the globe. While we recognize that the scale of this challenge is significant, the potential for creating a lasting, positive impact motivates us.

## Improving material recovery rates

Effectively disassembling and recycling our products after their use is a key part of our work to support a circular economy. We invest heavily in recycling innovation, including at our asset recovery center in California and our Material Recovery Lab (MRL) in Texas. At the MRL, we're working on developing more effective and efficient means of disassembling products that maximize material recovery while minimizing waste.

We've designed a team of disassembly robots - Daisy, Dave, and Taz - to recover valuable materials from recycled devices. Daisy is now capable of quickly and skillfully taking apart 29 models of iPhone - including various models between iPhone 5 and iPhone 14 Pro Max - into discrete components to recover valuable materials.

We're also developing new technologies at our asset recovery center that can automate reuse and recycling processes that have typically required manual sorting, which can be time-intensive and error-prone. This work aims to create low-cost solutions that our recycling suppliers can deploy to recover more materials.

## Focusing on priority materials

Our recycled and renewable efforts focus on 15 materials that we've prioritized based on their environmental and social impacts within Apple's supply chain. These include aluminum, cobalt, copper, glass, gold, lithium, paper, plastics, rare earth elements, steel, tantalum, tin, titanium, tungsten, and zinc, which account for 87 percent of the total product mass shipped to our customers in 2023. 11

Last year, we took an ambitious leap forward by setting new 2025 recycled materials targets to bring us closer to our ultimate goal of making all products with only recycled and renewable materials. We also launched our first products with 100 percent recycled cobalt in the battery, including iPhone 15, iPhone 15 Pro, Apple Watch Series 9, and Apple Watch Ultra 2. 12 Across all products in 2023, our use of certified recycled cobalt increased to 52 percent, on a mass-balance basis, including postindustrial scrap and postconsumer scrap from end-of-life batteries.

## Our 2025 recycled materials targets

<!-- image -->

All Apple-designed batteries are targeted to be made with 100 percent recycled cobalt. 6

Magnets in Apple devices are targeted to use 100 percent recycled rare earth elements. 7

<!-- image -->

All Apple-designed printed circuit boards are targeted to use 100 percent recycled tin soldering and gold plating. 8

<!-- image -->

|

Innovating toward recycled and renewable materials

<!-- image -->

<!-- image -->

4

<!-- image -->

|

## Responsible sourcing of materials

As we work toward our goal to use only recycled and renewable materials, we remain committed to sourcing all materials that go into our products responsibly, regardless of their origin. Our Responsible Sourcing of Materials Standard (Responsible Sourcing Standard) applies to all suppliers and meets or exceeds internationally accepted standards for human rights and the environment. We also collaborate with government, civil society, and industry experts to support local mining communities and make sure that our initiatives continue to address the challenges they face.

The first step in driving our high standards for materials sourcing is establishing a deep understanding of our supply chain, which we do by mapping the companies that provide materials to our suppliers. We use this information to publish a list of our identified tin, tantalum, tungsten, gold (3TG), cobalt, and lithium smelters and refiners, which we update each year.

In 2023, 100 percent of identified 3TG, cobalt, and lithium smelters, refiners, and manufacturers participated in assessments to verify compliance with our standards, including strict social, environmental, human rights, and governance requirements. This marks nine consecutive years of 100 percent compliance for 3TG, eight consecutive years for cobalt, and four consecutive years for lithium. If smelters and refiners are unable or unwilling to meet our requirements, they risk removal from our supply chain. Since 2009, Apple has directed the removal of 222 3TG and 9 cobalt smelters and refiners from our supply chain, including 14 in 2023.

## Sharing tools and resources to accelerate progress

We require the suppliers, smelters, refiners, materials manufacturers, and recyclers deeper in our supply chain to identify and assess possible risks related to labor and human rights, health and safety, and the environment. To support their work, we're helping strengthen and increase the transparency of independent, third-party auditing programs at the smelter, refiner, and mining levels.

We also continue to innovate, develop, and scale risk identification tools, together with partners such as the Responsible Business Alliance (RBA) and IMPACT, a nongovernmental organization (NGO) working to transform how natural resources are managed in areas where human rights are at risk. In 2023, we continued to support IMPACT's work to develop solutions that measure and track supply chain activities and their social and environmental impacts in artisanal and small-scale mining (ASM) communities.

We communicate our sourcing requirements and engage with 3TG suppliers through training webinars on topics such as responsible sourcing regulations and due diligence management systems. In 2023, more than 400 suppliers took advantage of this training program. And through our SupplierCare platform, we offer additional online training resources in multiple languages.

To learn more about how we're increasing transparency and addressing risks deeper in our supply chain, refer to our United Nations Guiding Principles on Business and Human Rights: 2024 Mapping of the Apple Supply Chain

.

## Addressing challenges through collaboration

Addressing challenges in the materials supply chain and supporting those working and living in mining communities require innovation and collaboration with stakeholders beyond our own supply chain. We regularly engage with a broad range of stakeholders and rightsholders - including human rights, environmental, and minerals experts from civil society, NGOs, industry, academia, and government - to review and gather feedback on Apple's programs and explore innovative and responsible approaches to materials sourcing.

In 2023, we continued our active participation in and leadership on multiple industry associations and multistakeholder initiatives, including:

-  The Board of Directors of the RBA
-  The Steering Committee of the RBA's Responsible Minerals Initiative (RMI)
-  The Governance Committee of the Public Private Alliance for Responsible Minerals Trade (PPA)
-  The European Partnership for Responsible Minerals (EPRM)

Throughout 2023, we drove and actively contributed to a variety of activities with leading industry organizations and multistakeholder initiatives, including supporting the ongoing development of industrywide responsible sourcing standards and participating in multiple panels at the annual RBA and RMI conferences.

## Strengthening industry traceability systems

Last year, in partnership with sustainability nonprofit RESOLVE, we continued to fund and scale Regeneration, a social enterprise focused on processing waste material from legacy mine sites to restore natural environments and support rehabilitation and biodiversity. RESOLVE's earnings from the sale of these responsibly sourced materials will be reinvested in habitat restoration.

Regeneration is an expansion of Salmon Gold, a partnership that we continued to fund and scale with RESOLVE in 2023. Salmon Gold works with small-scale miners and Indigenous communities in remote regions of the Yukon, Alaska, and British Columbia to support mining practices that help restore rivers and streams so that salmon and other fish can thrive. This work includes connecting local miners, environmentalists, and government agencies to mitigate the damage done by historic mining activities. The gold mined from this project is then traced from its origin to a refiner in Apple's supply chain using blockchain technology.

## Supporting mining communities

We're committed to improving conditions in and around mining communities and contributing to a just transition as we move toward recycled and renewable materials. We partner with experts to empower independent voices and provide vocational education programs that enable members of local communities moving away from mining to build skills and pursue new opportunities.

## Empowering independent voices

Ensuring independent voices at the mining level have a forum for raising concerns is critical to identifying and assessing risks and better supporting people deeper in our supply chain. For the eighth consecutive year, we provided funding to a whistleblowing mechanism, which enables people in and around mining communities in the Democratic Republic of the Congo (DRC) to anonymously raise concerns related to mineral extraction, trade, handling, and exporting using a toll-free hotline. In 2023, the program continued to increase awareness and utilization of the whistleblowing mechanism through radio campaigns in mining communities, the distribution of promotional materials, and consultations with stakeholders such as local civil society actors.

And for the seventh year, we supported rights awareness training for miners, youth, and community officials in ASM communities in the DRC through our partnership with the international development NGO Pact. These trainings are designed to raise awareness of a range of human rights issues and are based in part on a curriculum developed by the United Nations Children's Emergency Fund (UNICEF). We've worked with Pact to make adjustments and improvements to enable the sustainability of these programs, including implementing Pact's WORTH savings and loan program for both community members and apprenticeship graduates, providing more technical assistance to graduates, and collaborating even more with community groups and local government bureaus to create sustainable transition plans for core program activities.

## Providing education and training

Last year, we continued to support Pact's vocational education programming that provides mentorship, literacy classes, and career training for trades such as hairdressing, carpentry, auto mechanics, and welding to mining communities in the DRC.

We also continued to support the Massachusetts Institute of Technology (MIT) D-Labs' work with Universidad Nacional to build a robust national association of women artisanal miners in Colombia called Mujeres Mineras Unidas por Colombia (MMUC). MMUC members facilitate trainings for local miners in gold ASM communities. In 2023, 148 women artisanal miners from 17 territories participated in co-design workshops, focusing on formalization and environmental sustainability.

For more information on the ways we support mining communities in our supply chain, refer to our Conflict Minerals Report .

<!-- image -->

5

## How we're creating change through shared action

Sharing tools and resources to drive progress ခ Partnerships ခ

<!-- image -->

3

<!-- image -->

4

<!-- image -->

5

<!-- image -->

## Sharing tools and resources to drive progress

As we work to support people and the planet throughout our supply chain, our goal is always to share our knowledge and lessons learned with others, so that everyone can achieve progress, faster. The following are examples of how we continue to make key tools, technologies, and platforms we've developed openly available to both our suppliers and companies beyond our supply chain to use in their own businesses.

## Bloom

We work with the non-governmental organization (NGO) IMPACT to support the development of tools such as Bloom, an interactive platform to measure and track human rights risks in mineral supply chains as well as the impact of supply chain activities on the social and environmental well-being of artisanal and small-scale mining (ASM) communities in the Democratic Republic of the Congo (DRC).

## ChemWorks

Together with ChemFORWARD, we launched ChemWorks, an open-access platform that helps accelerate the adoption of safer cleaners and degreasers by providing resources for formulators to screen and optimize their products with verified safer chemicals.

## Clean Energy Procurement Academy

In 2023, we announced plans to donate our clean energy resources to create a first-of-its-kind public training platform that will be available to businesses across many different industries, giving companies of all sizes - in Apple's supply chain and beyond - access to the resources and advocacy networks we've cultivated for nearly a decade. We've partnered with the Clean Energy Buyers Institute (CEBI) and other corporates to launch the inaugural Clean Energy Procurement Academy, a shared training curriculum and delivery process that will equip companies with the technical readiness to advance clean energy procurement, address scope 3 emissions, and decarbonize global supply chains.

## International Organization for Migration (IOM) Fair and Ethical Recruitment Due Diligence Toolkit

In 2022, we supported the creation and release of the IOM Fair and Ethical Recruitment Due Diligence Toolkit. Based on tools developed by Apple and tested in our supply chain, IOM's toolkit is available to companies across industries and around the world and designed to help them conduct comprehensive due diligence at every stage of recruitment.

Last year, we helped IOM scale its toolkit to other industries and stakeholder groups around the world. This included pilots in Saudi Arabia and Canada, where employers and government agencies were trained on how to use IOM's toolkit.

## IOM Remediation Guidelines for Victims of Exploitation in Extended Mineral Supply Chains (Remediation Guidelines)

Apple helped fund and draft IOM's Remediation Guidelines, a publicly available resource that provides concrete guidance to companies and their business partners on how to ensure victims of exploitation in mineral supply chains are adequately protected and assisted.

## IPC Standard for Greener Cleaners Used in Electronics Manufacturing

We worked with IPC, the premier global association for electronics manufacturing, to help draft and launch IPC1402, Standard for Greener Cleaners Used in Electronics Manufacturing . This standard helps companies across the electronics industry select cleaners that are safer for their employees and the environment.

## Recyclable protective films (RPFs)

In 2018, we helped develop the industry's first RPFs. These films, which protect products during manufacturing, have since been widely adopted among our final assembly sites, preventing more than 15,000 metric tons of plastic waste from being sent to landfills. We're promoting the use of RPFs across industries, having worked with 14 suppliers to verify their materials through recyclability testing so that others beyond Apple can make this change, too.

## Responsible Business Alliance (RBA) Process Chemical Management and Safety Learning Plan

We donated our technical guidance and training materials on safer chemical management to the RBA, which used them to create the Process Chemical Management and Safety Learning Plan, a comprehensive global resource on responsible chemical management. The Process Chemical Management and Safety Learning Plan is available to all RBA members around the world on the organization's e-learning platform.

<!-- image -->

In 2022, the IOM released the Fair and Ethical Recruitment Due Diligence Toolkit based on tools developed by Apple and tested in our supply chain.

## RBA Responsible Recruitment Due Diligence Toolkit

In 2021, we supported the creation and release of the RBA's Responsible Recruitment Due Diligence Toolkit, which provides RBA members and their supply chain partners with practical guidance and tools to prevent forced labor in their supply chains. Based on tools originally tested and scaled in Apple's supply chain, the RBA's toolkit is focused on building the capacity of workplaces to actively engage and monitor their labor recruitment partners to ensure no one is forced to work in their supply chains.

## RBA Specialty Validated Assessment Program for Chemical Management (SVAP-CM)

We provided funding to help the RBA develop and launch a new subset of its Validated Assessment Program (VAP) that's specifically focused on chemical management. An overview of the SVAP-CM provisions is free for all companies to help ensure that their manufacturing suppliers are using best-in-class chemical management systems, controls, and administrative structures that uphold human rights.

## Responsible Minerals Initiative (RMI) Minerals Grievance Platform

We first funded and developed the RMI's Minerals Grievance Platform, a cross-industry platform where allegations concerning minerals supply chains are reported, investigated, and addressed. Grievances can be anonymously submitted by NGOs, companies, or the public.

## Risk Readiness Assessment (RRA)

Apple first funded and developed the RRA, which has been deployed by the RMI since 2017 and is now used by hundreds of companies across industries to assess risks in their global supply chains. In addition, Copper Mark, an assurance framework that promotes responsible copper production, used the RRA as part of its criteria at 69 sites last year.

## Stretch wrapping film

We've developed a proprietary formula for thinner stretch wrapping film used on pallets for finished product shipping. Product wrapping film accounts for a considerable amount of virgin plastic usage within our supply chain. By adopting the thinner film, we're reducing the plastic used during this process by up to 50 percent. We've shared this formula with our suppliers and their vendors to help accelerate its adoption and reduce reliance on virgin materials across the industry.

## Waste to Resource platform

In 2021, we developed an externally hosted, free, open platform where any company can access our zero waste resources - including lists of recommended recyclers - in pursuit of their own waste reduction goals. In 2023, we extended the platform's reach, providing more than 1,500 informational resources to our suppliers and other businesses beyond our own supply chain across China mainland, Thailand, Vietnam, and India - a number that grows as we and our suppliers continue to share valuable resources through the database.

Our goal is to continue enhancing the platform, making it easier for suppliers and other companies to navigate a readily accessible list of recyclers in their countries.

## Water stewardship

We work with the Alliance for Water Stewardship (AWS) to give both our suppliers and the broader industry the tools and resources needed to address their water use more holistically. We funded the creation of the AWS T ools Hub, a series of online tools open to AWS members that makes it easier for them to learn about, assess themselves against, and adopt the AWS Standard. These resources include:

-  A training program based on learning modules Apple donated from our SupplierCare platform
-  'E-Standards,' a digital, interactive version of the AWS Standard that allows companies to record and track their progress toward implementation
-  The Audit Ready Toolkit, which allows companies to assess themselves against the Standard's requirements

We also funded the translation of these tools - as well as the AWS Standard itself - to promote the adoption of the Standard across additional countries and regions.

## Partnerships

<!-- image -->

## Alliance for Water Stewardship (AWS)

AWS is a global initiative that fosters collaboration between businesses, governments, and civil society, offering a framework and standard for demonstrating world-class water stewardship practices.

-

Apple continues to raise awareness and drive the adoption of the AWS Standard among our suppliers and others in our industry to advance the sustainability of local water resources around the world. Apple is also the first electronics company to serve on the AWS board of trustees and participates in the AWS ICT (Information and Communications Technology) sector working group.

<!-- image -->

## ChemFORWARD

ChemFORWARD is a supply chain collaboration working to advance safer chemistry in product design and manufacturing by expanding access to verified chemical hazard data and safer alternatives.

-

Apple is a Co-design Partner at ChemFORWARD and cochairs the organization's Technical Advisory Group. Apple and ChemFORWARD also co-launched ChemWorks, a website that provides companies across the electronics industry access to certified safer formulations and resources for formulators to screen and optimize their products with verified safer chemicals.

<!-- image -->

## Clean Electronics Production Network (CEPN)

CEPN is a multistakeholder initiative working to improve chemical safety in the electronics supply chain.

-

Apple is a founding member of CEPN and serves on its design team. We're also a founding signatory of the organization's T oward Zero Exposure (TZE) program, a public platform for companies across the electronics industry to commit to and report on their efforts to eliminate workers' exposure to hazardous chemicals in manufacturing.

<!-- image -->

## Clean Energy Buyers Alliance (CEBA)

CEBA is a membership association for large-scale energy buyers that seeks to democratize clean energy for all buyers and create a resilient, zero-carbon energy future.

-

Apple sits on the board of CEBA and serves on its Supply Chain and International Collaboration working group.

<!-- image -->

## European Partnership for Responsible Minerals (EPRM)

EPRM is a partnership between civil society, industry, and government focused on responsible artisanal and small-scale mining (ASM) and sourcing practices, as well as improving social and economic conditions for mining communities.

-

Apple is a member of the EPRM.

<!-- image -->

## International Labour Organization (ILO)

The ILO is the United Nations (UN) agency that governs labor rights and standards at work. It brings together governments, employers, and workers to 'drive a human-centered approach to the future of work through employment creation, rights at work, social protection, and social dialogue.'

-

Apple works with the ILO on a number of projects, including those related to rights training, responsible recruitment, freedom of association and collective bargaining, and advancing worker voice. Apple also serves on the steering committee of the ILO Global Business Network on Forced Labour.

<!-- image -->

## Fund for Global Human Rights

The Fund for Global Human Rights (the Fund) is a public foundation that works with local human rights organizations in 63 countries around the globe to empower voices, mobilize movements, and improve lives.

-

Apple partners with the Fund to support frontline human rights and environmental defenders working on a range of issues, including economic and social rights, inclusive economic growth, judicial advocacy, environmental justice, and the rule of law, as well as health, safety, and fair compensation.

<!-- image -->

## International Organization for Migration (IOM)

IOM is a UN agency and the leading global expert on migration. It works to facilitate pathways for regular and safe migration, ensuring the orderly and humane management of migration, promote international cooperation on migration issues, drive solutions to displacement, and save lives and protect people on the move, providing humanitarian assistance to migrants and vulnerable communities in need.

-

Apple partnered with IOM to develop our Responsible Labor Recruitment Due Diligence Toolkit (Recruitment Toolkit). IOM also delivers trainings to our suppliers on the Recruitment Toolkit.

<!-- image -->

## IMPACT

IMPACT is a nonprofit organization that transforms how natural resources are managed in areas where security and human rights are at risk.

-

Apple supported IMPACT's development of Bloom, an interactive platform to measure and track human rights risks in mineral supply chains, as well as the impact of supply chain-related activities on social and environmental well-being in ASM communities in the Democratic Republic of the Congo (DRC).

<!-- image -->

## Pact

Pact is an international development organization that works on the ground in nearly 40 countries, building solutions for human development in true partnership with communities.

-

Apple partners with Pact to deliver rights awareness training and vocational education programs to miners, youth, and community officials in mining communities in the DRC.

<!-- image -->

## Institute of Public &amp; Environmental Affairs (IPE)

IPE is a leading nonprofit environmental research organization based in Beijing that is dedicated to collecting, collating, and analyzing government and corporate environmental data. Through its platforms and partnerships, IPE works to achieve environmental transformation, promote environmental information disclosure, and improve environmental governance mechanisms.

-

As the first recipient of IPE's Green Supply Chain Corporate Information Transparency Index Master's Level Designation, Apple is committed to actively engaging our suppliers in China mainland to help achieve our climate resource conservation goals and helping others in the industry do the same.

<!-- image -->

## Public-Private Alliance for Responsible Minerals Trade (PPA)

The PPA is a multisector initiative supporting the ethical production, trade, and sourcing of minerals from the African Great Lakes region.

-

Apple serves on the PPA's Governance Committee.

<!-- image -->

## RE100

RE100 is a global initiative bringing together the world's most influential businesses driving the transition to 100 percent renewable electricity.

-

Apple sits on the RE100 Advisory Committee.

<!-- image -->

## Responsible Minerals Initiative (RMI)

Part of the RBA, the RMI is one of the most utilized resources for companies from a range of industries to address responsible mineral sourcing issues in their supply chains.

-

Apple sits on the RMI's steering committee and is engaged in a number of RMI working groups and fund projects.

## RESOLVE

RESOLVE is a leading sustainability non-governmental organization (NGO) driving sustainable solutions to critical social, health, and environmental challenges by creating innovative partnerships where they're needed most.

-

Apple works with RESOLVE to fund Regeneration, a social enterprise focused on processing waste material from legacy mine sites to restore natural environments and support rehabilitation and biodiversity. Regeneration is an expansion of an earlier project, Salmon Gold, which is a partnership between Apple, RESOLVE, and Tiffany &amp; Co.

<!-- image -->

## Thomson Reuters Foundation

Thomson Reuters Foundation is an independent charity working to advance media freedom, foster more inclusive economies, and promote human rights. The foundation aims to drive systemic change through news, media development, free legal assistance, and convening initiatives.

-

Apple is a former recipient of Thomson Reuters Foundation's Stop Slavery Award. Apple also supports TrustLaw, the world's largest pro bono network, which provides legal support, research, training, tools, and resources for NGOs and social enterprises at the frontlines of social change.

<!-- image -->

## Responsible Business Alliance (RBA)

RBA is the world's largest industry coalition dedicated to responsible business conduct in global supply chains.

-

Apple collaborates with the RBA and its member companies throughout the year on initiatives spanning the entirety of the work we do across our supply chain. In 2023, Apple served in several leadership capacities, including:

-  Member of the Board of Directors
-  Founding and former steering committee member of the Responsible Labor Initiative (RLI)
-  Steering committee member of the Responsible Minerals Initiative (RMI)
-  Member of the Environment Task Force

<!-- image -->

## Working Capital Innovation Fund (incubated by Humanity United)

Working Capital Innovation Fund is an early-stage venture fund that invests in scalable supply chain tools to meet the need for more transparent and ethical supply chains, addressing the need to protect vulnerable workers and source responsibly.

-

Apple is a founding member of and investor in the Working Capital Innovation Fund.

<!-- image -->

## Responsible Labor Initiative (RLI)

Established by the RBA, the RLI is a multi-industry, multistakeholder initiative focused on ensuring that the rights of workers vulnerable to forced labor in global supply chains are consistently respected and promoted.

-

Apple is a founding member of the RLI and formerly served on its steering committee.

<!-- image -->

6

## Additional resources

Reports and filings ခ How we prevent forced labor in our supply chain ခ Understanding assessment results ခ Endnotes ခ

1

2

<!-- image -->

3

<!-- image -->

4

<!-- image -->

5

<!-- image -->

6

<!-- image -->

6

## Reports and filings

In addition to this progress report, Apple releases annual policy updates, public reports, and disclosures.

## Apple Human Rights Policy

Our Human Rights Policy is based on internationally recognized standards, including the United Nations (UN) International Bill of Human Rights, the International Labour Organization's (ILO) Declaration on Fundamental Principles and Rights at Work, and the United Nations Guiding Principles on Business and Human Rights (UNGPs). It governs how we treat everyone, from our customers and teams, to our business partners, to people at every level of our supply chain.

[Human Rights Policy ခ](https://s2.q4cdn.com/470004039/files/doc_downloads/gov_docs/Apple-Human-Rights-Policy.pdf)

## Apple Supplier Code of Conduct and Supplier Responsibility Standards

Our Supplier Code of Conduct (Code) outlines Apple's requirements for its suppliers regarding conduct related to labor and human rights, health and safety, environmental protection, ethics, and management practices. Apple's Supplier Responsibility Standards (Standards) provide additional clarity regarding Apple's requirements. Apple suppliers must meet these Standards to be in compliance with our Code.

[Supplier Code and Standards ခ](http://www.supplychainreports.apple/Supplier-Code-of-Conduct-and-Supplier-Responsibility-Standards)

## Conflict Minerals Report

The Conflict Minerals Report serves as our filing to the United States (U.S.) Securities and Exchange Commission (SEC) in compliance with Dodd-Frank Section 1502 reporting related to the sourcing of tin, tantalum, tungsten, and gold (3TG) from the Democratic Republic of the Congo (DRC) and adjoining countries.

[Conflict Minerals Report ခ](http://www.supplychainreports.apple/Apple-Conflict-Minerals-Report)

## Corporate Environment, Health and Safety Policy

Apple is committed to protecting the environment as well as the health and safety of our employees, customers, and the global communities where we operate.

The Corporate Environment, Health and Safety (EHS) policy is contained in the Environmental Progress Report available at apple.com/environment ခ

## Environmental Progress Report

Every year, we release a report with detailed information about our environmental efforts, how we measure our overall environmental footprint, and the progress we've made over the past year.

Apple's Environmental Progress Report is available at apple.com/environment ခ

## Material Impact Profiles

This paper details how we've prioritized the materials in our products based on their environmental, social, and supply chain impacts. The prioritized list of materials represents those that we'll first transition to recycled or renewable content, driving toward our goal of using 100 percent recycled or renewable materials in our products.

[Material Impact Profiles ခ](https://www.apple.com/environment/pdf/Apple_Material_Impact_Profiles_April2019.pdf)

## Product Environmental Reports

Key Apple product releases are accompanied by a Product Environmental Report, which provides environmental information relevant to the entire life cycle impact of that product.

Product Environmental Reports are available at apple.com/environment ခ

## Smelter and Refiner List

The Smelter and Refiner List includes smelters and refiners of 3TG, lithium, and cobalt in our supply chain.

[Smelter and Refiner List ခ](http://www.supplychainreports.apple/Apple-Smelter-Refiner-List)

## Supplier List

The Apple Supplier List represents 98 percent of our direct spend for materials, manufacturing, and assembly of our products worldwide.

## [Supplier List ခ](http://www.supplychainreports.apple/Apple-Supplier-List)

## United Nations Guiding Principles on Business and Human Rights: 2024 Mapping of the Apple Supply Chain

This document outlines the policies, processes, and programs for identifying, mitigating, and remedying salient human rights risks in our global supply chain.

[United Nations Guiding Principles on Business and Human Rights: 2024 Mapping of the Apple Supply Chain ခ](http://www.supplychainreports.apple/Apple-UNGP-Mapping)

## How we prevent forced labor in our supply chain

Apple does not tolerate forced labor. In the more than 50 countries and regions where our suppliers operate, we have teams of experts, including independent third parties, who monitor our suppliers and have put industry-leading procedures in place to help verify that no one is forced to work.

Our comprehensive approach starts before we sign a contract with a supplier and is meant to confirm that people's rights are respected throughout the entirety of their employment journey, regardless of their job, their location, or how they were hired.

<!-- image -->

## We set the highest standards.

Eliminating forced labor begins with setting and maintaining the highest standards. Our standards often go above and beyond local requirements to protect people from forced labor risks.

- Aligning with international frameworks

Our policies and supplier requirements align with international labor and human rights standards, including those of the International Labour Organization (ILO), the United Nations Guiding Principles on Business and Human Rights (UNGPs), and the Organisation for Economic Cooperation and Development (OECD).

- The Apple Human Rights Policy

The Apple Human Rights Policy outlines how we treat everyone, including our customers, employees, suppliers, and people across each level of our supply chain.

- The Apple Supplier Code of Conduct (Code) and Supplier Responsibility Standards (Standards)

Apple's Code and Standards outline our strict requirements for responsible labor recruitment and apply to all suppliers, protecting workers globally. We go above and beyond legal requirements in many places by strictly prohibiting labor recruitment in regions where we cannot conduct adequate due diligence and by maintaining a zero fees policy, because we believe no one should pay to secure a job.

<!-- image -->

## We engage early.

To address forced labor risks at their roots, we know that our work has to begin before people enter our supply chain.

- Labor recruitment mapping informs our strategy

An effective strategy requires a deep understanding of our supply chain. In 2023, we mapped over 2,100 labor recruitment agencies that work with our suppliers across 40 countries and regions.

- A leading strategy requires leading tools

The Apple Responsible Labor Recruitment Due Diligence Toolkit (Recruitment Toolkit), developed in partnership with the International Organization for Migration (IOM), provides suppliers and their labor agencies with easy-to-use tools that help them effectively manage and report data, mitigating forced labor risks from the start of the employment journey. In addition to providing hands-on training, we are making these tools openly available for others to use.

## · Awareness is power

We require our suppliers to train their employees on their workplace rights to help raise their awareness about what to do if their rights are not being respected. Foreign Contract Workers, who make up a very small percentage of the people in our supply chain, also receive training, both prior to leaving their home country and upon arriving in their destination country. To date, our suppliers have provided workplace rights training to over 28 million people. And last year, we directly engaged with over 581,000 people in our supply chain to learn more about their workplace experience.

- Investing in continuous improvement

Through our Supplier Employee Development Fund (SEDF), we're investing /dollarsign50 million to expand programs designed to further improve the rightstraining experience, worker voice platforms, and supplier employee education opportunities.

Learn more about how we prevent forced labor in our supply chain during recruitment on page 20 .

<!-- image -->

## We hold suppliers accountable.

Once we've implemented thorough preventative measures, independent, thirdparty assessments verify that our suppliers are meeting our standards. Looking for evidence of forced labor is part of every supplier assessment we conduct. If we find any violations of our Code and Standards, we take swift action to remedy the issue and improve the supplier's operations.

## · A close look

We regularly conduct independent, third-party assessments, including surprise assessments, of our suppliers to verify compliance with over 500 criteria. This includes an extensive document review to confirm that all hiring and personnel records are in place and accurate. In addition to specialized forced labor assessments for at-risk suppliers, we also require many suppliers to participate in facility-wide assessments, such as the Responsible Business Alliance's (RBA) Validated Assessment Program (VAP), to verify performance across the supplier's entire business. If we find gaps in supplier compliance or capability, we require them to implement a Corrective Action Plan (CAP). Since 2007, our assessments have covered approximately 94 percent of our direct manufacturing spend.

- We investigate the reports we receive

In addition to thoroughly assessing our suppliers' performance in upholding our standards, we also receive reports from the press, governments, civil society, and people in our supply chain, and we encourage the public to report concerns via our public website . We investigate the reports we receive and frequently have Apple teams onsite within 24-48 hours.

- Swift action and remediation

Forced labor in any form is a Core Violation of our requirements.   If a Core Violation is discovered, the supplier's Chief Executive Officer (CEO) is notified, and the supplier is immediately placed on probation, pending the successful completion of a CAP. Probation can include receiving no new projects or new business and the termination of existing business with Apple. 10

- Action this year

In 2023, across more than 800 Code of Conduct assessments, we found no instances where anyone was forced to work in our supply chain. T o date, our suppliers have directly repaid /dollarsign34.5 million in recruitment fees to over 37,700 of their employees due to Apple's zero fees policy.

<!-- image -->

## We track progress and report transparently.

Consistent improvement requires transparency and accountability. Since 2007, we have been publishing reports on our efforts to transparently share our progress and challenges.

- [People and Environment in Our Supply Chain Progress Report](http://www.supplychainreports.apple/Apple-Supply-Chain-2024-Progress-Report)

Published annually since 2007, this report (formerly known as the Supplier Responsibility Progress Report) contains a detailed account of our progress, challenges, and future plans across all areas of our supplier requirements.

- [United Nations Guiding Principles on Business and Human Rights: 2024 Mapping of the Apple Supply Chain](http://www.supplychainreports.apple/Apple-UNGP-Mapping)

This document outlines the policies, processes, and programs for identifying, mitigating, and remedying salient human rights risks in our global supply chain.

- Disclosures on Efforts to Combat Human Trafficking and Slavery

These disclosures are specialized filings that focus specifically on our efforts to prevent and address forced labor risks throughout our supply chain. They include our due diligence process for our entire business, including manufacturing, materials and goods sourcing, and services. These reports also demonstrate our alignment with the UNGPs and meet regulatory requirements in Australia, California, Canada, Norway, and the United Kingdom (UK).

- Consistently raising the bar

We revisit all of our supplier requirements every year, consistently raising the bar that suppliers must meet in order to continue doing business with us, and publish the updates publicly.

## · Learn more

We publish additional reports that provide a transparent look at our supply chain. Our Conflict Minerals Report describes our work to responsibly source materials. Our Smelter and Refiner List is a list of all identified tin, tantalum, tungsten, gold (3TG), cobalt, and lithium smelters and refiners across our global supply chain, and the Apple Supplier List shares the companies and their locations that comprise at least 98 percent of our direct manufacturing spend.

<!-- image -->

## We regularly engage and partner with experts.

Engagement with stakeholders and rightsholders is necessary to hold ourselves accountable, take action where it's needed, and achieve rapid progress.

- The International Labour Organization

We work closely with the ILO on a number of projects, including those related to advancing worker rights and voice. Apple is a member of the ILO Global Business Network on Forced Labour and serves on the steering committee.

- The International Organization for Migration

Apple partners with IOM on multiple initiatives, including the development of and trainings on our Recruitment Toolkit.

- Responsible Business Alliance

Apple collaborates with the RBA and its member companies frequently throughout the year on initiatives spanning the entirety of the work we do across our supply chain. As a full member, we have served in several leadership capacities, including as a member of the Board of Directors (Board), a founding and former steering committee member of the Responsible Labor Initiative (RLI), and a member of the steering committee of the Responsible Minerals Initiative (RMI).

- Fund for Global Human Rights

Apple partners with the Fund for Global Human Rights (the Fund) to support grassroots activists as well as human rights and environmental defenders.

6

## Understanding assessment results

## Our 100-point scale for supplier assessment scores

<!-- image -->

## High performer

-  Mature management systems and consistent implementation
-  Minor and isolated Code violations

<!-- image -->

## Medium performer

-  Typically have some management systems in place but may be underdeveloped or implemented inconsistently
-  May have major, isolated Code Violations and/or numerous minor violations

<!-- image -->

## Low performer

-  Severely underdeveloped management systems
-  Major violations found across a number of Code categories
-  Any supplier found to have a Core Violation of our Code, whether during an assessment or at another time during the year, is automatically classified as a low performer

Our assessment process evaluates suppliers against more than 500 criteria to verify their performance and identify areas of improvement. Once assessed, each supplier facility is ranked on a 100-point scale across three categories: 1) labor and human rights, 2) health and safety, and 3) the environment. The average number of points received is the facility's composite score for the year, which determines if the supplier is designated as high-, medium-, or low-performing. These performance categories reflect both the frequency and severity of any issues found during the assessment process.

We utilize standard definitions for violations of our supplier requirements in order to consistently evaluate our suppliers' performance in upholding our standards.

## Administrative Noncompliance:

Denotes policy-, procedure-, training-, or communicationrelated findings.

Examples of administrative noncompliance include:

-  Inadequate record-keeping
-  Inadequate documentation of policy or procedures
-  Insufficient training on policy

## Violation:

Denotes noncompliance with our Code and Standards. Examples of violations include:

-  Insufficient provision of benefits
-  Inadequate pre-placement, on-job, or post-employment occupational health exams
-  Inadequate environmental permits

## Core Violation:

The most serious violation of our Code and Standards. When a Core Violation is identified, the supplier's Chief Executive Officer is notified, and the supplier is immediately placed on probation. Probation is the period beginning when a Core Violation is discovered by Apple and ending when Apple determines the supplier has completed all necessary corrective actions. Examples of consequences resulting from probation include receiving no new projects or new business and the termination of existing business with Apple.

Core Violations of our Code include:

-  Abuse
-  Underage labor
-  Debt-bonded labor
-  Forced labor
-  Falsification of data
-  Retaliation
-  Obstruction of an assessment
-  Bribery
-  Unsafe or unhealthy environment provided to workers that may cause imminent significant risk of serious injury, illness, property damage, or any form of loss
-  Defeated safety devices or impaired loss control system without additional controls to prevent serious incident
-  Inadequate maintenance or intentional circumvention that demonstrates the failure of an environmental abatement system
-  Lack of required environmental approvals or controls
-  Use of prohibited substances
-  Illegal disposal of hazardous waste

6

## Endnotes

## Forward-looking statements

The report is provided voluntarily, and does not cover all information about our business. References in this report to information should not be construed as a characterization regarding the materiality of such information to our financial results or for purposes of the U.S. securities, or any other, laws or requirements. While certain matters discussed in this report may be significant, any significance should not be read as necessarily rising to the level of materiality used for the purposes of complying with the U.S. federal securities, or other, laws and regulations. The information covered by the report contains forward-looking statements within the meaning of the Private Securities Litigation Reform Act of 1995, including statements regarding our environmental goals, or sustainability targets, commitments, and strategies and related business and stakeholder impacts. Forward-looking statements can be identified by words such as 'future,' 'anticipates,' 'believes,' 'estimates,' 'expects,' 'intends,' 'plans,' 'predicts,' 'will,' 'would,' 'could,' 'can,' 'may,' 'aim,' 'strive,' and similar terms. These statements involve risks and uncertainties, and actual results may differ materially from any future results expressed or implied by the forward-looking statements.

These risks and uncertainties include, without limitation, any failure to meet stated environmental or sustainability targets, goals, and commitments, and execute our strategies in the time frame expected or at all, global sociodemographic, political, and economic trends, changing government regulations, technological innovations, climate-related conditions and weather events, our ability to gather and verify data regarding environmental impacts, the compliance of various third parties, including our suppliers with our policies and procedures, or their commitments to us, and our expansion into new products, services, technologies, and geographic regions. More information on risks, uncertainties, and other potential factors that could affect our business and performance is included in our filings with the U.S. Securities and Exchange Commission, including in the 'Risk Factors' and 'Management's Discussion and Analysis of Financial Condition and Results of Operations' sections of the company's most recently filed periodic reports on Form 10-K and Form 10-Q and subsequent filings. Further, from time to time we engage in various initiatives (including voluntary disclosures, policies, and programs), but we cannot guarantee that these initiatives will have the desired effect. We assume no obligation, and expressly disclaim any duty (including in response to new or changed information) to update any forward-looking statements or information, which speak as of their respective dates. Readers should not place undue reliance on the forward-looking statements made in this report. Moreover, many of the assumptions, standards, metrics, and measurements used in preparing this report continue to evolve, are sourced from third parties, and/or are based on assumptions believed to be reasonable at the time of preparation, but should not be considered guarantees. Given the inherent uncertainty of the estimates, assumptions, and timelines contained in this report, we may not be able to anticipate whether, or the degree to which, we will be able to meet our plans, targets, or goals in advance.

- 1 Apple reports data about the recycled content of its products at different levels of fidelity, based on the level of independent data verification. The bulk of Apple's recycled content data is certified and thus verified by an independent third party. Less than 5 percent of the total mass shipped in Apple products in fiscal year 2023 (FY2023) contains recycled content that is either supplier verified, meaning it has been reported by the supplier and cross-checked by Apple, or supplier reported, meaning it has been reported by the supplier based on production and allocation values. In all cases, Apple defines recycled content in alignment with ISO 14021. We do not currently include industry-average recycled content, which may result in underreporting actual recycled content. Total recycled material shipped in products is driven by product material composition and total sales - as a result, this overall recycled or renewable content percentage may fluctuate based on the number and type of products sold each year.
- 2 We account for savings through this program on a fiscal-year basis, rather than a calendar year basis as reported in publications before fiscal year 2021 (FY2021).
- 3 These sites have been third-party verified by UL Solutions against the UL 2799 Zero Waste to Landfill Environmental Claim Validation Procedure (ECVP). UL Solutions requires at least 90 percent diversion through methods other than waste-to-energy to achieve Zero Waste to Landfill (Silver: 90-94 percent, Gold: 95-99 percent, and Platinum: 100 percent) designations.
- 4 Apple reports 3TG smelter and refiner assessment information on a calendar year per U.S. Securities and Exchange Commission (SEC) requirements. See our annual Conflict Minerals Report by visiting our public website .
- 5   We plan to reach carbon neutrality beginning with our fiscal year 2030 (FY2030) carbon footprint.
- 6   Apple's commitment is to use 100 percent recycled cobalt, on a mass balance-system basis, in all Apple-designed batteries by 2025. We calculate our use of recycled cobalt on a mass balancesystem basis at the end of each fiscal year.
- 7 Apple's commitment is to use 100 percent recycled rare earth elements in all magnets by 2025.
- 8   Apple's commitment is to use 100 percent recycled tin soldering and gold plating in all Apple-designed rigid and flexible printed circuit boards by 2025.
- 9   Supplier assessment scores are reflective of a supplier's performance at the time of assessment. If violations are discovered through other engagements or reports, suppliers are required to follow standard remediation processes, including Corrective Action Plans, Corrective Action Verifications, and undergoing additional assessments as needed. Beginning in fiscal year 2022 (FY2022), any supplier found to have a Core Violation of our Code, whether during or outside of an assessment, is automatically classified as a low performer for the year, requiring them to complete additional capability-building programs and undergo additional assessments. Learn more about how we score assessments and categorize supplier performance on page 59 .
- 10  Core Violations are the most serious level of violation of our Code and Standards. Learn more about Core Violations on page 59 .
- 11   In Apple's 2022 Environmental Progress Report, covering FY2021, we stated that the 14 priority materials account for 90 percent of the total product mass shipped. For FY2022, Apple improved its internal data models, resulting in an increase in the total product mass shipped, thereby reducing the coverage of our priority materials to 87 percent of the total product mass shipped. In FY2023, Apple included titanium to the priority materials list, which, in total, account for 87 percent of the total product mass shipped.
- 12   All cobalt content references are on a mass balance system basis.

## A relentless focus on better.

Continuous improvement is in Apple's DNA, and our work to uphold the highest standards across our global supply chain is no exception.

We believe that business can and should be an innovative force for good. By upholding our values everywhere that our business reaches, we strive to prove this to be true and share what we've learned with others, so that everyone moves forward, faster.

Our work continues.

61

<!-- image -->