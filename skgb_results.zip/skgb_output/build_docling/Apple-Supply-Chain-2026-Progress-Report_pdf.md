## People and Environment in Our Supply Chain

2026 Annual Update

## People come first.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## A letter from Sabih Khan

<!-- image -->

At Apple, our values inspire every innovation we share - from the final product, to the work it takes to get it into our customers' hands.

We put those values into practice with the Apple Supplier Code of Conduct. From the very beginning, its high standards have served as the foundation of our deep commitment to the people, communities, and environment across our global supply chain. And at every step, we've raised the bar for ourselves and our suppliers.

This work begins with our commitment to the people across our supply chain. Now in its fifth year, our $50 million Supplier Employee Development Fund continues to deliver opportunities for our suppliers' employees to learn and grow. The Fund's work builds on education programs that have been running since 2008, which have benefited more than 10 million people.

Participants in these programs are gaining critical skills in areas such as robotics, automation, and leadership, preparing them for advanced manufacturing jobs across our supply chain. Last year, as part of our $600 billion commitment to expand manufacturing and innovation in the United States, we opened an Apple Education Hub in Detroit, providing a space for suppliers to engage in hands-on technical and professional learning opportunities. And we continue to expand all of our educational offerings to supplier sites across the United States, including at the new factory in Houston that is supporting production of advanced Apple servers.

Our commitment to people is also reflected in our efforts to build a supply chain where people understand their rights and are treated with dignity and respect. Since this work began, we've trained more than 33 million people on their workplace rights, and continue to invest in dynamic online learning platforms that allow workers to receive this training directly on their mobile devices.

But training is only the beginning. We are committed to workers' voices being heard and valued, while driving co-created solutions. Last year, we engaged directly with more than 655,000 supplier employees through interviews and anonymous surveys. That feedback drove our suppliers to make thousands of enhancements to their facilities, workplaces, and employee services.

Just as we are committed to supporting the people who make our products, we are equally dedicated to protecting the planet we all share. Since 2015, we've reduced emissions across our value chain by more than 60 percent, even as our business has grown. And in 2025, we reached important milestones toward our goal to one day make our products using only recycled or renewable materials: using 100 percent recycled cobalt in all Apple-designed batteries, 100 percent recycled rare earth elements in all magnets, and 100 percent recycled tin soldering and gold plating in all Apple-designed printed circuit boards. As we make progress toward these ambitious goals, we will continue to do this work in a way that respects the dignity of people at every level of our supply chain.

While we are proud of the progress we have made, we know that there will always be more for us to do. This work comes with complex challenges, but we approach them with relentless optimism, a collaborative spirit, and a deep commitment to people, communities, and the planet we share.

## Sabih Khan

Chief Operating Officer

<!-- image -->

## By the numbers: Progress across our supply chain

<!-- image -->

## Labor and human rights

## 33M+

supplier employees trained on their workplace rights since 2008

## 655K+

supplier employees engaged about their workplace experience through interviews and anonymous surveys

## $34.5M+

in recruitment fees paid back by suppliers to more than 37,700 supplier employees since 2008 as a result of Apple's zero-fees policy

## 1.4M+

supplier employees whose working hours were reviewed weekly to verify they do not work over 60 hours per week (including overtime), and have at least one day off every seven days

## 50+

human rights and environmental defenders and organizations supported by Apple

<!-- image -->

## Health, safety, and education

## 10M+

supplier employees that have participated in technical training, professional development, and enrichment courses since 2008

## 9M+

education and training sessions delivered as part of the Supplier Employee Development Fund since launching in 2022

## 8M+

supplier employees reached by our health and wellness education programs since 2017

## 49K+

supplier employees reached by our Vocational Education for Persons with Disabilities program since 2022, including more than 12,000 that were offered employment as a result

## 108K+

participants in Apple's Swift coding program since 2017; five apps developed and launched by supplier employees on the App Store in 2025

<!-- image -->

## Supply chain accountability

## 1,856

assessments and audits of our supply chain conducted, with sites selected based on factors such as worker sentiment and previous audit performance

## 155

new or expanding supplier facilities assessed for compliance with our strict labor, human rights, and environmental standards prior to entering our supply chain

## 25

manufacturing supplier facilities removed from our supply chain since 2009 for failing to meet our standards

<!-- image -->

## Responsible materials sourcing

## 230

audits of smelters, refiners, and materials processors conducted 1

## 100%

of identified tin, tantalum, tungsten, and gold (3TG) smelters and refiners complied with our requirement to complete third-party audits. Cobalt and lithium smelters and refiners also maintained 100 percent compliance.

## 232

smelters and refiners removed from our supply chain since 2009 for failing to meet our standards²

## 85+

recycling supplier facilities assessed through third-party audits for compliance with our health and safety standards

<!-- image -->

## Environment

## 20+

gigawatts of renewable energy procured by suppliers in our Supplier Clean Energy Program in 2025

## 60%+

reduction in global greenhouse gas emissions, compared with 2015 baseline

## 30%

of materials, by weight, used in our products came from recycled or renewable sources³

## 100B+

gallons of water saved by suppliers in our Clean Water Program since 2013, achieving an average reuse rate of 43 percent

## 230+

supplier facilities were zero waste-assured,4 with more than 400 supplier facilities participating in our Zero Waste Program across 15 countries and regions

<!-- image -->

## Upholding Apple values across our supply chain

People come first. Our values inform how we do business from the technology we make to the way we make it.

We drive high standards across our supply chain in the areas of labor and human rights, health and safety, environment, responsible materials sourcing, community and rights-holder engagement, and business conduct - and we hold ourselves and our suppliers accountable. And as our business evolves, we continue to raise the bar.

Our focus in 2025 →

[To learn more about our work, read our United Nations Guiding Principles on Business and Human Rights Mapping of the Apple Supply Chain.](http://www.supplychainreports.apple/Apple-UNGP-Mapping)

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## The Apple supply chain

Our global supply chain includes everything that goes into designing, building, delivering, supporting, and recycling Apple products and services.

This includes our manufacturing and recycling partners; the companies providing primary materials to our suppliers; as well as those supporting our logistics, content and support services, and retail operations. Across our products' lifecycles, suppliers are part of supporting our business nearly every step of the way.

We set high standards for all of our suppliers in order to safeguard the rights, dignity, and safety of people working across our supply chain, and the environment in communities where our suppliers operate. Suppliers are required to uphold these standards in order to do business with Apple, regardless of the work they do or where they operate.

## Design and source

We design our products to last, including more recycled and renewable materials, and making those products easier to recycle at the end of their useful life. All materials, whether recycled or not, must come from sources that meet our strict standards.

## Make

Suppliers help us build parts that are combined to create critical components, such as displays, batteries, and chips. These components are assembled to become Apple products.

## Package and ship

Suppliers help us to deliver finished Apple products all over the world, including to our retail stores and directly to our customers.

## Use

Suppliers help deliver Apple services like Apple One and AppleCare, from technical infrastructure to customer support.

## Recover

With support from recycling suppliers, we recover products and innovate solutions to maximize recovery of priority materials. We also share what we learn with the industry to help drive progress.

<!-- image -->

## The Apple Supplier Employee Development Fund

In 2022, we launched our $50 million Apple Supplier Employee Development Fund (SEDF). SEDF was created to deepen our investment in the people in our supply chain by strengthening and scaling worldclass worker rights training, worker voice platforms, and education opportunities to more supplier employees and their communities.

As we enter the fund's fifth year, SEDF has become a global community of more than 20 strategic partners working together to:

- Deliver customized training and resources to people in order to safeguard their rights and dignity.
- Create employment opportunities in our supply chain by making jobs and workplaces more accessible and inclusive for all people.
- Provide access to educational opportunities that support personal and professional development for our suppliers' employees.

We're proud of the progress we've achieved and the community we've cultivated through SEDF. Together, we're unlocking new opportunities for the millions of people reached by our supply chain.

## Empowering people through rights awareness and resources

Informed workers are empowered workers. We're continuing to invest in highly customizable rights training resources to be used by workers and communities across - and beyond - our supply chain. This includes digital rights training platforms that deliver world-class learning experiences to supplier employees, directly on their mobile devices.

Last year, we partnered with the International Organization for Migration (IOM) to deploy a new kind of resource, designed to meet workers where they are. Mobile Worker Resource Centers are heavily customized vans that deliver training, information, and critical resources to new employees navigating jobs in new places. The resource centers provide support on issues ranging from obtaining government-issued IDs to guidance on local public transportation, and other topics - all with the goal of creating a smooth onboarding experience with respect for rights at the center.

Last year, we also worked with partners to expand the availability of training and capability building for both suppliers and their employees on critical health and safety topics, including machine and chemical safety. We are developing additional tools, standards, and resources to enable adoption of safer chemicals in our supply chain, as well as across the industry, with the goal of continuing to minimize workers' potential exposure to chemical hazards.

## Unlocking opportunities for supplier employees through education

Expanding access to education gives everyone more ways to realize their potential. Through hands-on and virtual experiences offered through our Apple Education Hubs, we're helping supplier employees gain skills that can help them grow personally and professionally - wherever their work takes them.

Across the United States, China mainland, India, and Vietnam, we're providing a wide variety of programs in highly soughtafter technical and professional skills. These include computer science, advanced manufacturing fundamentals, automation equipment maintenance, and Lean Six Sigma, a methodology for improving operational efficiency and quality. Our most popular courses continue to be those offered through our Swift coding program, with more than 108,000 supplier employees participating since 2017. Many participants go on to develop apps that independently meet the high standards to be published on the Apple App Store, with five apps developed and launched by supplier employees in 2025.

We're also working to increase access to employment and professional development opportunities in Apple's supply chain, and to cultivate more accessible and inclusive workplaces, through our Vocational Education for Persons with Disabilities program. To date, more than 49,000 supplier employees have participated in this program across the United States, China mainland, India, and Vietnam.

## Partnerships that accelerate progress

At the center of SEDF is a global community of worldclass partners. From education and worker rights training organizations to mineral sourcing, human rights, and migration experts, these partners are leveraging their unique resources and expertise to scale the impact of SEDF's work to people around the world. See page 22 to learn more about the partners that are helping us to deliver on SEDF's goals around the world.

This includes looking beyond our supplier facilities to support labor and human rights standards, as well as communities across our supply chain. In 2025, through our partnership with the Fund for Global Human Rights, we funded 28 grantees working in five countries on issues ranging from social rights and rule of law, to inclusive economic growth and environmental justice. In partnership with Thomson Reuters Foundation, we continue to support TrustLaw, which provides legal support, research, training, tools, and resources for NGOs and social enterprises advancing social change.

<!-- image -->

## Expanding education opportunities in the United States

In 2025, we announced a $600 billion commitment to accelerate investments in the United States. This included the launch of a new Apple Manufacturing Academy in Detroit, in partnership with Michigan State University, to help bolster manufacturing capability and capacity. The Academy, which to date has benefited more than 140 small- to medium-sized U.S. companies, offers free training and support to American companies on implementing artificial intelligence (AI) and smart manufacturing techniques.

As part of this commitment, we launched a U.S. Apple Education Hub, also in Detroit. This includes a physical space, as well as virtual programming, designed to provide American workers with the skills necessary to succeed in advanced manufacturing jobs.

Our Vocational Education for Persons with Disabilities program also expanded to the United States in 2025, supporting American suppliers in cultivating new talent pipelines and helping create more accessible, inclusive, and productive workplaces for all supplier employees. Last year, select U.S. manufacturing, repair, and recycling suppliers employing more than 1,000 workers, commissioned third-party assessments to evaluate the accessibility of their facilities for people who may need additional support working in a manufacturing environment.

These assessments looked at the physical layout of the facilities - including production lines and shared spaces, such as restrooms and break rooms - and the suppliers' hiring practices. They also evaluated the resources and support available to their teams, such as employee resource groups. The assessments have provided initial action plans for our suppliers to follow as they launch the program at their facilities, and are also providing us with valuable feedback and best practices as we expand the program to additional sites in the United States in the coming year.

The United States has long been critical to the success of our business and our supply chain. We remain committed to providing opportunities for growth and development to the people across the country that help us build, deliver, and support Apple products.

<!-- image -->

<!-- image -->

## Protecting the planet we all share

## At Apple, we're acting with urgency to protect our shared resources, demonstrate leadership, and create an example for others to follow.

## Apple 2030

We're committed to our ambitious, science-based Apple 2030 goal to become carbon neutral across our value chain. Our aim is to reduce our greenhouse gas emissions by 75 percent compared with 2015, before balancing the remaining emissions with carbon credits that adhere to rigorous international standards.⁵ We're on our way, having reduced emissions by more than 60 percent since 2015, even as our revenue has grown by 78 percent in that same time.

We also continue to increase our use of recycled and renewable materials, as these materials are typically less carbon-intensive than their primary alternatives. This helps us achieve progress toward our 2030 carbon neutrality goal, as well as our ambition to one day make all of our products using only recycled or renewable materials.

## Supply chain decarbonization

Reaching Apple 2030 means we must significantly reduce emissions across our many manufacturing processes. This includes improving energy efficiency, increasing the use of clean electricity, and addressing direct emissions through abatement.

Through targeted programs, such as our Supplier Energy Efficiency Program and Supplier Clean Energy Program, we're working to make our supplier facilities as energy-efficient as possible and transitioning our entire supply chain to 100 percent renewable energy. The Apple Supplier Code of Conduct (Code) and Supplier Responsibility Standards (Standards) require our entire direct manufacturing supply chain to use 100 percent renewable electricity for their Apple production by 2030. We've seen significant progress toward this goal, and many suppliers have gone beyond the requirement for Apple production to power entire facilities with renewable energy.

## Circularity and recycling

We're working toward a future where every Apple product will be created from, and contribute to, circular supply chains. This includes sourcing recycled and renewable materials, designing long-lasting and durable products, and developing recycling innovations to improve how we recover materials at the end of a product's useful life. Circularity helps unlock the potential of the materials in our products so that they can be used again and again, making the best use of finite resources.

Last year, we achieved significant progress toward this effort. As of the end of the 2025 calendar year, all Apple-designed batteries are now using 100 percent recycled cobalt; all magnets in Apple products are using 100 percent recycled rare earth elements; and all Apple-designed printed circuit boards are using 100 percent recycled tin soldering and gold plating.6 We also achieved our commitment to remove plastic from our product packaging, instead leveraging fiber-based alternatives.7

<!-- image -->

<!-- image -->

Innovation is central to realizing the potential of recycling - not just for Apple products but throughout our industry. Our Material Recovery Lab (MRL) in Austin, T exas, is home to Daisy, our iPhone disassembly robot, as well as a lab where we develop and operationalize new recycling technologies and processes that maximize the recovery of key materials. The techniques developed at the MRL are designed to be used at scale in our partners' recycling and material processing centers around the world.

We also operate an Advanced Recovery Center (ARC) in Santa Clara Valley, California, and work with recyclers to expand the use of advanced technologies to efficiently recover high-quality materials, while prioritizing our high environmental and safety standards. By designing market-ready solutions, working with recycling equipment manufacturers to implement them, and demonstrating the effectiveness of these solutions in our own facilities, we're helping to scale access to innovative solutions for the broader recycling industry.

## Zero waste

We're committed to eliminating waste at every stage of the product life cycle, from the time a product is designed and manufactured to when it's ultimately recycled.

Through our Zero Waste Program, suppliers are required to implement a plan for identifying waste, develop a method for quantifying and monitoring their landfill diversion rate, set waste reduction goals, and maintain progress toward sending zero waste to landfill. Starting with only a single facility more than a decade ago, our Zero Waste Program has expanded to more than 400 of our supplier facilities around the world, with many of our largest suppliers implementing these activities beyond Apple production lines and eliminating waste across their entire operation.

We also support our suppliers in verifying their zero waste efforts, including through UL Solutions, a leading testing, inspection, and certification body. UL Solutions requires at least 90 percent diversion of waste through methods other than waste-to-energy in order to achieve zero waste status according to its criteria. In 2025, UL Solutions looked at 230 of our supplier facilities - including all final assembly sites for major Apple products - to verify they met its UL 2799 criteria.4 Achieving this level of performance across our supply chain requires innovative new materials and recycling strategies, as well as collaboration with external partners to address today's infrastructure and technology challenges in waste reduction.

## Water

Access to clean, safe water is a basic human right. Our supply chain accounts for 99 percent of Apple's total water footprint, and we're taking action with our suppliers to help protect and preserve communities' access to potable water, particularly in water-stressed areas.

Our industry-leading Clean Water Program helps our suppliers become stewards of the water resources where they operate by conserving water, promoting reuse, and preventing pollution within our supply chain.

We also work with external partners to understand local water needs, improve the sustainability of local water resources, and promote responsible water stewardship across social, cultural, environmental, and economic criteria. Together with our partners, we're providing our suppliers and the broader industry with tools and resources to help address water use more holistically, creating positive impact across supplier facilities and the water basins where they operate.

## Smarter chemistry

The safety of the people in our supply chain, our customers, and the planet is our top priority. This starts by establishing requirements for our suppliers that meet, and often exceed, industry standards through our Regulated Substances Specification (RSS). We also collect detailed information about suppliers' usage and handling of chemicals in their facilities through our Full Material Disclosure (FMD) and Chemical Safety Disclosure (CSD) programs.

Our approach to protecting the health and safety of our suppliers' employees follows the hierarchy of controls, meaning we prioritize the elimination and substitution of hazardous materials, wherever possible. When no alternative is available to eliminate potential exposure, we work to verify suppliers have strong engineering and administrative controls in place to protect the health and safety of their employees and the environment where their facilities operate.

This includes working with partners across the industry to develop tools, standards, and resources to help our suppliers select safer chemicals from the start to use in our products and manufacturing processes. As we drive suppliers to shift their approach to safer alternatives, they are also applying their capabilities to operations beyond Apple's supply chain. For instance, many final product assembly suppliers, in making changes to meet our safer cleaners requirement, have applied these changes to improve their facilities' overall chemical management systems. This includes applying these standards to new materials our suppliers use outside of Apple production.

- Ꮹ Our approach to environmental stewardship takes into consideration our entire business, including our corporate operations and supply chain. In addition to this brief summary of our supply chain environmental programs, a comprehensive review of Apple's broader environmental strategy and progress can be found in our 2026 Environmental Progress Report and on our Environment website.

<!-- image -->

## Innovation leading the way to a circular supply chain

## Achieving progress toward one day building our products using only recycled or renewable materials requires innovative solutions at every level of our supply chain.

For many years, we have invested heavily in developing, testing, and deploying cutting-edge technologies to address industry-wide recycling challenges. At our dedicated Material Recovery Lab (MRL) in Austin, T exas, and our Advanced Recovery Center (ARC) in Santa Clara Valley, California, we conceptualize and design solutions to improve the safe and efficient recovery of critical materials. This includes automated solutions, such as our disassembly robots Daisy, Dave, and T az, which maximize the recovery of materials from electronic products while minimizing waste; as well as autonomous mobile robots (AMRs) that help transport products and components around these facilities to increase operational efficiency. This also includes innovations like augmented-reality powered disassembly stations that assist workers in safely and efficiently disassembling Apple products.

In 2025, we deployed our latest advancements in recycling technology with Cora, a new e-waste processing line designed to achieve higher material recovery rates than industry baselines - and to operate at high safety and environmental standards. What sets Cora's design apart is its utilization of readily available equipment, as well as novel applications of existing advanced sensors and sorters. This unique design allows Cora to perform precision material recovery, identifying materials down to their atomic composition, in some cases. Cora's smaller, more costeffective footprint is also part of our broader effort to develop industry-deployable approaches that address electronics recycling challenges.

We are also making investments and working with partners to develop solutions to increase the availability of recycled content. For nearly five years, we have worked with the American company MP Materials to pilot advanced recycling technology to improve the quantity and quality of recycled rare earth elements, which are critical for building magnets and other electronic components. Building on this work, in 2025, we announced a $500 million longterm agreement with MP Materials to source these recycled rare earth elements for use in Apple products. As part of the agreement, MP Materials will construct a commercial-scale, dedicated recycling line in Mountain Pass, California, which will be able to process recycled rare earths from a range of inputs, including magnet scrap and components recovered from end-of-life products.

From innovative technology solutions to strategic partnerships and investments, we're leveraging a wide variety of tools to accelerate the market for recycled materials and create a circular supply chain.

<!-- image -->

12

<!-- image -->

## How we work with suppliers

We design our products in California and work with a global network of suppliers to bring them to life. Our supply chain spans more than 60 countries and regions, with millions of people and thousands of innovative businesses working together to build the best products and services.

This section contains select overviews of the fundamental approaches and programs we have refined over many years as we work to safeguard and support the people and places that are part of our supply chain.

For more detail on all of these programs, as well as our comprehensive strategy for identifying and addressing salient risks in our supply chain, please read the United Nations Guiding Principles on Business and Human Rights Mapping of the Apple Supply Chain.

<!-- image -->

<!-- image -->

## High standards. Applied everywhere.

The Apple Supplier Code of Conduct (Code) and Supplier Responsibility Standards (Standards) outline the requirements to which our suppliers must contractually adhere to in order to do business with Apple.

These include requirements on labor and human rights, health and safety, environment, responsible materials sourcing, community and rights-holder engagement, and business conduct. For 20 years, the Code and Standards have been regularly evaluated and updated, published on our website, and communicated to our suppliers in many languages.

In 2025, we took significant steps to strengthen our Code and Standards to meet the evolving nature of our business, and to continue to increase our support for people and the planet throughout our global supply chain.

- [Ꮹ Read the Apple Supplier Code of Conduct and Supplier Responsibility Standards.](http://www.supplychainreports.apple/Supplier-Code-of-Conduct-and-Supplier-Responsibility-Standards)

<!-- image -->

## How we hold suppliers accountable

Our global supply chain includes thousands of businesses spanning over 60 countries and regions, and millions of people all over the world. We work to hold our suppliers accountable to our strict Code and Standards through continuous engagement at every stage of our business relationship.

## 33M+

supplier employees trained on their workplace rights since 2008

## 655K+

supplier employees engaged about their workplace experience through interviews and anonymous surveys

## 1,856

assessments and audits of our supply chain conducted, with sites selected based on factors such as worker sentiment and previous audit performance

## We engage early.

Before we award business to a supplier, or begin production, we check to verify that our strict supplier requirements can be met. Once business is awarded, we provide training and guidance to new suppliers to help them make any necessary improvements in order to meet our requirements prior to work beginning.

## We monitor and support suppliers during peak production.

As suppliers prepare to enter their busiest production periods, we work to verify they are upholding our labor and human rights standards, including limits on working hours, timely payment of wages, and providing proper training. We do this through onsite visits and by collecting worker feedback. In 2025, we conducted 579 onsite visits and 10,300 worker interviews at more than 70 supplier facilities as they ramped up production.

## We listen to people in our supply chain.

We review anonymized worker sentiment, including concerns raised through grievance mechanisms, to identify emerging issues and address any worker concerns. We also proactively collect feedback from workers through interviews and anonymous workplace satisfaction surveys. In 2025, we leveraged AI-powered tools to conduct weekly reviews of anonymized worker sentiment across more than 140 priority supplier facilities, and engaged directly with more than 655,000 supplier employees.

## We monitor working hours.

We restrict the workweek for supplier employees to 60 hours (including overtime, which must be voluntary) and require at least one day off every seven days. Any exceptions to this policy require prior authorization from Apple management and must meet strict requirements. To hold suppliers accountable to this high standard, we review suppliers' data on employee working hours throughout the year as part of our assessments, with key suppliers required to report on a weekly basis. In 2025, we received weekly data on working hours for more than 1.4 million workers in our supply chain.

## We assess our suppliers' performance.

We evaluate our suppliers' compliance each year against more than 500 criteria - covering labor and human rights, health and safety, environment, responsible materials sourcing, community and rights-holder engagement, and business conduct. These assessments are conducted globally by internationally accredited third-party auditing firms. Each assessment includes management and employee interviews, extensive document reviews, and site walk-throughs. In addition, some suppliers may receive supplemental audits focused on one or more specific issues. Many of the assessments and visits we conduct each year at supplier facilities are unannounced. In 2025, 895 assessments that focused on the requirements of our Code and Standards were conducted, including 216 unannounced assessments.

## We engage in third-party industry assessments.

We require many of our suppliers to undergo an additional, facility-wide, third-party assessment widely used by the industry, known as the Responsible Business Alliance's Validated Assessment Program (VAP). VAP assessments evaluate Apple production lines, but also look beyond to ensure a facility's operations are consistent with internationally accepted standards - even in spaces where they are not making Apple products. In 2025, more than 100 VAP assessments were completed at Apple supplier sites.

issue from reoccurring. We also require that suppliers address any impacts these violations may have on their employees. For the most serious violations (what we call Core Violations), we contact the supplier's Chief Executive Officer (CEO) and immediately place the supplier on probation until all corrective actions have been taken. This can result in a supplier receiving no new projects or new business from Apple, or even the termination of existing business. Removing a company from our supply chain, however, is considered a last resort, as it may limit the ability of workers to seek recourse and could allow violations to continue.

## We investigate the reports we receive.

In addition to thoroughly assessing our suppliers' performance in upholding our standards, we also receive reports from the press, governments, civil society, and people in our supply chain. We also encourage the public to report concerns via our public website. In addition to responding to feedback from supplier employees, we promptly investigate any allegations we receive. When necessary, Apple experts are typically onsite within 24-48 hours.

We correct violations and require remedy to affected workers. If a violation of our standards is discovered, we require suppliers to promptly implement a plan to correct it - checking in with Apple every 30 days - and to strengthen their operations to prevent the

## We increase awareness and build capabilities.

To prevent issues from happening in the first place, we work with suppliers to support their continued growth and improvement. Through online and in-person training, as well as customized

## How we safeguard against assessment interference

We take extensive steps to ensure our Code of Conduct assessment process is thorough, professional, and carried out with integrity, transparency, and sensitivity for the well-being of supplier employees.

- All Code of Conduct assessments are conducted by third-party auditing firms that are accredited to meet international auditing standards. Many of the firms that conduct our assessments are also certified to meet the standards of the Responsible Business Alliance. Apple employees are often present for assessments to support auditors and verify that our protocol is followed.
- Suppliers cannot have operations in, recruit labor directly or indirectly from, or source materials, products, or services directly or indirectly from regions where Apple and third parties cannot access and conduct comprehensive evaluations of the supplier's compliance with our Code and Standards.
- We prohibit interference of any kind in our assessment process, and require that interviews conducted as part of assessments take place in confidential places with no managers or

cameras present. Apple partners with auditing firms that provide local auditors with native language capabilities to eliminate any language barriers between the supplier employee and the auditor.

- Retaliation in any form is a Core Violation of our Code and Standards. Last year, more than 42,000 follow-up phone calls were made to verify that supplier employees who participated in interviews did not experience retaliation as a result.
- We provide anonymous reporting channels where supplier employees can contact Apple directly, accessible at any time and in any language, should they experience retaliation or have other concerns about their workplace experience.
- In 2025, auditors did not report any experiences of interference from supplier management, local officials, or any other entities.

guidance from subject matter experts, we help increase awareness and capabilities related to new requirements, emerging risks, and gaps we've identified. This includes taking into context geographicand operational-specific risks, such as machine and fire safety for higher risk processes, and transportation safety in locations where more people utilize supplier-provided transportation.

## We hold suppliers accountable deeper in our supply chain.

Our suppliers are required to confirm their suppliers' operations are complying with our high standards, and any applicable laws and regulations. We regularly evaluate and verify that our suppliers are conducting their due diligence, review their audit reports to spot-check findings, and verify that they have corrected any compliance issues. If we receive an allegation about a supplier deeper in our supply chain, we work with our suppliers to investigate and correct any findings.

- Ꮹ Learn more about supplier performance in 2025 on page 16.

## Supplier performance in 2025

We work closely with our suppliers to prevent violations of our standards, but if they do occur, we take prompt action to address the violations and support affected workers. Findings can range from administrative noncompliance, such as inadequate record-keeping, to more severe issues, which we call Core Violations, which result in immediate and serious consequences for the involved supplier, up to and including ending our business relationship.

Due to consistent engagement with our suppliers, Core Violations are becoming less frequent, with three facilities found to have Core Violations in 2025.

This included two instances of working hours falsification, after which the suppliers involved were placed on probation and required to remediate the cause of the violations. We also had a finding deeper in our manufacturing supply chain. A sub-tier product enclosure vendor (our supplier's supplier) failed to meet the local working age requirement for two individuals, relatives of a long-term employee at the site, who were a few months short of the local age requirement of 16. The violation was discovered during a facility readiness audit conducted before production began and was immediately corrected and remediated. Per our strict process, the two individuals were immediately escorted back home, paid all due wages, and enrolled in school. As part of the remediation process, their monthly living and education expenses were paid by our supplier, and an independent third-party organization was engaged to facilitate the remediation process and to regularly monitor their academic and living conditions through calls, and school and home visits. In line with our Core Violation process, we also notified our supplier's executive leadership immediately and placed the supplier on probation. We worked with both our supplier and the sub-tier vendor to identify the root cause of the issue and develop a Corrective Action Plan to remediate the incident and prevent a reoccurrence. This included requiring our supplier to send a communication to all of their sub-tier vendors articulating the consequences of failing to meet working age requirements; to conduct a training on hiring standards with their managers; and to develop a work plan for improving their hiring management systems. In addition, our supplier received a significant financial penalty from Apple, and ended their relationship with the sub-tier vendor after appropriate remediation occurred.

As a result of increasing our threshold for strong supplier performance, in 2025, we saw a slight decrease in the number of suppliers achieving highperformer status.

Learn more about our assessment process and how we address violations of our standards on page 15.

<!-- image -->

## How we uphold the strongest standards in hiring

Our teams of experts, including accredited third-party auditors, use industry-leading procedures to verify that no one is forced to work. This work starts before we sign a contract with a supplier, and is focused on confirming that people's rights are respected throughout their entire employment journey.

## We set high standards.

The policies and standards that govern our approach to preventing forced labor in our supply chain include the Apple Human Rights Policy, and our Apple Supplier Code of Conduct (Code) and Supplier Responsibility Standards (Standards).

## Aligned with international human rights frameworks.

The requirements outlined in our Code and Standards align with internationally recognized human rights frameworks and standards, including those of the International Labour Organization's (ILO) Declaration on Fundamental Principles and Rights at Work, the United Nations Guiding Principles on Business and Human Rights (UNGPs), and the Organisation for Economic Co-operation and Development's (OECD) Guidelines for Multinational Enterprises on Responsible Business Conduct.

## Applied universally.

Our strict requirements apply to all suppliers, and are designed to protect workers globally regardless of their job, location, or how they were hired.

## Above and beyond legal requirements.

We go above and beyond legal requirements, including strictly prohibiting the payment of recruitment fees, and the recruitment of labor in regions where we cannot conduct adequate due diligence.

## Constantly evolving.

We revisit our supplier requirements regularly, consistently raising the bar that suppliers must meet in order to continue doing business with us, and we publish the updates to these requirements publicly.

<!-- image -->

## We engage early and often.

To address forced labor risks at their roots, our efforts begin before workers enter our supply chain, and include direct and ongoing engagement with actors all along the labor recruitment journey.

## We map our supply chain.

Our work begins by using data to identify how and where workers are recruited. This includes mapping high-risk migration corridors, as well as the labor agencies being used globally by our suppliers to hire workers. Since 2020, we've mapped 3,800 labor agencies back to our suppliers.

## We develop tools for better due diligence.

The Apple Responsible Labor Recruitment Due Diligence Toolkit (Recruitment Toolkit), developed in partnership with the International Organization for Migration (IOM), the United Nations' agency for migration, gives suppliers and their labor agencies easy-to-use tools to manage and report data, mitigating forced labor risks from the start of the employment journey.

## We directly engage workers.

All supplier employees are required to receive training on their workplace rights. Foreign Contract Workers - people who travel between countries to work - are required to receive pre-departure training in their country of origin, onboarding training upon arrival in their destination country, as well as regular refresher training. Since 2008, more than 33 million people have been trained by our suppliers on their workplace rights. In 2025, we also directly engaged more than 655,000 supplier employees on their workplace experience through anonymous surveys and confidential interviews.

## We train suppliers and labor agencies.

Engaging directly with our suppliers and their labor agencies - many of which are small- or medium-sized businesses is a unique and critical part of our work. We train our suppliers and their labor agencies on the Recruitment Toolkit through customized training delivered in partnership with IOM.

<!-- image -->

## Holding suppliers accountable.

Once we've implemented thorough preventative measures, assessments are conducted by accredited third-party auditors (including unannounced assessments) to verify that suppliers are meeting our standards. Looking for evidence of forced labor is part of every supplier assessment. If we find any violations of our Code and Standards, we take swift action to correct the issue, improve the supplier's operations, and support affected workers.

## We conduct thorough assessments.

Our assessments include an extensive document review to confirm that hiring and personnel records are in place and accurate. In addition to specialized forced labor assessments, we also require many suppliers to participate in facility-wide assessments, such as the Responsible Business Alliance's Validated Assessment Program (VAP). If we find gaps in a supplier's compliance or capabilities, we require them to implement a Corrective Action Plan (CAP).

## We investigate any concerns, from anywhere.

In addition to thoroughly assessing our suppliers' compliance with our standards, we also investigate any allegations we receive from the press, governments, civil society, people in our supply chain, and the general public. When necessary, Apple teams are typically onsite within 24-48 hours of receiving any allegations.

## We take swift action and remediation.

Forced labor in any form is a Core Violation (the most serious level of violation) of our supplier requirements. If a Core Violation is discovered, the supplier's CEO is notified, and the supplier is immediately placed on probation, pending the successful completion of a CAP. Probation can include receiving no new projects or new business and the termination of existing business with Apple.

## We measure our progress.

In 2025, we looked for indicators of forced labor as defined by the International Labour Organization across 895 Code of Conduct assessments, and found no instances in our supply chain where people were forced to work.

<!-- image -->

## Regularly engaging and partnering with experts.

We work closely with expert stakeholders and rightsholders to prevent forced labor in our supply chain, and to advance responsible labor recruitment practices across the industry.

## The International Labour Organization (ILO)

We work closely with the ILO on a number of projects, including those related to advancing worker rights and voices. Apple is a member of the ILO Global Business Network on Forced Labour and serves on the steering committee.

## The International Organization for Migration (IOM)

Apple partners with IOM on multiple initiatives, including the development of, and trainings on, our Responsible Labor Recruitment Toolkit.

## Responsible Business Alliance (RBA)

Apple collaborates with the RBA and its member companies throughout the year on initiatives covering the work we do across our supply chain. We've served in several leadership capacities over time, including as a member of the RBA's Board of Directors, a founding and former steering committee member of the Responsible Labor Initiative, and a member of the steering committee of the Responsible Minerals Initiative.

## Fund for Global Human Rights

Apple partners with the Fund for Global Human Rights to support grassroots activists, as well as human rights and environmental defenders.

Logistics and product repair, United States

iMac assembly, Ireland Robotics training, India

Professional skills development course, United States

<!-- image -->

Vocational Education for Persons with Disabilities, China mainland

Coding classes, Vietnam

## How we expand opportunity through education

## Education is essential to creating a more equitable world and preparing people for rapidly evolving advanced manufacturing jobs.

Since 2008, our supplier education programs have focused on three pillars: technical skills development; professional skills development; and health and wellness training. These programs are helping suppliers develop the knowledge they need to meet the demands of an evolving supply chain, and helping supplier employees gain skills to grow personally and professionally.

<!-- image -->

## Apple Education Hubs

Established in 2022 as part of our $50 million Supplier Employee Development Fund, Apple Education Hubs are physical spaces and online learning platforms that provide education opportunities to our suppliers' employees. The Hubs, currently located in the United States, China mainland, India, and Vietnam, have made more than nine million education and training opportunities available to supplier employees.

## Technical skills to unlock new pathways

Technical training provides access for people to move into new career opportunities. We deliver a wide variety of technical skill-building programs to supplier employees in highly sought-after skills, such as computer science, smart manufacturing fundamentals, automation equipment maintenance, and Lean Six Sigma, a methodology for improving operational efficiency and quality. Among our most popular programs is our Swift coding program, with many participants developing apps that independently meet the high standards to be published in the Apple App Store. Since 2017, more than 108,000 supplier employees have participated in the program, with five apps developed and launched by supplier employees on the App Store in 2025.

<!-- image -->

## Professional skills development

We are helping supplier employees develop the communication and collaboration skills that can make them more effective in any role, provide them pathways to leadership opportunities, and foster more supportive work environments. In 2025, more than 179,000 supplier employees in three countries participated in soft skills training, including communications skills, personal efficiency, stress management, conflict resolution, and gender sensitivity and equality training.

<!-- image -->

􀎜

## Vocational Education for Persons with Disabilities

Our Vocational Education for Persons with Disabilities program works with suppliers to make employment and professional development opportunities accessible for people with disabilities in our supply chain, as well as to improve safety and inclusivity practices in supplier facilities. The program supports suppliers in recruiting, retaining, and providing advancement opportunities for program participants. This includes helping suppliers identify and recruit for roles that best align to the skills and needs of participants, and assessing facilities for opportunities to improve accessibility. The program also provides training for workers and managers to increase awareness and capabilities, such as sign language, to cultivate more inclusive workplaces, as well as personal and professional skills training to help participants continue to grow in their careers. Since its launch in 2022 in China mainland, the program has expanded to key suppliers in the United States, India, and Vietnam, benefiting more than 49,000 supplier employees at 70 supplier sites.

<!-- image -->

􁕜

## Health education and support

For many supplier employees, their position at an Apple supplier facility may be their first experience working in a manufacturing environment, away from friends and family, and living and working with many different people. Through our supplemental health education programs, we are supporting supplier employees in navigating these environments in a way that promotes their overall health and wellness, and improves their workplace satisfaction.

Since 2017, through new employee orientation sessions, Apple Education Hub programs, monthly health awareness campaigns, and other specialized training opportunities, we've helped make health education and resources available to more than eight million people on topics such as nutrition, mental well-being, first aid, reproductive health, and early disease detection.

## How we source materials responsibly

Apple works with suppliers to responsibly source all materials - whether from primary or recycled sources - used in Apple products.

## Apple Responsible Sourcing Toolbox

- Innovate in materials sourcing
- Map the supply chain and establish strict requirements
- Understand risks by using supply chain tools such as the Risk Readiness Assessment
- Conduct third-party audits of primary and recycled materials processors
- Address risks that   are found
- Publish smelter and refiner list annually
- Increase recycled and renewable content
- Support local communities
- Engage with civil society and support local human rights and environmental defenders
- Strengthen industry traceability systems to increase transparency
- Develop and drive common industry standards
- Provide training to supply chain actors to strengthen due diligence

## We set high standards.

Our requirements and human rights due diligence practices are aligned with international standards and frameworks, including the United Nations Guiding Principles on Business and Human Rights (UNGPs), the International Labour Organization's (ILO) Declaration on Fundamental Principles and Rights at Work, and the Organisation for Economic Co-operation and Development (OECD) Due Diligence Guidance for Responsible Supply Chains of Minerals from ConflictAffected and High-Risk Areas.

## Identifying risks.

We require our suppliers to identify and assess a broad range of risks, including social, environmental, and human rights risks for materials used in Apple products. We support this work by training suppliers, and working with partners, to develop and scale tools to support risk management across global supply chains.

## Strengthening industry standards.

In addition to setting our own rigorous standards, we support the development of industry-wide standards. We participate and serve in leadership capacities across multiple industry associations and initiatives. This includes the Responsible Business Alliance (RBA) - where we previously served on the board of directors and continue to actively participate in working groups and task forces - as well as the Responsible Minerals Initiative (RMI), where we currently serve on the steering committee.

## We map and prioritize materials.

Our goal is to one day use only recycled or renewable materials for our products and packaging. We use data to understand the environmental, social, and supply chain impacts of materials used in our supply chain. We also work to map the origin of those materials to guide our responsible sourcing strategy.

We prioritize materials for transition to recycled or renewables. Looking across commonly used mined materials, and weighting them against the amount of each Apple uses, we've identified 15 priority materials that represent the biggest opportunities for impact across environmental, social, and supply chain criteria: aluminum, cobalt, copper, glass, gold, lithium, paper, plastics, rare earth elements, steel, tantalum, tin, titanium, tungsten, and zinc. These materials accounted for more than 85 percent of the total product weight shipped to our customers in 2025. Each is outlined in detail in our Material Impact Profiles white paper.⁸

## We work to identify the origin of materials used in our products.

We work to map our supply chain to the smelter and refiner level and, to the extent available, to the mining level. Through this process, we identify smelters and refiners that provide tin, tantalum, tungsten, and gold (3TG), cobalt, and lithium to our suppliers, as well as other materials - such as mica, copper, graphite, and nickel. Our suppliers are required to identify the origins of all materials they use, whether that be a recycler, smelter, refiner, or, in the case of biological materials, a farm.

## Responsibly sourcing primary materials.

Although Apple does not source primary material directly from mine sites, our responsible materials sourcing program includes requirements that apply to all suppliers' sourcing across the supply chain.

<!-- image -->

## We verify and report.

Every year, we publish a list of all identified 3TG, cobalt, and lithium smelters and refiners in our supply chain. In 2016, we became the first electronics company to publish a list of cobalt refiners in our supply chain, and in 2020, we were the first to publish a list of lithium refiners.

## Conducting third-party audits.

Suppliers are only permitted to use or source key materials for Apple products from smelters, refiners, and recyclers who have completed, or demonstrated progress towards completion of, responsible sourcing audits. We also work closely with third-party audit programs, such as those operated by RMI and the London Bullion Market Association.

For the past decade, all of the identified 3TG and cobalt smelters and refiners in our supply chain have participated in assessments conducted by accredited third-party auditors, as required by our Responsible Sourcing of Primary, Recycled, and Renewable Materials Standard. All identified lithium refiners also continue to meet our requirements each year. If smelters or refiners are unable or unwilling to meet our standards, we take necessary actions, through our suppliers, to terminate the applicable business relationships. Since 2009, Apple has directed the removal of 206 3TG, 17 cobalt, and 9 lithium smelters and refiners from our supply chain. 2

## Addressing allegations.

We take allegations related to our supply chain very seriously - and we expect our suppliers to do the same. We require our suppliers to review and address any incidents reported to them involving their materials supply chains. We provide support to help suppliers complete corrective actions in line with OECD Due Diligence Guidance.

## We empower independent voices and local communities.

We support industry platforms, such as the RBA Voices platform, and grassroots organizations that enable people living and working in and around mining communities to voice concerns. And as we pursue our goal to one day use only recycled or renewable materials in our products, we partner with international development organizations to support communities as they transition away from mining activities.

## We support communities in their transition from mining.

For nearly a decade, Apple supported the NGO Pact in developing a localized program to deliver rights awareness training, vocational education, and financial access and literacy to mining communities in the Democratic Republic of the Congo (DRC). This also included support for communities as they transition away from participation in mining activities.

## We support vulnerable populations in the DRC.

In 2025, we supported Panzi Hospital and Foundation, which provides holistic care for survivors of sexual violence in the DRC.

We support human rights and environmental defenders. Since 2017, we've partnered with the Fund for Global Human Rights to deliver flexible funding and support to human rights and environmental defenders working in mining communities.

We invest in environmental restoration and communities. Since 2017, we've worked with the nonprofit RESOLVE on projects aimed at restoring and rehabilitating ecosystems that have been affected by legacy mining operations. This includes Regeneration, a project focused on re-mining and processing waste material from legacy mines to further restore natural environments and promote biodiversity.

<!-- image -->

## Partnerships

Apple's ambition is to be the ripple that creates broader change. Global supply chains - and the challenges they present - are highly complex, so effecting change requires working in the collective.

We work with a diverse group of partners to strengthen and expand the impact of our programs. In addition to the organizations listed here that support our people-focused commitments, we also work with additional stakeholders to drive progress toward Apple 2030 and our other environmental goals.

- Ꮹ To learn more about our environmental partnerships, see our 2026 Environmental Progress Report and our Environment website.

<!-- image -->

Alliance for Water Stewardship

<!-- image -->

<!-- image -->

Clean Electronics Production Network

<!-- image -->

Fair Wage Network

<!-- image -->

IDEA

<!-- image -->

International Labour Organization

<!-- image -->

London Bullion Market Association

<!-- image -->

Pact

<!-- image -->

Responsible Business Alliance

<!-- image -->

Thomson Reuters Foundation American India Foundation Council for Adult and Experiential Learning Fund for Global Human Rights IMPACT

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

International Organization for Migration

<!-- image -->

Manipal Academy of Higher Education

<!-- image -->

Public-Private Alliance for Responsible Minerals Trade

<!-- image -->

Social Accountability International

<!-- image -->

Working Capital Innovation Fund (incubated by Humanity United)

<!-- image -->

Anker Research Institute

<!-- image -->

Disability:IN

<!-- image -->

Goodbit

<!-- image -->

Inno

Initiative for Responsible Mining Assurance

<!-- image -->

Michigan State University

<!-- image -->

Quizrr

<!-- image -->

SCORE Academy

<!-- image -->

World Business Council for Sustainable Development ChemFORWARD

<!-- image -->

<!-- image -->

Enable India

<!-- image -->

Harvard Humanitarian Initiative

<!-- image -->

Institute of Public and Environmental Affairs

<!-- image -->

Levin Sources

<!-- image -->

Organisation for Economic Cooperation and Development

RESOLVE

<!-- image -->

The Remedy Project

<!-- image -->

Zhejiang University

## An unwavering commitment.

We are deeply dedicated to the people, communities, and the environment across our global supply chain. While we're proud of the progress that has been accomplished, there will always be more for us to do.

The progress we make happens through partnership - with our suppliers, stakeholders, and the millions of people who work to bring our products to life. We believe business, at its best, can be a force for good in the world.

Additional reporting on our programs and progress is available at apple.com/supplychain and apple.com/environment.

## Endnotes

## Forward-looking statements

The information covered by the report contains forwardlooking statements within the meaning of the Private Securities Litigation Reform Act of 1995, including statements regarding our goals, targets, commitments, and strategies and related business and stakeholder impacts. These statements involve risks and uncertainties, and actual results may differ materially from any future results expressed or implied by the forwardlooking statements, including any failure to meet stated goals and commitments, and execute our strategies in the time frame expected or at all, as a result of many factors, including changing government regulations or stakeholder expectations, and our expansion into new products, services, technologies, and geographic regions. Forward-looking statements can also be identified by words such as 'future,' 'anticipates,' 'believes,' 'estimates,' 'expects,' 'intends,' 'plans,' 'predicts,' 'will,' 'would,' 'could,' 'can,' 'may,' and similar terms. More information on risks, uncertainties, and other potential factors that could affect our business and performance is included in our filings with the SEC, including in the 'Risk Factors' and 'Management's Discussion and Analysis of Financial Condition and Results of Operations' sections of the company's most recently filed periodic reports on Form 10-K and Form 10-Q and subsequent filings. We assume no obligation to update any statements, which speak only as of the date they are made.

## Information in this report

This report does not cover all information about our business. References in this report to information should not be interpreted as an indication of the materiality of such information to Apple's financial results or for purposes of U.S. securities laws, or any other laws or requirements. Additionally, certain terminology used in this report, such as 'value chain,' 'impacts,' 'risks,' 'opportunities,' and 'targets' may differ from the terminology used in legal reporting frameworks. Also, any reference in this report to sustainable activities should not be interpreted as an indication of the classification of such activity under any legal classification framework which could be subject to specific criteria and requirements that may differ from the general references in this report.

## Reporting year

We track our progress based on Apple's fiscal year. All references to a year throughout the report refer to Apple's fiscal years, unless 'calendar year' is specified. Apple's fiscal year is the 52- or 53-week period that ends on the last Saturday of September.

- 1 Apple reports 3TG smelter and refiner assessment information on a calendar year.
- 2 The total number of 3TG smelters and refiners directed to be removed from Apple's supply chain since 2009 represents a cumulative count with smelters and refiners only counted once, when first removed from Apple's supply chain. 3TG smelters and refiners may subsequently re-enter the supply chain if they meet Apple's Code and Responsible Sourcing of Primary, Recycled, and Renewable Materials Standard, and other 3TG mineral requirements.
- 3 Apple reports data about the recycled content of its products at different levels of fidelity, based on the level of independent data verification. The bulk of Apple's recycled content data is certified and thus verified by a third party. Less than 1 percent of the total mass shipped in Apple products in fiscal year 2025 contained recycled content that was not third party certified and verified and is either supplier-verified (meaning it has been reported by the supplier and cross-checked by Apple) or supplier-reported (meaning it has been reported by the supplier based on production and allocation values). In all cases, Apple defines recycled content in alignment with ISO 14021. We do not currently include industry-average recycled content, which may result in underreporting actual recycled content. Total recycled material shipped in products is driven by product material composition and total sales - as a result, this overall recycled or renewable content percentage may fluctuate based on the number and type of products sold each year.
- 4 These sites are included in the scope of our reasonable level of assurance report that has been third party verified by UL Solutions against the UL 2799 Zero Waste to Landfill Environmental Claim Validation Procedure (ECVP). The UL 2799 criteria requires at least 90 percent diversion through methods other than wasteto-energy to achieve Zero Waste to Landfill (Silver: 90-94 percent, Gold: 95-99 percent, and Platinum: 100 percent) designations.
- 5 We plan to reach carbon neutrality in fiscal year 2030 (FY2030) carbon footprint.
- 6 We accomplished our goal to use 100 percent recycled cobalt in all Apple designed batteries, 100 percent recycled tin soldering and 100 percent recycled gold plating in all Apple-designed rigid and flexible printed circuit boards, and 100 percent recycled rare earth elements in all magnets. This accomplishment excludes inventory for replacement and repair, as well as excess inventory purchased prior to year-end currently being consumed and representing less than 0.1% of total material usage.
- 7 Apple achieved its goal of eliminating plastic in our packaging and transitioning to 100 percent fiber-based packaging. Apple's goal to remove plastic from packaging included retail bags, all finished goods boxes (including plastic content in labels and in-box documentation), packaging sent to our customers as part of Apple Trade In, AppleCare packaging for whole units and service modules (with the exception of plastics needed to protect items from electrostatic discharge), and secondary packaging of Apple products and accessories sold by Apple. Our goal excluded the inks, coatings, or adhesives used in our packaging. We plan to remove plastic from the packaging of refurbished products by 2027, once old product packaging designs are phased out. We'll continue selling existing inventory of AppleCare packaging for whole units and service modules that contain plastics for vintage and products at end of life and a select subset of vintage products launched prior to December 2023 until consumed. This approach will enable us to avoid waste generated by repackaging goods in new 100 percent fiber-based packaging and represents less than 0.4% of our total packaging footprint.
- 8 Since publishing the 'Material Impact Profiles' white paper, we've expanded our analysis to include biodiversity factors.

<!-- image -->