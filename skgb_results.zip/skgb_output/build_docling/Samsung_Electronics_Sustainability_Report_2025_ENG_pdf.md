Samsung Electronics Sustainability Report 2025

## A Journey   Towards a Sustainable Future A Journey   Towards a Sustainable Future

## A Journey   Towards a Sustainable Future A Journey Towards a Sustainable Future

Samsung Electronics Sustainability Report 2025

## Our Company

Message from Our CEO About Us Corporate Governance Materiality Assessment Stakeholder Engagement

## Principle

Compliance &amp; Ethics

## Planet

| [DX Division]                 |
|-------------------------------|
| Governance and Major Progress |
| Climate Change                |
| Circular Economy              |
| Water                         |
| Pollution                     |

## Facts &amp; Figures

Economic Performance Social Performance Environmental Performance Performance by Division

04

05

06

07

09

59

11

12

16

18

20

62

63

68

72

| [DS Division]                 |
|-------------------------------|
| Governance and Major Progress |
| Climate Change                |
| Circular Economy              |
| Water                         |
| Pollution                     |

21

22

27

29

32

## Appendix

| Independent Assurance Report                                    |   76 |
|-----------------------------------------------------------------|------|
| Verification Statement on Scope 1 and 2 Greenhouse Gas Emission |   77 |
| Verification Statement on Scope 3 Greenhouse Gas Emission       |   78 |
| GRI Index                                                       |   80 |
| TCFD Index                                                      |   82 |
| SASBIndex                                                       |   84 |
| About This Report                                               |   86 |

## People

Our People Sustainability in Supply Chain Empowering Communities Privacy Protection &amp; Security Product Quality &amp; Safety

02

35 45 51 53 55

## Our Company

Message from Our CEO

About Us

Corporate Governance

Materiality Assessment

Stakeholder Engagement

04

05

06

07

09

## Message from Our CEO

Dear Shareholders, Customers, Partners, and Employees,

The year 2024 has been marked by rapid industrial changes, including global geopolitical risks and advancements in AI technology. Competition across industries has intensified, and new technologies are driving significant transformations in business operations.

Despite these challenges, Samsung Electronics achieved a 16% increase in revenue and a fivefold increase in operating profit compared to the previous year. We also focused on laying the foundation for continued growth through strategic investments in our facilities and a strengthened commitment to research and development.

Thanks to the recognition and support from stakeholders across various sectors, Samsung Electronics' brand value surpassed USD 100 billion for the first time, as evaluated by Interbrand, securing our position among the world's top five brands for the fifth consecutive year. We would like to extend our sincerest gratitude.

The key solution to rapidly changing business environments and rising socioeconomic risks lies in adhering to our fundamental business principles and establishing a foundation for sustainable growth. Samsung Electronics continues to engage in diverse activities across society based on this belief, aiming to enhance our business competitiveness and drive technological innovation.

Let me first address environmental initiatives. Based on the "New Environmental Strategy" announced in September 2022, Samsung Electronics is working towards achieving net zero scope 1 and 2 emissions, maximizing resource circularity, and tackling environmental challenges through technological innovation.

The DX (Device eXperience) Division aims to achieve net zero scope 1 and 2 emissions by 2030. As of the end of 2024, 93.4% of its total energy consumption has been transitioned to renewable energy. Major product models have adopted high-efficiency energy technologies, reducing average power consumption by 31.5% compared to 2019. 31% of plastic components used in products now incorporate recycled materials, marking significant progress.

The DS (Device Solutions) Division aims to achieve net zero Scope 1 and 2 emissions emissions by 2050, continuing its investment in the Regenerative Catalytic System (RCS) for integrated treatment of process gases. All Korean manufacturing sites of the DS Division have obtained the highest certification of 'Platinum' from the Alliance for Water Stewardship (AWS) for their excellences in water management. Additionally, all of the Division's global sites have undergone an integrated Zero-Waste-to-Landfill validation by UL Solutions, a leading environmental safety certifier, and achieved their highest rating.

The increasing energy demand due to the adoption of advanced technologies presents new challenges for sustainable growth. In particular, the rapid advancement of AI technology and the growth of the IT industry have led to significant increases in energy consumption and carbon emissions in data centers and other sectors. As customers increasingly demand carbon footprint reduction and the use of carbonfree energy, Samsung Electronics is actively exploring and implementing a range of  eco-friendly energy solutions.

In the social field, Samsung Electronics is strengthening our safety accident prevention system with the goal of achieving Zero Major Accidents and a Global Top Tier Lost-Time Injuries Rate (LTIR) by 2030. In 2024, the DX Division conducted a labor and human rights risk assessment (Business &amp; Human Rights Benchmark) at 19 of our manufacturing sites and published a related report.

In the supply chain sector, we expanded efforts to strengthen collaborative partnerships in 2024 by conducting third-party audits on 33 second-tier suppliers. Additionally, plans are underway to introduce an enhanced integrated due diligence policy in 2025 to better address global supply chain regulations.

Additionally, in 2024, Samsung Electronics supported the "Samsung SW·AI Academy for Youth", a flagship corporate social responsibility program, with 37.5 billion KRW, training 2,200 young software talents. In 2025, we plan to extend educational opportunities to graduates of Meister high schools. In addition, Samsung supported a total of 14,362 youth leaving protective care facilities to secure stable residence and prepare for their future through the Samsung Stepping Stone of Hope program. The Stepping Stone of Hope opened new centers in the North Chungcheong Province and the city of Daejeon in 2024, and plans to build another center in the city of Incheon in 2025 to support more youth in need.

As in previous years, the 2025 Sustainability Report has been published in accordance with global disclosure regulation frameworks. It encompasses our sustainability management governance, strategies, implementation activities and achievements throughout 2024. The content of the Samsung Sustainability Website is closely aligned with and complements this report.

Samsung Electronics continues its efforts to build a foundation for renewed success amidst uncertainty. Guided by our management philosophy, "Creating the best products and services based on talent and technology to contribute to society," we are solidifying our technological leadership and securing growth engines for the future.

Samsung Electronics deeply values input from our stakeholders and will continue to do our utmost to establish a foundation for sustainable growth.

Thank you.

CEO and Vice Chairman of Samsung Electronics Co.

Young-Hyun Jun

<!-- image -->

04

## About Us

Samsung Electronics Co., Ltd. (hereinafter Samsung Electronics) aims to become a global premier company that contributes to society by creating the world's best products and services based on talent and technology. To achieve this, Samsung Electronics has concretized our 5 Business Principles into detailed guidelines and action items, establishing them as our Code of Conduct that all employees must adhere to and which will serve as a standard for all business activities. Moving forward, Samsung Electronics will continue to internalize our 5 Key Values into our organizational culture to grow sustainably.

## About Our Organization

Samsung Electronics is divided into two Divisions, Device eXperience (DX) and Device Solutions (DS), according to product characteristics, each of which is operated independently. The DX Division produces and sells finished products such as smartphones, network systems, computers, TVs, refrigerators, washing machines, air conditioners, and medical equipment, while the DS Division consists of the Memory Business, Foundry Business, and System LSI Business which produces and sells semiconductor components such as DRAM, NAND Flash, and mobile APs. As of the end of 2024, Samsung Electronics owns 240 manufacturing sites, sales offices, R&amp;D centers, and design centers worldwide.

<!-- image -->

| Regional Headquarters 1)   | Sales Offices 2)   | Manufacturing Sites   | Purchase Centers   |
|----------------------------|--------------------|-----------------------|--------------------|
| 15                         | 109                | 33                    | 6                  |
| R&DCenters                 | Design Centers     | Others 3)             | Total              |
| 40                         | 7                  | 30                    | 240                |

1) Regional classification is based on Samsung Electronics' internal management criteria.  2) Sales subsidiaries, branches, etc. 3) Distribution subsidiaries, IP Offices, etc.  4) Suppliers of parts used in the manufacturing of Samsung Electronics products.

<!-- image -->

Employees  262,647

<!-- image -->

Suppliers

4)   2,503

<!-- image -->

Operations in  76  countries

<!-- image -->

R&amp;D expenditure KRW  35.0  trillion

<!-- image -->

05

## Corporate Governance

## Board of Directors

Samsung Electronics' Board of Directors is composed of directors elected at the shareholders' meeting and resolves important matters related to the company's business. We implemented a balanced governance system where the Heads of the DX and DS Divisions, as well as the Heads of major Business Units, serve as internal directors on the Board to practice responsible management, while independent directors, experts in their respective fields, provide an objective perspective and oversight of the management team. As of the end of March 2025, the Board includes 3 internal directors (Young-Hyun Jun, Tae-Moon Roh, Jai-Hyuk Song) and 6 independent directors (Je-Yoon Shin, Jun-Sung Kim, Eunnyeong Heo, Myung-Hee Yoo, Hye-Kyung Cho, Hyuk-Jae Lee). To enhance independence and transparency, the Board has separated the roles of Board Chair and CEO, appointing independent director Je-Yoon Shin as the Chair.

## [Board of Directors Composition](https://www.samsung.com/global/sustainability/principle/corporate-governance/#AYUr1R6qE7IAIx_C)

Samsung Electronics considers a diverse set of expertise, gender, and nationality when appointing directors. Independent directors in particular consist of individuals with extensive knowledge or experience in professional fields such as finance, law, IT (robotics, AI, semiconductors), risk management, public sector, and sustainable management. To this end, we prepare and utilize the BSM (Board Skills Matrix) . In addition, 2 out of the 6 independent directors are women in consideration of the positive impact of the Board's gender diversity on its activities such as balanced decision-making.

## Sustainability Governance

The Board of Directors, Samsung Electronics' highest decision-making body, oversees our sustainable management activities.

In July 2021, our Governance Committee expanded and reorganized into the Sustainability Committee under the Board of Directors to promote sustainable management in fields such as environment, society, and governance, and to enhance shareholder value. All independent directors participate in the Sustainability Committee, deliberating and approving various matters related to management policies and mid- to long-term strategies in the fields of environment, society, and governance, as well as managing risks related to issues such as sustainable management and shareholder return policies.

We also operate the DX Division's Sustainability Council and the DS Division's ESG Management Council, led by each Division Head. Management reviews sustainable management-related matters with respective responsible personnel. We report discussed items to the Board of Directors and the Sustainability Committee as needed. We also operate a council where relevant departments discuss and coordinate major sustainability issues such as climate change and human rights.

Since 2021, sustainability indicators have been incorporated into our performance evaluation systems for both organizations and executives. These indicators include greenhouse gas (GHG) emissions reduction, renewable energy transition, energy-efficient product development, regulatory compliance, and product accessibility, and are tailored to the responsibilities of each organization and executive.

## Sustainable Management Governance Bodies

<!-- image -->

| Board of Directors                                                                                                            | Board of Directors                                                                                                                                                      |
|-------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Board of Directors and its affiliated SustainabilityCommittee oversees sustainability strategyand progress                    | Board of Directors and its affiliated SustainabilityCommittee oversees sustainability strategyand progress                                                              |
| [DX] SustainabilityCouncil [DS]ESGManagementCouncil                                                                           | [DX] SustainabilityCouncil [DS]ESGManagementCouncil                                                                                                                     |
| Managementdiscusses sustainability-related topics with executives of all relevant units - Frequency: At leastonceevery6months | Managementdiscusses sustainability-related topics with executives of all relevant units - Frequency: At leastonceevery6months                                           |
| Environment                                                                                                                   | [DX Div.] Environmental Safety Meetings, ESGDisclosure Task Force [DS Div.] Carbon Reduction Committee, Environmental Conservation Committee, Reuse Expansion Committee |
| Social                                                                                                                        | Labor and HumanRights Council, Privacy Steering Committee, Security Council, Quality Innovation Committee                                                               |

06

## Materiality Assessment

Samsung Electronics conducts materiality assessments identifying and prioritizing key sustainability issues material to our business, transparently disclosing the processes and results. In 2024, we conducted a Double Materiality Assessment (DMA) adapted from the European Financial Reporting Advisory Group's (EFRAG) materiality assessment implementation guidance and published the results in our 2024 Sustainability Report. We observed no significant changes in issues related to sustainable management within Samsung Electronics' value chain, leading us to maintain final material topics for the current reporting period. Our materiality assessment considered both relevant company activities' impacts on the external environment and relevant external factors' financial impacts on the company.

## Materiality Assessment Process

<!-- image -->

| Step 1. Understanding the Business                                                                          | Step 1. Understanding the Business                                                                                                 |                                                                                                                 | Step2.IdentifyingImpacts,Risks,andOpportunities(IROs) Step 3. Evaluating IROs                                                                                    |                                                                                                                            |                                                                                                                            | Step 4. Selecting Material Topics                                                                                                                                      | Step 4. Selecting Material Topics                                                                                                                                      | Step 4. Selecting Material Topics                                                                                                                                      | Step 4. Selecting Material Topics                                                                                                                                      | Step 4. Selecting Material Topics                                                                                                                                      |
|-------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Analyze internal/external environments andvalue chain to extract preliminary relevant sustainability topics | Analyze internal/external environments andvalue chain to extract preliminary relevant sustainability topics                        | Identify environmental/social impacts andfinancial risks/ opportunities of 13 preliminary sustainability topics | Identify environmental/social impacts andfinancial risks/ opportunities of 13 preliminary sustainability topics                                                  | Design evaluative scales for identified primary topics' IROs andperformevaluationsbasedon robust stakeholder participation | Design evaluative scales for identified primary topics' IROs andperformevaluationsbasedon robust stakeholder participation | Combinequantitative/qualitative analyses of the survey results to select 8material topics, whicharereviewedbymanagementandthen reported to the SustainabilityCommittee | Combinequantitative/qualitative analyses of the survey results to select 8material topics, whicharereviewedbymanagementandthen reported to the SustainabilityCommittee | Combinequantitative/qualitative analyses of the survey results to select 8material topics, whicharereviewedbymanagementandthen reported to the SustainabilityCommittee | Combinequantitative/qualitative analyses of the survey results to select 8material topics, whicharereviewedbymanagementandthen reported to the SustainabilityCommittee | Combinequantitative/qualitative analyses of the survey results to select 8material topics, whicharereviewedbymanagementandthen reported to the SustainabilityCommittee |
| Analyze internal/external environments                                                                      | Analyze internal/external environments                                                                                             | Provide Identification Basis                                                                                    | Provide Identification Basis                                                                                                                                     | Establish AssessmentCriteria                                                                                               | Establish AssessmentCriteria                                                                                               | Establish AssessmentCriteria                                                                                                                                           | under the Board of Directors                                                                                                                                           | under the Board of Directors                                                                                                                                           | under the Board of Directors                                                                                                                                           | under the Board of Directors                                                                                                                                           |
| Disclosed company data such as our Annual Report and internal company data such as stakeholder inquiries    | Disclosed company data such as our Annual Report and internal company data such as stakeholder inquiries                           | ∙ Legal/regulative issues ∙ Externally disclosed information                                                    | Scale                                                                                                                                                            | Environmental/ SocialImpacts                                                                                               | Size of impacts                                                                                                            |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |
|                                                                                                             |                                                                                                                                    | (media, Sustainability Website, Sustainability Report, etc) ∙ Stakeholder requests                              | Scope                                                                                                                                                            | Environmental/ SocialImpacts                                                                                               | Geographic/physical reach of impacts                                                                                       | Qualitative Results                                                                                                                                                    | Qualitative Results                                                                                                                                                    | Quantitative Results                                                                                                                                                   | Quantitative Results                                                                                                                                                   | Quantitative Results                                                                                                                                                   |
| Understand                                                                                                  | andanalyze the value chain                                                                                                         | (customers, investors, suppliers, rating agencies, etc)                                                         | (customers, investors, suppliers, rating agencies, etc)                                                                                                          | Environmental/ SocialImpacts                                                                                               | Remediability Time required to remediate                                                                                   | Environmental/ Social Impacts                                                                                                                                          | Financial Risks/ ExecutiveManagement                                                                                                                                   | Financial Risks/ ExecutiveManagement                                                                                                                                   | Financial Risks/ ExecutiveManagement                                                                                                                                   | Financial Risks/ ExecutiveManagement                                                                                                                                   |
| Upstream                                                                                                    | [DX] Mineral mining, manufacturing of electronic components, optical devices, etc [DS] Mineral mining, manufacturing of electronic |                                                                                                                 | Likelihood                                                                                                                                                       | Environmental/ SocialImpacts                                                                                               | negative impacts Time estimated for potential impacts to occur                                                             | Environmental/ Social Impacts                                                                                                                                          | Opportunities Interview                                                                                                                                                | Opportunities Interview                                                                                                                                                | Opportunities Interview                                                                                                                                                | Opportunities Interview                                                                                                                                                |
|                                                                                                             | components, gases, chemical products, etc                                                                                          |                                                                                                                 | Identifying IROs                                                                                                                                                 |                                                                                                                            | Quantitative size of risksand opportunities considering                                                                    |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |
| Own Operations                                                                                              | [DX] Research, manufacturing, andsale of electronic products [DS] Research, manufacturing, andsale of semiconductors               | Environmental &SocialImpacts                                                                                    | ∙ Environmental &social impacts of sustainability related companyactivities ∙ Classified as "positive" or "negative" &"actual" or "potential" Size&Reach         |                                                                                                                            | companysales, net worth, etc. &qualitative reach of risks andopportunities considering expected time of                    | Final Material Topics                                                                                                                                                  | Final Material Topics                                                                                                                                                  | Final Material Topics                                                                                                                                                  | Final Material Topics                                                                                                                                                  | Final Material Topics                                                                                                                                                  |
|                                                                                                             |                                                                                                                                    |                                                                                                                 | Financial Risks/ Opportunities                                                                                                                                   |                                                                                                                            |                                                                                                                            | Environmental                                                                                                                                                          | Social                                                                                                                                                                 | Governance                                                                                                                                                             | Governance                                                                                                                                                             | Governance                                                                                                                                                             |
| Downstream                                                                                                  | [DX] Product transportation, sales agents, product repair, call centers, consumers [DS] Manufacturing of homeappliances,           | FinancialRisks/                                                                                                 | ∙ External impacts of sustainability related topicson companyfinances                                                                                            |                                                                                                                            | related decision making Time expected for financial                                                                        | ClimateChange andEnergy                                                                                                                                                | WorkingConditions -Employees                                                                                                                                           | Compliance &Ethics                                                                                                                                                     | Compliance &Ethics                                                                                                                                                     | Compliance &Ethics                                                                                                                                                     |
| computers, cars, etc                                                                                        |                                                                                                                                    | Opportunities ∙                                                                                                 | Classified as "risks" or "opportunities" Likelihood                                                                                                              |                                                                                                                            | risks/opportunities to occur                                                                                               | Water                                                                                                                                                                  | SupplyChain                                                                                                                                                            |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |
|                                                                                                             |                                                                                                                                    |                                                                                                                 |                                                                                                                                                                  |                                                                                                                            |                                                                                                                            | Resource Circularityand Waste                                                                                                                                          | Information Securityand Protection                                                                                                                                     |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |
| Derive Primary Topics                                                                                       | Derive Primary Topics                                                                                                              |                                                                                                                 |                                                                                                                                                                  |                                                                                                                            |                                                                                                                            |                                                                                                                                                                        | Product Quality                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |
|                                                                                                             |                                                                                                                                    | Opinions                                                                                                        | Opinions                                                                                                                                                         | Opinions                                                                                                                   | Opinions                                                                                                                   | Opinions                                                                                                                                                               |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |
|                                                                                                             |                                                                                                                                    | Stakeholder Surveys                                                                                             | Collect Internal &External KeyStakeholder                                                                                                                        |                                                                                                                            |                                                                                                                            |                                                                                                                                                                        | andSafety                                                                                                                                                              |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |
| FormIssue Pool                                                                                              | 115 issues consisting of 92 European Sustainability Reporting Standards (ESRS) suggested sub-topics +23sector specific issues      |                                                                                                                 | Conducted online survey for relevant Korean/global SamsungElectronics stakeholders including employees, customers, suppliers, investors, NGOs, and international |                                                                                                                            |                                                                                                                            | Further select environmentally material issues by to account for Divisional sectoral differences ∙ DXDivision: climate change andenergy, water,                        |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |
| Evaluation Alignment with companystrategy,                                                                  |                                                                                                                                    |                                                                                                                 | organizations                                                                                                                                                    |                                                                                                                            |                                                                                                                            | Division circularityandwaste                                                                                                                                           |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |
| 52 issues →Select 13 preliminary topics encompassing                                                        | 52 issues →Select 13 preliminary topics encompassing                                                                               | Management Interviews                                                                                           | to obtain their views on sustainability topics material to the                                                                                                   | Derive                                                                                                                     | Derive                                                                                                                     | ∙ DSDivision: climate change andenergy, water, resource                                                                                                                | resource                                                                                                                                                               |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |
| the 52 issuesbasedonESRStopictaxonomy                                                                       |                                                                                                                                    |                                                                                                                 |                                                                                                                                                                  |                                                                                                                            |                                                                                                                            |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |
|                                                                                                             |                                                                                                                                    |                                                                                                                 |                                                                                                                                                                  |                                                                                                                            | department executives                                                                                                      |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |
|                                                                                                             |                                                                                                                                    |                                                                                                                 |                                                                                                                                                                  | Criteria                                                                                                                   |                                                                                                                            |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |
|                                                                                                             | value chain analysis results                                                                                                       |                                                                                                                 | Conducted interviews with DX/DSDivision                                                                                                                          |                                                                                                                            |                                                                                                                            |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |
|                                                                                                             |                                                                                                                                    | Executive                                                                                                       |                                                                                                                                                                  |                                                                                                                            |                                                                                                                            |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |
|                                                                                                             | with global initiatives, key issues in the industry,                                                                               |                                                                                                                 |                                                                                                                                                                  |                                                                                                                            |                                                                                                                            |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |
|                                                                                                             | alignment                                                                                                                          |                                                                                                                 |                                                                                                                                                                  |                                                                                                                            |                                                                                                                            |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |
|                                                                                                             |                                                                                                                                    |                                                                                                                 | sustainability-related                                                                                                                                           |                                                                                                                            |                                                                                                                            |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |
|                                                                                                             |                                                                                                                                    |                                                                                                                 |                                                                                                                                                                  |                                                                                                                            |                                                                                                                            | circularity andwaste, pollutants                                                                                                                                       |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |
|                                                                                                             |                                                                                                                                    |                                                                                                                 | company                                                                                                                                                          |                                                                                                                            |                                                                                                                            |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |                                                                                                                                                                        |

<!-- image -->

<!-- image -->

07

## Material Topic Management

Samsung Electronics identifies the impacts of selected material topics on the company, and reports on company activities to manage these topics.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| 2025Material Topics                | Governance                                                                                                                                                                                                                                                                                                                                                                                                           | Strategy                                                                                                                                                                                                                                                                                                             | Risk Management(Policy)                                                                                                                                                                                                                           | Activities (Major Progress)                                                                                                                                                                                                                                          |
|------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| ClimateChange andEnergy            | Sustainability Committee under the Board of Directors oversees sustainabilitymanagement (including environmental management) strategy and progress Sustainability CouncilandESGManagement Council chaired by respective Division Heads discuss and decide on current issues Invest over KRW7trillion in environmental managementactivities by 2030 (including process gas reduction and water resource conservation) | ‧ DXDivision: net zero Scope 1 and 2 emission by 2030 ‧ DSDivision: net zero Scope 1 and 2 emission by 2050                                                                                                                                                                                                          | ‧ Identify key risks and opportunities due to climate change and develop response strategies by assessing financial impacts based on climate scenarios                                                                                            | · Reduce direct emissions, expand renewable energy, reduce external GHGemissions                                                                                                                                                                                     |
| Water                              | ‧ ‧                                                                                                                                                                                                                                                                                                                                                                                                                  | ‧ DXDivision: replenish 100%ofwater used globally by 2030 ‧ DSDivision: achieve zero increase in water intake for Korean manufacturing sites relative to 2021 levels by 2030                                                                                                                                         | ‧ Assess water resource risks and develop regional response strategies                                                                                                                                                                            | ·ExpandscopeofAWS 1) certification 1) Alliance for Water Stewardship                                                                                                                                                                                                 |
| Resource Circularityand Waste      | Sustainability Committee under the Board of Directors oversees sustainabilitymanagement (including environmental management) strategy and progress Sustainability CouncilandESGManagement Council chaired by respective Division Heads discuss and decide on current issues Invest over KRW7trillion in environmental managementactivities by 2030 (including process gas reduction and water resource conservation) | ‧ DXDivision: apply recycled plastic to all plastic parts in our products by 2050 ‧ DSDivision: achieve 99.9% waste recycling rate across all Korean manufacturing sites by 2030                                                                                                                                     | ‧ Manageresource use and environmental impact risks throughout the entire product life cycle, from raw material procurement to production, use, disposal, and recycling                                                                           | · Operate product waste retrieval system, attain Zero Waste-to-Landfill validations at business sites                                                                                                                                                                |
| Working Conditions - Employees     | Sustainability Committee under the Board of Directors, Sustainability CouncilandESG ManagementCouncil chaired by respective Division Heads and Labor and HumanRights Council oversees and manages employee and supply chain labor and humanrights at various levels                                                                                                                                                  | ‧ Respect humanrights based on managementphilosophy of 'People First', continue to pursue safe work environment,and create positive workplace culture                                                                                                                                                                | ‧ Establish various policies and standards including fundamental principlesofhuman rights, grievance policy, environmental health and safety policy · Operate employee communication and grievance channels and performhuman rights due diligence | · Observe freedom of association and right to collective bargaining · Analyze and improve livingwagegap · Operate manufacturing site safety managementprogramsandemployeehealth promotion programs · Provide fringe benefits and work policies for work-life balance |
| Supply Chain                       | Sustainability Committee under the Board of Directors, Sustainability CouncilandESG ManagementCouncil chaired by respective Division Heads and Labor and HumanRights Council oversees and manages employee and supply chain labor and humanrights at various levels                                                                                                                                                  | · Secure sustainable supply chain by assisting not only business competitiveness but also supplier labor and humanrights, occupational health and safety, and talent development                                                                                                                                     | ‧ Establish various policies and standards including supplier Code of Conduct, global purchasing Code of Conduct ‧ Provide supplier employee comm.channels, grievance channels, and operate combined supplier due diligence process               | · Perform forced labor, child labor special audits · Perform regular EHSaudits, consulting, and training for suppliers · Operate Partner CollaborationAcademy                                                                                                        |
| Information Securityand Protection | Privacy protection team leader acts as Chief Privacy Officer and Information Protection Center Head as Chief Information Security Officer to serve as control towers Operate Privacy Protection Committee and Security Council                                                                                                                                                                                       | · Three Privacy Protection Principles: 'Transparency, Security, Choice' · Four Pillars of Cybersecurity: 'Preventing &Hardening, Prediction, Detection, Response'                                                                                                                                                    | ‧ Establish global privacy protection policy ‧ Operate SamsungPrivacy Website and SamsungSecurityReporting Portal                                                                                                                                 | · Operate Privacy LegalManagementSystem (PLMS) and educate employees · Operate security platformSamsungKnox and SamsungKnoxVault · Establish semiconductor technology security                                                                                       |
| Product Quality andSafety          | Operate Quality Innovation Committee, the highest product quality related decision making body GlobalCSCenterHeadperformsroleofcompany- widechiefCustomerSatisfaction(CS)officer                                                                                                                                                                                                                                     | · Based on quality vision of "Pursuing Perfect Quality and Service for the Best Customer Experience," announce Code of Conduct for quality managementcentered on customer focus, fundamentals, professionalism, creation of premium products, and customer creation, committing to practicing quality responsibility | ‧ Operate quality assurance system and incident response process                                                                                                                                                                                  | · Secure product safety and improve product quality/customer service                                                                                                                                                                                                 |
| Compliance& Ethics                 | Board of Directors and affiliated committees oversee compliance, performing relevant operations through Compliance Committee                                                                                                                                                                                                                                                                                         | · Establish and specify employee and business guidelines with compliance and ethics as top priorities for a fair and transparent businessmanagement                                                                                                                                                                  | ·CPMS 1) based riskmanagement 1)ComplianceProgramManagementSystem                                                                                                                                                                                 | · Operate education and reporting programs, evaluate corruption risk                                                                                                                                                                                                 |

08

## Stakeholder Engagement

Samsung Electronics has defined 8 key stakeholder groups that significantly influence our business activities, taking into account the characteristics of the industry. We gather opinions from stakeholders through various communication channels tailored to stakeholder interests and reflect them in our business strategies and decision-making processes. We continuously monitor whether the key stakeholder opinions are incorporated into our business operations. Additionally, we transparently and promptly share our sustainability performance with stakeholders through our Sustainability Website , stakeholder forums, surveys, and on-site visits. We will strengthen communication and improve transparency in management to build a trusted relationship with stakeholders for our sustainable growth.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Stakeholders   | Stakeholders                                                  | KeyInterests                                                                                                              | KeyInterests                                                                                                                                  | Communication Channels                                                                                                                                                                    | Communication Channels                                                                                                                                  | Major Activities                                                                                                                                                    | Major Activities                                                                                                                                                          |
|----------------|---------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                | Customers (B2C&B2B)                                           | · Quality of products and services · Safety in product use · Environmental impact of products throughout their life cycle | · Accurate product information · Transparent communication                                                                                    | · Customer satisfaction surveys · Contact centers, service centers · SamsungElectronicsNewsroom · Samsung.com                                                                             | · SamsungSemiconductorNewsroom · Sustainability Website · Sales channels · Product environmental report                                                 | · Reinforce quality and safety managementsystems · Offer product information via the country-specific websites                                                      | · Resolve issues identified through Voice of the Customer (VOC) · Staff sustainability specialists at subsidiary and business levels                                      |
|                | Shareholders andInvestors                                     | · Economic performance · Riskmanagement · Information disclosure                                                          | · Sustainability agenda (environmental, social, and governance)                                                                               | · Annual General Meeting · Non-Deal Roadshows, investor meetings · Earnings releases                                                                                                      | · Investors Forum · InvestorESGRoadshow · IR Website                                                                                                    | · Forecast business performance info. and environment · Update shareholder return policy · Publish disclosures                                                      | · Release information on corporate governance · Share environmental/social performance · Collect shareholder and investor opinions                                        |
|                | Employees                                                     | · Safe and healthy work environment · Diversity, equity, and inclusion · Training and career development                  | · Employment and benefits · Labor relations · Organizational culture                                                                          | · Labor unions, work councils chats · Counseling centers · Satisfaction surveys (work concentration, organizational health, employee experience) · Industrial Safety and Health Committee | · Executivemanagement communications ·SamsungNOW · In-house communication channels · Sustainability Website · Compliance/ethics whistleblowing channels | · Offer tailored career development programs · Host town hall events · Perform collective bargaining activities · Operate labor-management relations advisory group | · Managebusiness sites' work environment · Foster a culture of trust communication · Provide training programs · Operate health improvement programs (diet programs, etc) |
|                | Suppliers                                                     | · Partner collaboration · Workplace EHSimprovement · Fair trade                                                           | · Worker humanrights protection · GHGemissions reduction                                                                                      | · Purchasingmanagementsystem · Partner Collaboration Portal · Hotline, Cyber Sinmungo                                                                                                     | · Partner CollaborationAcademy · Partner Collaboration Day/Meetings · Sustainability Website                                                            | · Financial/technical support · ManageGHGemission reduction · Employeetraining/innovationsupport                                                                    | · Support supplier workenvironment · Collect and resolve grievances                                                                                                       |
|                | Local Communities                                             | · Local hiring, local economy revitalization · Indirect economic effects, including investment/employment                 | · Conservation of local environment development · Philanthropic activities                                                                    | · Local volunteer center · Sustainability Website                                                                                                                                         | · CSRWebsite                                                                                                                                            | · Support SMEs, including Smart Factory construction · Conserve river ecosystems near our business sites                                                            | · Runcommunity outreach programs on education (Samsung Stepping Stone of Hope,Samsung SW·AI Academyfor Youth, etc.)                                                       |
|                | International Organiza- tions,NGOs, Associations, Specialized | · Social responsibilities forhuman rights and the environment · Cross-industry collaboration                              | · UNSDGscontributions (climate action, etc.) Transparent and timely information disclosure                                                    | · Corporate meetings ·NGOmeetings · StakeholderForum · Labor-human rights stakeholder workshops                                                                                           | · Civil society -executive managementmeetings · Sustainability Website · Industrial Associations                                                        | · Collect global NGOopinions,engagewithRBA 1) , RMI 2) ,EPRM 3) ,UNGC 4) , ACEC 5) , SCC 6) amongothers                                                             | · Collect global NGOopinions,engagewithRBA 1) , RMI 2) ,EPRM 3) ,UNGC 4) , ACEC 5) , SCC 6) amongothers                                                                   |
|                | Organizations                                                 |                                                                                                                           | ·                                                                                                                                             |                                                                                                                                                                                           |                                                                                                                                                         | 1) Responsible Business Alliance 2) Responsible Minerals Initiative 3) European Partnership for Responsible Minerals                                                | 4) United Nations GlobalCompact 5) Asia Clean Energy Coalition 6) Semiconductor Climate Consortium                                                                        |
|                | Government                                                    | · Indirect economic effects, including investment/employment · Fair trade                                                 | · Occupational health &safety · Compliance · Business ethics                                                                                  | · Policy dialogue · Parliament · Policy public hearings                                                                                                                                   | · Policy advisory boards · Sustainability Website                                                                                                       | · Support SMEsin collaboration with the government                                                                                                                  | · Operate joint venture investment windows with the government                                                                                                            |
|                | Media                                                         | · Key product/business performance and strategy · Future growth strategies (investments,R&D,M&A, newbusinesses)           | ·Achievementsinpromotingsustainable management,includingnetzero · HR, labor relations, health safety, patents, product &service quality, etc. | · Press releases · Sustainability Website · SamsungSemiconductorNewsroom                                                                                                                  | · SamsungElectronicsNewsroom · Media briefings                                                                                                          | · Support media reporting on global IT exhibitions and newproduct launches · PRactivities                                                                           | · Arrange interviews &press conferences · Participate in media days                                                                                                       |

09

<!-- image -->

We dream of a better world, a better planet.

| DXDivision                    |   DXDivision | DSDivision                    |   DSDivision |
|-------------------------------|--------------|-------------------------------|--------------|
| Governance and Major Progress |           11 | Governance and Major Progress |           21 |
| Climate Change                |           12 | Climate Change                |           22 |
| Circular Economy              |           16 | Circular Economy              |           27 |
| Water                         |           18 | Water                         |           29 |
| Pollution                     |           20 | Pollution                     |           32 |

<!-- image -->

## Governance and Major Progress

## Governance

The Board of Directors of Samsung Electronics is our highest decisionmaking body, and the Sustainability Committee under the Board approves and oversees environmental strategies, goals, and major activities related to climate change and resource circularity. In 2022, the Sustainability Committee resolved the " New Environmental Strategy ", which encompasses long-term targets on subjects such as climate change response and resource circularity. The Committee annually reviews major achievements as part of its agenda since 2023.

<!-- image -->

The DX Division Head is responsible for key issues including establishing environmental management strategies, identifying implementation tasks, and executing investments. The Division Head operates the Sustainability Council with participation from Heads of Business Units and relevant Departments. In 2024, the Council was held 3 times, sharing annual plans and progress of key tasks across business units and related departments.

The Corporate Sustainability Center, the Global EHS Office, regional environmental dedicated organizations, and business unit sustainability offices oversee the execution of environmental management plans. Interdepartmental committees are operated to facilitate smooth discussions. The Environmental Safety Meetings manages and supervises greenhouse gas (GHG) emissions. Additionally, an ESG Disclosure Task Force responds to climate-related disclosure regulations, performing activities such as establishing GHG emission calculation standards and building management systems. In 2022, the "Circular Economy Lab" was formed to research material recycling technologies and product applications, aiming to replace product materials with recycled ones.

Since 2021, we added to our organizational and executive evaluations elements such as GHG reduction performance, renewable energy (RE) transition, development of high-efficiency products, waste recycling, and water resources management.

<!-- image -->

<!-- image -->

<!-- image -->

Environmental Management System

Environmental Management Governance

Environmental Risk Management

<!-- image -->

## Major Progress

## 2024 Progress and 2025 Targets

| Environmental Targets   | Environmental Targets                                                                                                                                                                                                                                                                                                                                                                             | 2024Progress                                                                                                                                                                                                                                                        | 2025Target                                                                                                  |
|-------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------|
| Climate Change          | · Achieve net zero emissions (Scope 1 and 2) · Improve power consumption of major models in 7 product categories 2) by30% 3) · 100%REtransition for DXbusiness sites 2030 2027                                                                                                                                                                                                                    | · Achieved Scope 1 and 2 emissions of: 340k tonnes CO₂e 1) · Achieved renewable energy transition rate of: 93.4% · Improved power consumption of major models in 7 product categories 2) by 31.5% 3) on average                                                     | · Achieve Scope 1 and 2 emissions of: 320k tonnes CO₂e 1) · Achieve renewable energy transition rate of:94% |
| Circular Economy        | · Apply recycled plastic 4) to100% 5) of DXproduct plastic parts 6) · Collect a cumulative 25 million tonnes of e-waste (since 2009) 2050 · Apply recycled plastic 4) to50% 5) of DXproduct plastic parts 6) · Expand e-waste recovery to all global sales regions, cumulatively collect 10 million tonnes of e-waste (since 2009) 2030 · Obtain Platinum Zero Waste-to-Landfill validations 2025 | · Applied recycled plastic 4) to31% 5) ofDXproduct plastic parts 6) (Cumulative769thousandtonnes 7) ) · Operated e-waste recovery program at approximately 80countries globally · Obtained Platinum Zero Waste-to-Landfill validations 8) in 18 manufacturing sites | · Obtain Platinum Zero Waste-to-Landfill validations in 22 global manufacturing sites                       |
| Water                   | · Replenish 100%ofwater used globally for DXDivision 2030                                                                                                                                                                                                                                                                                                                                         | · Achieved water replenishment rate of: 38.6% 9) (Korean sites' replenishment rate: 100%) · Received Alliance for Water Stewardship (AWS) Platinum certification at our Vietnam manufacturing site                                                                  | · Achieve water replenishment rate of:50%                                                                   |

1) Change in GHG emission calculation methodology (application of IPCC 2019, AR6)      2) Major models (2024): Refrigerator (RF91DB90LE01), air conditioner (AE120CXYBEK), washing machine (WD25DB8995BZ), TV(KQ75QND900FXKR), monitor (LS49DG952SKXKR), PC(NP960QGK), smartphone(SM-S928)      3) Compared to 2019 identical performance &amp; specifications 4) Pure recycled plastic ratios differ by part      5) Weight based ratio of parts with recycled plastic      6) Samsung Electronics developed plastic parts      7) Since 2009      8) Global environment and safety certifier UL Solutions approved      9) Replenishment progress audited by third-party external agency

Planet Facts &amp; Figures

<!-- image -->

11

Climate Change / Circular Economy / Water / Pollution

## Climate Change

## Strategy

The DX Division aims to achieve net zero Scope 1 and 2 emissions by 2030, focusing on reducing direct GHG emissions and expanding the use of renewable energy. Additionally, we identify and implement various tasks to reduce carbon emissions across the value chain, including logistics, sales, and usage of products.

<!-- image -->

<!-- image -->

## Direct GHG Emission Reduction

‧   Energy reduction activities including energy efficiency equipment installment and manufacturing process optimization ‧   GHG reduction project implementation for remaining emission reduction

## Indirect GHG Emission Reduction

‧ Utilize diverse RE procurement options to economically and sustainably secure RE ‧ Participate in global initiatives

<!-- image -->

## Value Chain Carbon Reduction

‧   Reduce value chain carbon emission from a product life cycle perspective including materials, production, transportation, usage, disposal, and recycling

## Risk Management

We manage risks related to business operations, product planning, and external trends based on environmental management systems such as ISO 14001 and ISO 50001. EHS departments monitor GHG emissions, energy usage, and climate impacts, and also regularly review issues on global sites, climate-related risks, and opportunities through joint environmental safety meetings with all relevant departments, the ESG disclosure Task Force, and the Sustainability Council. Climaterelated national regulatory risks are integrated into the company's risk management process. With respect to significant climate-related risks, the Sustainability Committee reviews and approves responses from relevant departments.

<!-- image -->

## Climate-Related Risk and Opportunity Analysis

The DX Division conducted a climate scenario analysis to systematically address major climate-related risks and opportunities. We identified key risks and opportunities arising from climate change and assessed the financial impacts of these risks and opportunities on the business under various climate scenarios 1) .  Based on the analysis, we are enhancing our response strategies to minimize major risks and capitalize on opportunities. The impact period for climate scenario analysis is set to short-term (within 1 year), medium-term (exceeding 1 year but not 5 years), and long-term (exceeding 5 years), considering our business strategy and net zero roadmap.

1)   Intergovernmental Panel on Climate Change (IPCC), International Energy Agency (IEA), Network for Greening the Financial System (NGFS) scenarios

## Climate-Related Risk and Opportunity Analysis Process

<!-- image -->

‧ Form climate related risks and opportunities pool ‧   Identify key risks and opportunities through climaterelated scenario analysis tools, stakeholder surveys, and inter-departmental roundtables

- ‧   Assess financial impacts of key risks and opportunities qualitatively and quantitatively under various climate change scenarios

‧   Assess mitigation and adaptation capacity to key risks' impacts, evaluate and consider leveraging key opportunities

- ‧ Refine strategies to address climate change

<!-- image -->

Climate Change / Circular Economy / Water / Pollution

## Key Risk and Opportunity Identification

We formed a pool of climate-related risks and opportunities related to our business by reviewing global climate change trends and industry responses based on a list of risks and opportunities presented by the TCFD 1) recommendations and CDP 2) .  We conducted surveys on the likelihood and impact size of these risks and opportunities among key internal and external stakeholders. Based on these results, we held inter-departmental roundtable meetings to discuss these results and finally identified major climate-related risks and opportunities.

Results show that key physical risks have impacts across the short-, medium-, and long-term, while transition risks and opportunities primarily have impacts in the medium- to long-term.

1) Task Force on Climate-related Financial Disclosures 2) Carbon Disclosure Project

## DX Division's Key Risks and Opportunities

| Type             | Type            | Risks andOpportunities                                                     | Risks andOpportunities                                                     | Risks andOpportunities                                                     | Risks andOpportunities                                                     |
|------------------|-----------------|----------------------------------------------------------------------------|----------------------------------------------------------------------------|----------------------------------------------------------------------------|----------------------------------------------------------------------------|
| Physical Risks   | Acute           | Typhoon                                                                    | Flood                                                                      | Wildfire                                                                   | Hail, Thunderstorm                                                         |
| Physical Risks   | Chronic         | Drought                                                                    | Extreme heat                                                               | Heavy rainfall                                                             | Extreme cold                                                               |
| Transition Risks | Policyand Legal | Increase in cost of purchasing carbon credits                              | Increase in cost of purchasing carbon credits                              | Increase in cost of purchasing carbon credits                              | Increase in cost of purchasing carbon credits                              |
| Transition Risks | Policyand Legal | Changes in laws and regulations related to climate change                  | Changes in laws and regulations related to climate change                  | Changes in laws and regulations related to climate change                  | Changes in laws and regulations related to climate change                  |
| Transition Risks | Market          | Increase in production cost due to rising electricity prices               | Increase in production cost due to rising electricity prices               | Increase in production cost due to rising electricity prices               | Increase in production cost due to rising electricity prices               |
| Transition Risks | Market          | Insufficient alignment with customerdemand for low-carbon products         | Insufficient alignment with customerdemand for low-carbon products         | Insufficient alignment with customerdemand for low-carbon products         | Insufficient alignment with customerdemand for low-carbon products         |
| Transition Risks | Technology      | Increase in R&Dcost for low-carbon products and services                   | Increase in R&Dcost for low-carbon products and services                   | Increase in R&Dcost for low-carbon products and services                   | Increase in R&Dcost for low-carbon products and services                   |
| Transition Risks | Reputation      | Stakeholder concerns and negative media coverage related to climate change | Stakeholder concerns and negative media coverage related to climate change | Stakeholder concerns and negative media coverage related to climate change | Stakeholder concerns and negative media coverage related to climate change |
| Opportunities    | Market          | Increase in demandforlow-carbon products and services                      | Increase in demandforlow-carbon products and services                      | Increase in demandforlow-carbon products and services                      | Increase in demandforlow-carbon products and services                      |
| Opportunities    | Market          | Use of renewable energy                                                    | Use of renewable energy                                                    | Use of renewable energy                                                    | Use of renewable energy                                                    |
| Opportunities    | Resilience      | Enhancing the supply chain's resilience to climate change                  | Enhancing the supply chain's resilience to climate change                  | Enhancing the supply chain's resilience to climate change                  | Enhancing the supply chain's resilience to climate change                  |

<!-- image -->

## Financial Impact Assessment

The DX Division assessed potential financial impacts expected under each climate scenario for the identified key risk and opportunity factors.

## Climate-Related Scenario Selection

We analyzed major risks and opportunities using various sciencebased scenarios that align with the latest international climate change agreements, including high-emission scenario and below 2℃ scenario. We analyzed physical risks using IPCC scenarios, and transition risks and opportunities using IEA and NGFS scenarios.

| Type                               | Source   | Scenario                   | Definition                                                                              |
|------------------------------------|----------|----------------------------|-----------------------------------------------------------------------------------------|
| Physical Risks                     | IPCC 1)  | SSP 4) 1-2.6               | Assumesnetzeroemissionsby2075 (Low-carbonemissionscenario) Assumescurrentlevelsofcarbon |
| Physical Risks                     | IPCC 1)  | SSP5-8.5                   | Assumesfossilfuel-baseddevelopment (High-carbonemissionscenario)                        |
|                                    | IEA 2)   | Net Zero Emissions by 2050 | Assumesnetzeroemissionsinthe energysectorby2050                                         |
|                                    | IEA 2)   | Announced Pledges          | Assumesfullimplementationof allnationalclimatecommitments worldwide                     |
| Transition Risks and Opportunities | IEA 2)   | Stated Policies            | Assumesmaintenanceand implementationofcurrentpolicies                                   |
| Transition Risks and Opportunities | IEA 2)   | Net Zero 2050              | Assumesglobalnetzeroemissionsby 2050                                                    |
| Transition Risks and Opportunities | NGFS 3)  | NDCs 5)                    | Assumesfullimplementation ofcurrentlypledgedNationally DeterminedContributionsworldwide |
| Transition Risks and Opportunities | NGFS 3)  | Current Policies           | Assumesmaintenanceand implementationofcurrentpolicies                                   |

1) Intergovernmental Panel on Climate Change   2) International Energy Agency 3) Network for Greening the Financial System   4) Shared Socio-economic Pathway 5) Nationally Determined Contributions

1. Physical Risks For each site 1) , we evaluated the level of exposure to physical risks and assessed financial impacts of floods, typhoons, droughts, wildfires, and extreme heat, using a global analytics tool 2) that incorporates modeling data and location information. In all 3 IPCC scenarios, floods had the biggest financial impact among the 5 physical risks.

1) All manufacturing sites, key storage facilities, etc.

2) Climate and disaster prediction model, national meteorological administration data, etc.

Flood The financial impact of floods was assessed based on the recurrence interval, inundation depth, and elevation level of the region in which each site is located. The results show that Asia has the highest financial impact

<!-- image -->

## Assessment of Financial Impact Levels from Floods (Short/Mid-/Long-Term, Scenario Averages)

<!-- image -->

among DX operations. In particular, certain manufacturing sites in Vietnam and India were evaluated as having relatively high financial impacts. It was analyzed that as climate change intensifies, even floods with recurrence intervals similar to those in the past are likely to result in deeper inundation levels. Consequently, physical damage to assets such as buildings, equipment, and inventory may occur, leading to a decline in asset value. In addition, production delays may cause revenue losses, resulting in potential financial losses.

2. Transition Risks and Opportunities We developed a methodology for assessing the financial impacts of transition risks and opportunities through literature review and consultation with external experts. Financial impacts were derived using both internal roadmap, such as our New Environmental Strategy, and external projection data from IEA and NGFS scenarios. The increase in electricity prices and the increase in cost of purchasing carbon credits emerged as key transition risks, while the use of renewable energy and increase in demand for low-carbon products and services emerged as significant opportunities. The below explains how some of these factors influence our operation as risk or opportunity.

Increase in Cost of Purchasing Carbon Credits As GHG regulations and policies become more stringent, we expect the price of carbon credits and the percentage of paid allocations to increase as well. As a regulated entity under the Korean Emissions Trading System (ETS) scheme, the DX Division is required to purchase carbon credits if our greenhouse gas emissions exceed the nationally allocated quotas. If the price of carbon credits in the ETS and the proportion of paid quotas increases, we expect that the operational costs associated with purchasing carbon credits may increase.

<!-- image -->

Increase in Demand for Low-Carbon Products and Services Increasing consumer awareness of climate change is driving preference for lowcarbon products and services, and national net zero policies and regulations are driving demand for low-carbon products. We see that the increasing demand for low-carbon products and services could be a long-term opportunity given our current business portfolio and business plans.

## Resilience Assessment

We conducted a resilience assessment based the results of the financial impact assessment and current countermeasures to risks and opportunities. We aim to enhance our climate resilience capabilities through systematic management of our operational sites in response to climate change and the implementation of our New Environmental Strategy.

Flood During the site selection process for manufacturing sites, we conduct risk assessments that include analysis of maximum regional precipitation, periods of heavy rainfall, and nearby river conditions. In the design phase, construction on ground level elevation is carried out to prevent potential flood damage. Flood risk simulations are performed to identify hazardous areas, and appropriate drainage and flood protection systems are installed. In addition, we have an emergency response system in place and conduct periodic on-site inspections and drills to ensure preparedness.

Increase in Cost of Purchasing Carbon Credits To mitigate the financial impact of increasing cost of purchasing carbon credits, we are implementing emission reduction initiatives such as reducing electricity consumption and increasing the use of renewable energy. In addition, we closely monitor policy developments related to the ETS and fluctuations in carbon credit prices to establish and execute strategies to optimize the purchase, sale, and retention of carbon credits.

Increase in Demand for Low-Carbon Products and Services We are making efforts to create low-carbon products from a product life cycle perspective, covering stages from material sourcing, production, and disposal, to recycling. We are expanding the application of circular materials such as recycled plastics in products, developing technologies to improve product energy efficiency, and providing services that reduce power consumption of home appliances through the SmartThings AI Energy mode solution. To extend product lifespan, we are improving product durability and repairability, supporting software upgrades, and are operating an e-waste collection system. We expect that continued development of lowcarbon products and services will contribute to addressing climate change and lead to revenue growth.

We will periodically analyze and calculate the financial impacts of climaterelated risks and opportunities, enhance our climate resilience, and strengthen long-term business competitiveness.

<!-- image -->

13

## Activities

## Direct GHG Emission Reduction

The DX Division prioritizes activities to minimize GHG emissions from our facilities, such as improving energy efficiency, reducing energy consumption, and transitioning to renewable energy, with the goal of achieving net zero Scope 1 and 2 emissions by 2030. We set annual energy reduction targets for global manufacturing sites and monitor reduction activity performance, and are transitioning 1) Korean business vehicles to zero-emission vehicles (electric, hydrogen).

For emissions that are difficult to reduce through internal efforts, we identify and implement GHG reduction projects to offset emissions. In 2024, we identified and carried out agroforestry projects in India, Egypt, and Madagascar, as well as mangrove restoration projects, securing an additional 460,000 tons of external reduction credits.

Agroforestry projects not only contribute to GHG reduction but also serve as initiatives that can enhance the income of local residents by cultivating specialty crops in the project areas. Mangroves, which primarily inhabit saline wetlands near river estuaries, provide ecosystems for both terrestrial and marine flora and fauna while exhibiting a carbon absorption rate approximately 5-10 times higher than typical land-based plants.

We plan to continuously discover external nature based GHG reduction projects. We prioritize Carbon Dioxide Removal (CDR) projects that can permanently remove GHG while also considering the improvement of local residents' quality of life and income, protection of terrestrial and marine ecosystems, and conservation of biodiversity, aligning with the UN Sustainable Development Goals (SDGs).

1)  Cumulatively transitioned 64 vehicles by end of 2024.

[Mid- to Long-Term Roadmap, Direct GHG Emission Reduction](https://www.samsung.com/global/sustainability/planet/climate-action/#anchor1)

[GHG Reduction Project Identification](https://www.samsung.com/global/sustainability/planet/climate-action/#AYUphhy6FUgAIx-G)

## Indirect GHG Emission Reduction

The DX Division has set a goal to transition 100% of the power usage at all its business sites to renewable energy by 2027. In 2024, we signed new PPAs (Power Purchase Agreements) for domestic manufacturing sites and expanded renewable energy power procurement through PPAs in manufacturing sites in India, Mexico, Brazil, Vietnam, and China. We plan to continue identifying PPAs that contribute to renewable energy expansion.

## [Mid-to Long-term Roadmap, Renewable Energy](https://www.samsung.com/global/sustainability/planet/climate-action/#anchor2)

## Renewable Energy Status by Key DX Division Regions

United States Through solar facility installations and the renewable energy certificates (RECs) purchases, we transitioned 100% of U.S. power usage to renewable energy since 2020.

Europe Since 2020, we transitioned 100% of European power usage to renewable energy through the Green Pricing system and the purchase of Renewable Energy Certificates (RECs).

India Through renewable energy PPAs with solar and wind power generators and the purchase of RECs, we transitioned 100% of Indian manufacturing sites' power usage to renewable energy since 2022.

Vietnam/China We transitioned 100% of our Vietnamese manufacturing sites' power usage to renewable energy since 2022 by purchasing RECs. We also plan to expand and implement PPAs in accordance to the enforcement of the country's PPA regulation.

<!-- image -->

Planet We transition 100% of our Chinese manufacturing site's power usage to renewable energy since 2022 through renewable energy PPAs (solar) and REC purchases. We intend to expand PPAs by signing wind power PPAs.

Latin America We transitioned 100% of our Brazilian manufacturing sites' power usage to renewable energy in 2022 through REC purchases, also receiving renewable energy through PPAs with wind power generators. We provide renewable energy power through PPAs with solar and wind power generators to our Mexican manufacturing site. We plan to continue expanding renewable energy PPAs to achieve 100% renewable energy for our manufacturing sites in Latin America by 2025.

Republic of Korea We transitioned 100% of our Korean sites' power usage to renewable energy since 2022 by utilizing the Green Pricing system and installing solar power facilities at several sites. The Gumi and Gwangju sites have been receiving renewable energy since 2024 after signing solar PPAs.

[Business Site Electricity Use Reduction](https://www.samsung.com/global/sustainability/planet/climate-action/#AZZHvPp6IlIALYMa)

<!-- image -->

14

## Value Chain Carbon Reduction

We support carbon reduction activities across the value chain, including partners, consumers, and others, to minimize carbon emissions throughout the product lifecycle-from materials, production, transportation, usage, disposal, and recycling.

[Mid-to Long-term Roadmap, Value Chain Carbon Reduction](https://www.samsung.com/global/sustainability/planet/climate-action/#anchor3)

## Upstream Reduction Activities

We promote GHG reduction activities among our top 90% suppliers by transaction amount. We monitor suppliers' GHG emissions, collects and manages information on reduction targets annually, and provide education and consulting on carbon reduction methods. Additionally, we encourage the use of renewable energy by awarding comprehensive evaluation points to suppliers with outstanding emission reduction performance. In 2024, we held an information session to introduce rooftop solar power generation projects to support suppliers considering a transition to renewable energy, at which 138 suppliers 1) attended.

1) Including DX and DS Division suppliers

## Downstream Reduction Activities

Product use phase carbon emissions take up the largest portion of DX Division Scope 3 emissions. We have set a target to apply low-power technologies across representative models of smartphones, TVs, refrigerators, washing machines, air conditioners, PCs, and monitors to reduce power consumption by an average of 30% by 2030 compared to identical performance/specification models in 2019. In 2024, we improved power consumption for leading models of 7 major product categories by an average of 31.5% compared to 2019 levels.

## Improvements for DX Division Product Energy Use

<!-- image -->

## Product Life Cycle Assessment (LCA)

Life Cycle Assessment (LCA) is used to quantitatively evaluate potential environmental impacts that may occur throughout the entire lifecycle of a product, from the processing of raw materials and components to manufacturing, transportation, usage, and disposal.

We conduct LCAs for leading models by product category 1) and use the results to identify and improve key environmental impact factors.

In 2024, we newly established LCA standards and processes for 13 product categories and received verification from Lloyd's Register Quality Assurance (LRQA), an internationally recognized certifier, confirming that our standards and processes comply with relevant standards (ISO 14040, ISO 14044, ISO 14067). LCA Results

1)   Products subject to Life Cycle Assessment (LCA) include smartphones (all models from 2023 onwards), TVs/monitors (select models sold in Europe from 2025 onwards), tablets/notebook PCs/watches (all models from 2024 onwards), and home appliances including refrigerators/ washing machines/air conditioners (models sold in Europe, the United States, Canada, and Korea from July 2024 onwards). Jointly manufactured (JDM) products are excluded.

## Development and Operation of LCA System

LCA requires a wide range of data, from product information such as materials, weight, and power consumption to process information like water and electricity usage.

We built an LCA automation system within the Sustainability Data Platform (SDP) 1) to  enhance the calculation and management of product carbon footprints and LCAs.By integrating all data used in LCAs through this system, we automated treatment of previously manually collected and process data and improved system accuracy by enabling our product experts to directly manage automatically generated results. In the future, we plan to expand the scope of LCA automation to better manage the environmental impacts of each product and use the information to communicate with stakeholders.

1)   A platform for integrating ESG data and processes within the DX Division to respond to global ESG regulations, mandatory disclosures, and customer requirements.

## Collaborative Efforts on Climate Action

We strive to contribute to climate change response by engaging with various stakeholders through Korean and global initiatives such as RE100, ACEC, and the CF Alliance, as well as through external communication activities.

Through multiple channels, we participated in policy recommendations and shared industry opinions on the need for stably purchasing renewable energy, boosting Power Purchase Agreement (PPA) regulations, and expanding renewable energy supply. Notably, in Vietnam, one of our major production countries, we actively advocated for the introduction of renewable energy PPA systems to relevant government offices, and Vietnam Electricity (EVN). As a result, the Direct Power Purchase Agreement (DPPA) regulation was established in 2024. We signed solar power PPA contracts at our Vietnamese manufacturing sites and are communicating with various stakeholders to promote improvements to the system.

[Collaboration on Renewable Energy Expansion and Climate Action](https://www.samsung.com/global/sustainability/planet/climate-action/#AY5zHAG62MUAIx-T)

## Initiative

· RE100 Membership and Advisory Committee Participation ·   Joined ACEC 1) as a founding member, participating in its Operating Committee, Strategy Advisory Group, and Country Working Groups ·   Participating in the CF Alliance 2) as a member of the Board of Directors and Working Groups · Participating in CoREi 3) , DUCD 4)

1) Asia Clean Energy Coalition 2) Carbon Free Alliance 3) Corporate Renewable Energy Initiative

4) Decarbonizing the Use phase of Connected Devices

## Policy Engagement

·   Renewable Energy Industry CEO Meeting, RE100 Corporate Meeting (Ministry of Trade, Industry, and Energy)

·   Corporate PPA Activation Meeting (Korea Energy Agency)

·   Following the enactment of Vietnam's DPPA decree (July 2024), recommendations for PPA activation and system improvement

15

## Circular Economy

## Strategy

The DX Division conducts various activities to maximize resource circularity throughout the entire product lifecycle, from raw material procurement to production, use, disposal, and recycling. By expanding the use of resource circular materials, operating a system for collecting end-of-life products, and pursuing Zero-Waste-to-Landfill validation, we are operating a "resource circular system." This system involves producing products using recycled materials, collecting end-of-life products to extract resources, and then using these resources as materials for new products. Additionally, we research methods to extend product lifespan, aiming to minimize the environmental impact of its products.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## Expand Use of Recycled and Recyclable Materials

‧   Develop innovative technologies addressing plastic debris, such as recycling discarded fishing nets

- ‧   Continuously expand use of recycled materials such as aluminum and glass
- ‧ Use resource-circular packaging materials

## Operate e-Waste Collection System

‧   Retrieve post-consumer use products &amp; extract resources to reuse as product raw materials

## Reinforce Business Site Waste Management

‧   Establish and conduct validation for Zero-Waste-to-Landfill policy

-   Push for recognition of recycled resources by the Ministry of Environment to reduce waste emissions

## Extend Product Life Cycles

‧   Improve product durability and repairability and support software upgrades to extend product lifespan

- ‧   Reduce consumer burden for damage and repairs through Samsung Care+

## Risk Management

We apply a 4 step approach of risk recognition → assessment → treatment → progress management so as to systematically manage our resource circularity related risks.

Resource circularity related risks include items such as waste treatment cost increase, treatment facility and technology limits, and lack of consumer awareness. In response, we made product lifecycle responsibility a key agenda item under our Environmental and Safety Policy .  We purchase raw materials, components, and packaging materials that minimize environmental impact and continuously strive to reduce resource use and environmental impact across all stages of product development, manufacturing, logistics, use, and disposal. Meanwhile, we recognize the recycling of waste, including plastics, as an opportunity to reduce processing costs and explore new markets through the development of recycling technologies. We also pay attention to the potential of turning risk factors into opportunities.

## Circular Economy Risk Management Process

<!-- image -->

<!-- image -->

## Activities

## Expand Recycled and Recyclable Materials Use

We are striving to introduce and utilize recycled and recyclable materials. We especially recognize the serious impact plastic waste has on marine environments and developed innovative technologies to recycle discarded fishing nets. We are also continually expanding our scope of recycled and recyclable materials such as recycled aluminum and glass.

In 2025, we applied recycled and recyclable materials including not only plastic, rare earth metals, steel, and glass but also gold, copper, cobalt, and aluminum to our Galaxy S25 series. We also applied recycled aluminum materials to the Galaxy S25 and S25+ frames.

We established a Circular Battery Supply Chain for the Galaxy S25 by utilizing recycled cobalt extracted from previously used Galaxy smartphones and batteries discarded during the manufacturing process. We newly applied recycled plastic from waste wafer trays used in semiconductor manufacturing processes.

We also applied recycled graphite materials extracted from waste batteries to graphite used in our 2024 and 2025 Neo QLED 8K TV models' for internal thermal insulation.

<!-- image -->

## [Continued Expansion of Recycled Material Usage](https://www.samsung.com/global/sustainability/planet/circular-economy/#AYpFQs76m5oAIx-K)

<!-- image -->

<!-- image -->

16

We also practice resource circularity in our product packaging and reduce our environmental impact by replacing plastic and vinyl with recycled materials, as well as making our packaging smaller and lighter.

[Mid-to Long-Term Roadmap, Recycled/Recyclable Material Expansion](https://www.samsung.com/global/sustainability/planet/circular-economy/#anchor1)

Recycled/Recyclable Packaging Material Use Case by Product  Category  -

[Visual Displays Digital Appliances](https://www.samsung.com/global/sustainability/planet/circular-economy/#AYUpnh5qAw0AIx_C)

[Mobile Appliances](https://www.samsung.com/global/sustainability/planet/circular-economy/#AYUpnu8aA14AIx_C)

## E-waste Collection System

We operate various recycling programs for waste products across approximately 80 countries to promote global e-waste recycling. We collect materials regardless of brand and consider national context to effectively operate our waste material recovery and recycling system via either directly operated recycling centers or partnered recycling associations and companies.

We recovered a total of 6.91 million tonnes of e-waste from 2009 through the end of 2024. We will expand our waste product recovery program to all regions with product sales, and plan to recover a total of 10 million tonnes by 2030 and 25 million tonnes by 2050.

[E-waste Take-Back Operation Recycling Programs by Country](https://www.samsung.com/global/sustainability/planet/circular-economy/#recyclingprograms)

[Waste Product Recovery System by Region](https://www.samsung.com/global/sustainability/policy-file/AYVheAP6CSMAIx95/Waste%20Product%20Collection%20System%20by%20Region.pdf)

[Requirements for Recycling Service Partners](https://www.samsung.com/global/sustainability/policy-file/AYVhVH2KCBMAIx95/Requirements%20for%20Recycling%20Service%20Partners.pdf)

## E-waste Recovery and Recycling Process

Retrieve e-waste

·   Operate retrieval/recycling program through recycling centers, regional logistics centers, and customer cellphone retrieval programs

Extract valuable resources

Recycle extracted resources

·   Extract resources such as copper, aluminum, iron, and plastic through preprocessing including sorting and shredding

·   Use extracted resources in our parts and product manufacturing

## Amount of Collected e-waste

<!-- image -->

## Reinforce Business Site Waste Management

We newly developed press molds for manufacturing TV and monitor components to enhance raw material usage efficiency. This has reduced the size of used sheet metals and decreased scrap generation by 20%. Additionally, we are striving to minimize our environmental impact by reducing waste generation and increasing recycling rates at our sites.

[Raw Material Use Efficiency Improvements](https://www.samsung.com/global/sustainability/planet/sustainable-operations/#AYlwobMqFKgAIx-n)

## Obtain Business Site Zero Waste-to-Landfill Validation

We aim to receive the highest level of Platinum Zero Waste-to-Landfill validation 1) for 22 of our global manufacturing sites to minimize resource waste and continually decrease negative impacts on the environment. To this end, each site recycles previously landfilled or incinerated manufacturing process waste into goods such as cement materials or recycled fuel. We also work on recyclable waste sorting by establishing new waste sorting processes, and recover as much useful energy as possible such as heat or steam even when materials are not recyclable and must be incinerated. We plan to continually improve our waste recycling rate through such circular waste management systems.

[Zero Waste-to-Landfill Validation](https://www.samsung.com/global/sustainability/planet/sustainable-operations/#zerowastetolandfill)

## Platinum Certified 2)

Korea: Suwon, Gwangju

Global:   China, Slovakia, India (Chennai, Noida), Poland, Egypt, Türkiye, Brazil (Campinas, Manaus), Vietnam (Hanoi(2)), Indonesia, Mexico (Tijuana, Querétaro), Thailand, USA

## Gold Certified 2)

## Korea: Gumi Global: Hungary, Vietnam (Hồ Chí Minh), Malaysia

1)   evaluates a company's resource circularity efforts and assigns validations based on the percentage of waste generated by a business that is diverted from landfills. Platinum 100%, Gold 95-99%, Silver 90-94%, Certified 80% or higher (decimals are rounded up, 99.5% is rounded up to 100%)

2) as of December 2024

Planet

## Recognition of Circular Resources

Since 2024, we are pursuing the Korean Ministry of Environment's Quality Mark Certification for Circular Resources which recognizes valuable waste material not hazardous to human health or the environment as resources. In 2024, we identified 21 circular resource recognizable items in 3 Korean sites via on-site consultations, of which 3 were recognized as circular resources. We expect a reduction of approximately 2,000 tonnes of waste through these recognitions. We seek to have all 21 items recognized as circular resources and reduce a total of approximately 9,000 tonnes of waste by 2027 .

[Circular Resource Recognition](https://www.samsung.com/global/sustainability/planet/sustainable-operations/#AYUqOPtaB-QAIx_C)

## In-house Waste Reduction

We implemented measures to reduce in-house single-use items. We distributed eco-bags to employees to minimize the use of disposable plastic bags and transitioned to reusable tableware and drink cups in company cafeteria and cafes. Additionally, we installed 480 food waste processors in breakrooms at the Suwon and Gwangju sites to separate food waste from general waste and convert it into compost.

## [In-house Waste Reduction](https://www.samsung.com/global/sustainability/planet/sustainable-operations/#AYUqOo_KCBIAIx_C)

## Extend Product Life Cycles

Shorter product life cycles increase resource usage and carbon emissions. We are enhancing our products' durability and reparability and providing software updates to increase product use periods and minimize their environmental impacts. We are also extending our products' life cycles through our Certified Re-Newed (CRN) program. 1)

1) Operated in Korea and the USA (as of April 2025)

## Product Life Cycle Extension

[Increase Durability](https://www.samsung.com/global/sustainability/planet/circular-economy/#AYUpofoqA-MAIx_C)

- [Consider Repairability](https://www.samsung.com/global/sustainability/planet/circular-economy/#AYUpoOHaA6gAIx_C)
- [Upgradability](https://www.samsung.com/global/sustainability/planet/circular-economy/#AYUposjaA_oAIx_C)
- [Certified Re-Newed (CRN) Program](https://www.samsung.com/global/sustainability/planet/circular-economy/#AYpFUtkKn7oAIx-K)
- [Product Repair Services](https://www.samsung.com/global/sustainability/planet/circular-economy/#AYUpo8JKBBsAIx_C)

<!-- image -->

17

## Strategy

The DX Division pursues sustainable water resource usage through systemic water resource management, water replenishment projects, and aquatic ecosystem preservation activities. We categorize used water into sewage, wastewater, process water, and ultra-pure water to increase the reutilization rate of water used across our global manufacturing sites. We restore water that is ultimately consumed and not returned to the local environment through external water replenishment projects, and continually carry out various activities to protect and improve site-adjacent watersheds' aquatic environment.

## [Water Resource Management Mission and Vision](https://www.samsung.com/global/sustainability/planet/sustainable-operations/#AYlwqxX6FUIAIx-n)

<!-- image -->

<!-- image -->

<!-- image -->

## Systemic Water Resource Management

‧   Reduce/recycle water used in manufacturing process via detailed water resource management at global manufacturing sites ‧   Obtain Alliance for Water Stewardship water management

- certifications

## Water Replenishment Projects

‧   Preserve water resources through water replenishment projects for all manufacturing sites

<!-- image -->

## Aquatic Environment Preservation

‧   Perform aquatic environment preservation activities including recycling discarded fishing nets, developing microplastic reducing products, and monitoring ecological indicators

## Risk Management

We perform annual analysis on whether a business site is located in a water stress or water risk region detailing potential water resource risks. We apply water resource management tools from internationally recognized bodies like the World Resource Institute's (WRI) 1) to identify water stress or risk regions, then establish and execute response strategies per water resource risk based on the Carbon Disclosure Project (CDP) Water Guidance.

1)   Aqueduct Water Risk Atlas standard: Regions evaluated as High (3) or above based on metrics including water resource quantitative and qualitative data, regulation, and reputation risk

<!-- image -->

We recognize droughts, floods, and ecosystem imbalance as water resource risks and establishes and implements response strategies for each. To prepare for droughts, we developed an Emergency Response Plan for Droughts and regularly monitor water usage and drought indicators. For flood response strategies, we established a flood prevention and reporting system across all business sites by setting criteria for issuing alerts and defining response measures, and conducted regular training accordingly. At each site, we collaborate with local governments to carry out regular cleanup activities and support the restoration of aquatic ecosystems to conserve natural ecosystems.

## [Water Risk Assessment](https://www.samsung.com/global/sustainability/planet/sustainable-operations/#AYUqiWq6CUgAIx_C)

<!-- image -->

| DXDivision Status for Sites in Water Risk Regions   | DXDivision Status for Sites in Water Risk Regions   | DXDivision Status for Sites in Water Risk Regions   | DXDivision Status for Sites in Water Risk Regions   | (as of 2024)   |
|-----------------------------------------------------|-----------------------------------------------------|-----------------------------------------------------|-----------------------------------------------------|----------------|
|                                                     | Unit                                                | Sites                                               | Withdrawal                                          | Release        |
| Total                                               | 1,000 Tonnes                                        | 25                                                  | 18,961                                              | 15,446         |
| WaterRiskRegions 1)                                 | 1,000 Tonnes                                        | 10 2)                                               | 2,594                                               | 2,038          |

- 2)   Number of water risk sites by country: India(2), Mexico(2), Poland(1), Egypt(1), China(1), Thailand(1), USA(1), Indonesia(1)

## Activities

## Systemic Water Resource Management

We are decreasing our water withdrawal through installation of water saving facilities at all our sites, and increasing our water reuse by expanding reuse of graywater from treated wastewater. We are also pursuing various water use reduction activities including using groundwater and rainwater for landscaping and everyday purposes.

## [Water Conservation and Reuse Efforts](https://www.samsung.com/global/sustainability/planet/sustainable-operations/#AYUqhwkKCP4AIx_C)

## Water Reuse Amount

2,737 thousand tonnes

* Water reuse to withdrawal ratio: 14.4%

<!-- image -->

## Water Replenishment Amount

thousand tonnes

1,358

* Water replenishment to use ratio: 38.6%

<!-- image -->

Climate Change / Circular Economy / Water / Pollution

Our Suwon, Gumi, and Gwangju manufacturing sites in Korea and SEV, SEVT, SEHC 1) subsidiaries in Vietnam obtained the highest level of 'Platinum' certification from the Alliance for Water Stewardship 2) (AWS) in February 2024. We consider this a testament to the superiority of our water resources management system and plan to expand certification status to our Indian subsidiary in 2025.

1) Aquired in 2025

- 2)   AWS was established by leading water organizations, including the United Nations, international NGOs, and research institutes, in response to the global water challenge. AWS certifies a company's water resource management system into three levels of 'Platinum', 'Gold', and 'Core' based on a total of 100 evaluative items like the company's water management stability, water contaminant management, water quality and hygiene, impact on aquatic ecosystem in nearby watersheds, and governance structure.

## [Water Resource Management Process](https://www.samsung.com/global/sustainability/planet/sustainable-operations/#AYUqiByKCSUAIx_C)

[AWS Certifications](https://www.samsung.com/global/sustainability/planet/sustainable-operations/#AYh0f1raiTgAIx-n)

<!-- image -->

<!-- image -->

## DX Division Water Resource Flow Chart (2024)

(unit: 1,000 tonnes)

<!-- image -->

<!-- image -->

18

## Water Replenishment Projects

Water use is a necessary part of a product's manufacturing process and we are treating and returning used water to the natural environment. But some water is inevitably consumed in this process. We established a goal to return as much water as is consumed in our '100% water replenishment by 2030' target, and are minimizing our environmental impact by returning utilizable water resources to stakeholders and local communities through water replenishment projects.

We signed a Memorandum of Understanding (MOU) with the Korean Rural Community Corporation in 2023, and piloted projects supporting agricultural water reuse in island communities facing water shortages. We expanded replenishment projects to 7 Korean sites and 16 global sites, carrying out projects in cooperation with respective local governments, public institutes, and NGOs. We achieved a water replenishment rate of over 100% for Korean sites through such efforts. We plan to expand replenishment projects to all global manufacturing sites by 2030 to contribute to our water resource conservation efforts.

## [DX Division Water Resource Replenishment Status](https://www.samsung.com/global/sustainability/planet/sustainable-operations/#AY8EB1vqLlcAIx9s)

<!-- image -->

## Reservoir Restoration Project - India, New Delhi

(Replenishes an approximate 100,000 tonnes of water per year)

Improve water quality (reservoir waste removal), increase reservoir capacity (floor dredging)

<!-- image -->

<!-- image -->

We calculate replenishment project performance using a global water resource replenishment methodology. We carried out performance audits with external institutes to remove potential calculation process errors and verify calculation methodology validity. We plan to continue external audits on replenishment projects to secure their accuracy and reliability.

## Water Resource Replenishment Project Performance

| Type   |   Projects | Water Replenished(㎥)   |
|--------|------------|-------------------------|
| Korean |          7 | 1,009,091               |
| Global |         16 | 348,425                 |
| Total  |         23 | 1,357,516 (38.6% 1) )   |

<!-- image -->

## Aquatic Environment Preservation

We engage in a variety of initiatives to protect marine environments and maintain ecosystem health. Discarded fishing nets are collected from the ocean and processed into components used in smartphones, TVs, vacuum cleaners, and more. We also collaborated with universities and nonprofit organizations to develop 'Ocean Mode,' a camera function optimized for underwater shooting, to contribute to coral reef restoration research. We also developed washing machines that reduce microfiber discharge by up to 60% per wash in an effort to protect marine ecosystems.

<!-- image -->

Recycled materials from discarded fishing nets

<!-- image -->

Coral reef restoration research support

<!-- image -->

Microplastic removing washing machines

We regularly monitor ecological indicators to secure the ecosystem health of our water replenishment projects. In particular, the Ogok Reservoir in Hamyang-gun, Gyeongsangnam-do, Korea, serves as both a source of agricultural water and a key habitat for local wildlife. We measure and manage water quality indicators-such as Total Nitrogen (TN) and Total Phosphorus (TP) 1) -and biological indicators such as fish, birds, and mammals. In 2025, additional assessments will be conducted at Korean sites to analyze the impact and dependence on biodiversity, reinforcing efforts to conserve ecosystems.

1)   TN, TP: Metrics indicating the total amount of nitrogen and phosphorus in water, used to assess water pollution levels and plays a key role in evaluating eutrophication in rivers and lakes.

## Ogok Reservoir and Surrounding Wildlife

Ogok Reservoir (Hamyang)

<!-- image -->

<!-- image -->

Leopard Cat (Class 2 endangered wildlife)

<!-- image -->

Otter (Class 1 endangered wildlife)

<!-- image -->

Mandarin Duck (Korean Natural Monument)

<!-- image -->

<!-- image -->

## World Water Day Activities

Every year, in celebration of World Water Day, the DX Division conducts activities to preserve river and marine ecosystems at our global manufacturing sites. Each site worked with local governments, NGOs, and students to conduct stream cleanup campaigns, hold awareness and education sessions, and perform ecosystem protection activities. In 2025, a total of 30,793 employees across 23 sites-including those in Korea, Vietnam, China, Brazil, and Mexico-participated.

<!-- image -->

<!-- image -->

## Water Replenishment Projects / AWS-Linked Events

In collaboration with local NGOs, governments, and residents, we carried out water purification and cleanup activities around water replenishment project sites and other areas including rivers, coastlines, and wetlands.

<!-- image -->

## Water Saving Campaigns

We installed water-saving facilities at business sites and conducted in-house campaigns to raise employee awareness about water conservation.

Water Awareness Initiatives To raise awareness of World Water Day, we organized educational activities for employees and nearby school students under the 2025 World Water Day theme of glacier preservation.

<!-- image -->

- Stream Aquatic  Ecosystem Protection

We monitored water pollution levels in rivers near business sites and planted trees along the riverbanks.

<!-- image -->

## Coral Reef Restoration Project

We are participating in coral reef restoration by collaborating with the non-profit organization "SeaTrees" and the Scripps Institution of Oceanography at the University of California, San Diego. We developed a custom camera mode mode called "Ocean Mode" 1) for Galaxy smartphones, enabling high-quality underwater photography of coral reefs. Using Ocean Mode allows the collection high-quality data with smartphones instead of bulky DSLR cameras, significantly enhancing the efficiency of coral reef restoration efforts.

1)   Ocean Mode is exclusively supported for this project and is not available in products for general consumers.

[Coral Reef Restoration Project](https://www.samsung.com/global/sustainability/planet/sustainable-operations/#AZZHvcMqImkALYMa)

<!-- image -->

<!-- image -->

19

## Pollution

## Strategy

The DX Division strictly complies with global environmental regulations 1) to minimize the potential negative impacts of substances of concern in products and chemicals used at sites on customer health and the environment. We continuously strengthen our internal management systems to ensure that all products and components are free from substances of concern and strictly limit our chemical usage. We also monitor environmental policies and regulations to ensure compliance with legal standards for water and air pollutants. We established internal emission standards to manage pollutants effectively, addressing stakeholder requirements and minimizing our impact on nature.

1)   EU Restriction of Hazardous Substances (RoHS), EU Registration, Evaluation, Authorisation and Restriction of Chemicals (REACH), US Toxic Substances Control Act (TSCA), etc.

## [EU REACH Declaration](https://www.samsung.com/global/sustainability/policy-file/AYVheSm6CV0AIx95/EU%20REACH%20SVHC%20Declaration.pdf)

<!-- image -->

## Risk Management

We conduct risk assessments for all hazardous materials or substances of concern whenever new equipment is introduced or responsible personnel, production layouts, procedures, or working condition are changed.

Once risks are identified, we evaluate the likelihood, consequences, contributing factors, and control measures, and develop possible incident scenarios assuming specific occurrence possibilities to assess potential impacts in advance and predict their impacts.

## Activities

## Management of Substances of Concern (SoC) in Products and During the Manufacturing Process

We operate a thorough pre- and post-management system for parts and raw materials. We set the Standards for the Control of Substances Used in Products , and voluntarily developed and implemented reduction plans for regulated and potentially hazardous substances 1) .

We also ensure that pollutants used throughout the supply chain are managed through the Eco-Partner Certification process, encouraging suppliers to participate in environmental initiatives. Suppliers are required to submit data from raw material providers and certificates of product environmental compliance to Samsung Electronics. We evaluate compliance with operation rules and the supplier's environmental quality management systems before granting certification. Only certified suppliers are eligible to conduct business with us.

1) Polyvinyl chloride (PVC), brominated fire retardants (BFRs), beryllium, antimony, etc.

## [Control of Substances Used in Products](https://www.samsung.com/global/sustainability/planet/sustainable-operations/#AYUqjP3KCboAIx_C)

As chemical substance regulations are strengthened world-wide and national regulatory subjects and standards become diversified, the importance of systemic chemical substance management is increasing.

## Eco-Partner Certification Process

<!-- image -->

<!-- image -->

Climate Change / Circular Economy / Water / Pollution

We regularly update chemical substance regulation database for 16 countries with manufacturing sites including China, Vietnam, and India, while minimizing risk by applying our own standards and through integrative management.

We manage all chemicals-related activities from purchasing to disposal via our system to secure chemical substance use safety. We are also enhancing our chemical substances management history process and system to readily identify whether internally regulated substances are contained in any chemical products that our employees intent to use, and are testing for such chemicals.

- [Chemical Substance Management Process](https://www.samsung.com/global/sustainability/planet/sustainable-operations/#AYUqjkr6CegAIx_C)
- [Manufacturing Process Used Regulated Substance](https://www.samsung.com/global/sustainability/planet/sustainable-operations/#AYUqjbUKCdEAIx_C)

## Pollutant Discharge Minimization and Incident Preparedness

We establish and adhere to stringent internal standards that exceed legal requirements to minimize production phase water pollutant discharge and air pollutant emissions and to proactively prepare for potential pollutant leaks or spills.

At each manufacturing site, we conduct wastewater discharge analysis more often than is required by legal standards to continuously comply with internal criteria. We maintain at least 10% excess capacity in water pollution control facilities in case of unexpected increases in pollutant inflow, and key components of these facilities are installed in duplicate to ensure uninterrupted operation in case of equipment failure.

Automatic gates, valves, other blockage facilities, measuring devices, and CCTVs tailored to the substances we handle and traits of surrounding watersheds are installed at the final stormwater discharge points. This ensures that pollutants can be immediately blocked in emergency situations.

Additionally, we participate in voluntary agreements such as the 'Particulate Matter Seasonal Management Program" managed by the Metropolitan Air Quality Management Office and the "Voluntary Agreement for Air Pollutant Reduction" managed by the Yeongsangang Basin Environment Management Office for our employees' health and the well-being of local communities.

<!-- image -->

20

## Governance and Major Progress

## Governance

The DS Division recognizes that environment is a critical area significantly influencing its business operations. The Sustainability Committee under the Board of Directors, the highest decision-making body of Samsung Electronics, and the ESG Management Council chaired by the DS Division's CEO, approve our environmental management strategies/goals and oversee key activities.

In 2022, the Sustainability Committee declared long-term goals through the " New Environmental Strategy ," in which key environmental targets such as addressing climate change and water resource management. Since 2023, the Committee has been incorporating key achievements related to these targets into its agenda and overseeing them accordingly.

To establish and implement environmental management plans and supervise implementations, We steer several core operational committees: the Carbon Reduction Committee, Environmental Conservation Committee, and Reuse Expansion Committee. The Carbon Reduction Committee oversees overall activities regarding climate change, including GHG emission monitoring; the Environmental Conservation Committee focuses on resource circularity and pollutant management; and the Reuse Expansion Committee sets detailed targets and manages implementation outcomes for water resource-related activities.

Environmental performance metrics such as greenhouse gas (GHG) reduction, renewable energy transition, and power savings are systematically integrated into our executives' and organizations' evaluations.

<!-- image -->

Environmental Management System Environmental Risk Management

<!-- image -->

<!-- image -->

<!-- image -->

[Environmental Management Governance](https://www.samsung.com/global/sustainability/planet/environmental-strategy/#AYUpd5hKFFYAIx-G)

<!-- image -->

## Major Progress

## 2024 Progress and 2025 Targets

| Environmental Targets   | Environmental Targets                                                                                                                                               | 2024Progress                                                                                                                                                                                                                              | 2025Targets                                                                                                                                                                                                                                                        |
|-------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Climate Change          | · Achieve net zero emissions (Scope 1 and 2) 2050                                                                                                                   | · Achieved Scope 1 and 2 emissions of: 14.55 million tonnes CO₂e 1) · Achieved renewable energy transition rate of: 24.8% · Develop high efficiency Regenerative Catalytic System (RCS) catalyst with treatment efficiency of97%          | · Achieve Scope 1 and 2 emissions of: 14.5 million tonnesCO 2 e · Achieve renewable energy transition rate of: 26% · Apply high efficiency RCS catalyst with treatment efficiency of97%                                                                            |
| Circular Economy        | · Obtain Platinum-grade Zero-Waste-to- Landfill validation for all global sites 2025 · Achieve 99.9% waste recycling rate 2) for Korean manufacturing sites 3) 2030 | · Achieved Korean manufacturing sites' recycling rate of 99.0% · Achieve 3 additional circular resource certifications · Obtain integrated Platinum-grade Zero-Waste- to-Landfill validation for all global sites                         | · Achieve Korean manufacturing sites' recycling rate of 99.2% · Achieve 5 additional circular resource certifications · Maintain integrated Platinum Zero-Waste-to- Landfill validation for our global sites                                                       |
| Water                   | · Reduce water withdrawal at Korean manufacturing sites to base year level 4) 2030                                                                                  | · Achieved Korean manufacturing sites' water reuse amount of 101 million tonnes · Achieved Alliance for Water Stewardship (AWS) Platinum certification for all Korean manufacturing sites                                                 | · Achieve Korean manufacturing sites' water reuse amount of 109 million tonnes · Secure water resource replenishment volume through restoration of Jangheung Damwetlands                                                                                           |
| Pollution               | · Develop newtechnology to treat manufacturing site air, water pollutants to natural levels 2040                                                                    | · (Air) Achieved Korean manufacturing sites' NOx emission reduction 5) of 508 tonnes · (Air) Acquired integrated organic/alkaline treatment technology patent · (Water) Modified chemicals (process) to reduce dissolved solids emissions | · (Air) Achieve Korean manufacturing sites'NOx emission reduction of 588 tonnes · (Air) Complete field setupfor300CMM 6) integrating organic/alkaline treatment technology · (Water) Research ion separation concentration and intermembrane absorption technology |

<!-- image -->

Climate Change / Circular Economy / Water / Pollution

<!-- image -->

21

## Climate Change

## Strategy

The DS Division has declared our commitment to achieving net zero Scope 1 and 2 emissions by 2050 and is actively working toward this goal by intensifying mitigation efforts under a long-term carbon reduction roadmap.

To reduce direct GHG emissions, technologies have been developed and implemented on-site. Additionally, efforts are being made to reduce indirect emissions through energy efficiency improvements and securing renewable energy sources. Furthermore, to systematically manage Scope 3 emissions, we established inventory systems and calculation methodologies including quantifying GHG emissions from suppliers within the supply chain and supporting them in setting reduction targets, thereby promoting comprehensive emission reduction activities across the semiconductor value chain.

To minimize our carbon footprint, quantitative assessments are conducted using Life Cycle Assessment (LCA) processes. Efforts are also underway to develop low-power semiconductor products aimed at reducing downstream emissions. Moving forward, we will continue to develop innovative technologies contributing to our net zero target, and further refine GHG emissions assessments as a robust foundation for ongoing emission reduction activities.

<!-- image -->

| DirectGHGEmissionReduction ‧ Enhance processgasmanagement · Reduce LNGfuel usage · Transition to Zero-Emission Vehicles                 |
|-----------------------------------------------------------------------------------------------------------------------------------------|
| IndirectGHGEmissionReduction ‧ Reduce power use · Expand renewable energy use                                                           |
| ValueChainCarbonReduction ‧ Upstream and downstreamreduction activities                                                                 |
| SemiconductorProductCarbonReduction ‧OperateproductLCAprocess&ProductCarbonFootprint(PCF)system · Enhance low-power product and process |

## Risk Management

We integrate climate-related risks into our overall risk management system for effective management. We identify, evaluate, and monitor physical risks like weather-related disasters and transition risks related to regulatory and market changes in each country based on ISO 22301, the international standard for Business Continuity Management System (BCMS). Based on these assessments, we develop comprehensive business continuity plans. In cases of acute risks such as typhoons or floods, we swiftly respond according to established emergency response procedures in order to minimize damage and promptly restore normal business operation. Additionally, we assess and monitor in real-time climate-related risks occurring at global sites based on risk management processes and manuals by function, including sustainability management, environment and safety, marketing, sales, and compliance. We continue to strengthen our response capabilities based on our climate-related risk management system, and report key risks and opportunities to the Sustainability Committee and ESG Management Council for review and response measures deliberations.

## [Business Continuity Management System](https://semiconductor.samsung.com/sustainability/highlights/business-continuity/)

<!-- image -->

## Climate-Related Risk and Opportunity Analysis

Identifying and managing climate-related risks and opportunities is crucial for creating new business opportunities and entering new markets. We established a climate-related risks and opportunities analysis process and assessed the financial impact on the business under various climate change scenarios. Based on this, we analyzed how effectively our business structure can respond to potential climate-related risks.

## Climate-Related Risk and Opportunity Analysis Process

<!-- image -->

| IdentifyKey Risksand Opportunities Assess Financial Impacts Assess Resilience   | ‧ Formclimate-related risks and opportunities pool ‧ Identify key risks and opportunities through climate- related scenario analysis, stakeholder surveys, and related department roundtables ‧ Assess financial impacts of key risks and opportunities qualitatively and quantitatively under various climate change scenarios ‧ Assess mitigation and adaptation capacity to key risks' impacts, evaluate and consider leveraging key opportunities ‧ Refine strategies to address climate change   |
|---------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

<!-- image -->

Climate Change / Circular Economy / Water / Pollution

## Identification of Key Risks and Opportunities

We constructed a pool of climate-related risks and opportunities related to our business by reviewing global climate change trends, industry responses, and the climate-related risks and opportunities presented in the Task Force on Climate-related Financial Disclosures (TCFD) recommendations and by the Carbon Disclosure Project (CDP). We also identified key risks and opportunities through climate-related scenario analysis, internal and external stakeholder surveys, and expert and departmental roundtable discussions. Identified physical risks were mainly chronic, affecting all short-, medium-, and long-term periods. Transition risks and opportunities primarily impacted the medium- and long-term.

## DS Division's Key Risks and Opportunities

| Type             | Type             | Risks and Opportunities                                                    | Risks and Opportunities                                                    | Risks and Opportunities                                                    | Risks and Opportunities                                                    |
|------------------|------------------|----------------------------------------------------------------------------|----------------------------------------------------------------------------|----------------------------------------------------------------------------|----------------------------------------------------------------------------|
| Physical Risks   | Acute            | Typhoon                                                                    | Flood                                                                      | Wildfire                                                                   | Hail, Thunderstorm                                                         |
| Physical Risks   | Chronic          | Drought                                                                    | Extreme heat                                                               | Heavy rainfall                                                             | Extreme cold                                                               |
| Transition Risks | Policy and Legal | Increase in cost of purchasing carbon credits                              | Increase in cost of purchasing carbon credits                              | Increase in cost of purchasing carbon credits                              | Increase in cost of purchasing carbon credits                              |
| Transition Risks | Market           | Insufficient alignment with customerdemandfor low-carbon products          | Insufficient alignment with customerdemandfor low-carbon products          | Insufficient alignment with customerdemandfor low-carbon products          | Insufficient alignment with customerdemandfor low-carbon products          |
| Transition Risks | Market           | Increase in production cost due to changing energy prices                  | Increase in production cost due to changing energy prices                  | Increase in production cost due to changing energy prices                  | Increase in production cost due to changing energy prices                  |
| Transition Risks | Technology       | Increase in R&Dcostsfor low-carbon products and services                   | Increase in R&Dcostsfor low-carbon products and services                   | Increase in R&Dcostsfor low-carbon products and services                   | Increase in R&Dcostsfor low-carbon products and services                   |
| Transition Risks | Technology       | Transition to low-carbon production processes                              | Transition to low-carbon production processes                              | Transition to low-carbon production processes                              | Transition to low-carbon production processes                              |
| Transition Risks | Reputation       | Stakeholder concerns and negative media coverage related to climate change | Stakeholder concerns and negative media coverage related to climate change | Stakeholder concerns and negative media coverage related to climate change | Stakeholder concerns and negative media coverage related to climate change |
| Opportunities    | Market           | Useof renewable energy                                                     | Useof renewable energy                                                     | Useof renewable energy                                                     | Useof renewable energy                                                     |
| Opportunities    | Market           | Increase in demandforlow-carbon products and services                      | Increase in demandforlow-carbon products and services                      | Increase in demandforlow-carbon products and services                      | Increase in demandforlow-carbon products and services                      |
| Opportunities    | Technology       | Useof low-carbon production processes                                      | Useof low-carbon production processes                                      | Useof low-carbon production processes                                      | Useof low-carbon production processes                                      |
| Opportunities    | Technology       | Reduction in water use and consumption                                     | Reduction in water use and consumption                                     | Reduction in water use and consumption                                     | Reduction in water use and consumption                                     |
| Opportunities    | Resilience       | Enhancing our company's resilience to climate change                       | Enhancing our company's resilience to climate change                       | Enhancing our company's resilience to climate change                       | Enhancing our company's resilience to climate change                       |
| Opportunities    | Resilience       | Enhancing the supply chain's resilience to climate change                  | Enhancing the supply chain's resilience to climate change                  | Enhancing the supply chain's resilience to climate change                  | Enhancing the supply chain's resilience to climate change                  |

<!-- image -->

22

## Financial Impact Assessment

The DS Division analyzed the potential financial impacts of identified key risks and opportunities through both quantitative and qualitative assessments, taking into consideration various climate-related scenarios in alignment with international climate change agreements.

|                                    | Climate-Related Scenario Selection   | Climate-Related Scenario Selection   | Climate-Related Scenario Selection                                                        |
|------------------------------------|--------------------------------------|--------------------------------------|-------------------------------------------------------------------------------------------|
| Type                               | Source                               | Scenario                             | Definition                                                                                |
| Physical Risks                     | IPCC 1)                              | SSP 4) 1-2.6                         | Assumesnetzeroemissionsby2075 (Low-carbonemissionscenario) Assumescurrentlevelsofcarbon   |
| Physical Risks                     | IPCC 1)                              | SSP5-8.5                             | Assumesfossil fuel-based development (High-carbon emission scenario)                      |
| Transition Risks and Opportunities | IEA 2)                               | Net Zero Emissions by 2050           | Assumesnetzeroemissionsinthe energysectorby2050                                           |
| Transition Risks and Opportunities | IEA 2)                               | Announced Pledges                    | Assumesfullimplementationof allnationalclimatecommitments worldwide                       |
| Transition Risks and Opportunities | IEA 2)                               | Stated Policies                      | Assumesmaintenanceand implementationofcurrentpolicies                                     |
| Transition Risks and Opportunities | NGFS 3)                              | Net Zero 2050                        | Assumesglobalnetzeroemissions by2050                                                      |
| Transition Risks and Opportunities | NGFS 3)                              | NDCs 5)                              | Assumesfullimplementation of currently pledgedNationally DeterminedContributionsworldwide |
| Transition Risks and Opportunities | NGFS 3)                              | Current Policies                     | Assumesmaintenanceand implementationofcurrentpolicies                                     |

1) Intergovernmental Panel on Climate Change   2) International Energy Agency 3) Network for Greening the Financial System   4) Shared Socio-economic Pathway 5) Nationally Determined Contributions

1. Physical Risks We analyzed hazard exposure levels and financial impacts of identified major physical risks at all our sites by scenario 1) and time period 2) using a global analysis tool incorporating IPCC scenarios, climate modeling data, and location information. As a result, under the SSP5-8.5 scenario, extreme heat exposure at Korean sites increases in the long term, relative to the short and medium terms. From a financial impact perspective, droughts and typhoons emerged as the key physical risks across all climate-related scenarios. Of these, the financial impacts of droughts are as follows.

1)   Scenarios widely recognized by major global institutions were used. Scenarios may inherently contain uncertainties and differ from actual future situations.

2) Short term: ≤ 1 year (2025), Mid-term: 1 ~ 5 years (2026~2029), Long-term: &gt; 5 years (2030~2050)

Drought We assessed drought exposure levels by analyzing the balance between water demand and supply in each DS site location, then calculated financial impacts based on potential future water prices 1) . Our analysis shows water prices aren't expected to rise dramatically overall compared to current levels, but facilities expecting increased demand will likely experience relatively greater financial impacts.

1)   Shadow price of water: Value of water based on water stress indices and population data in the Corporate Bonds Water Credit Risk Tool

2. Transition Risks and Opportunities We conducted a literature review and consulted external experts to develop an assessment methodology for financial impacts of risks and opportunities associated with the transition to a net zero society. Based on this, we assessed the financial impacts by utilizing internal strategies-including carbon reduction roadmaps aimed at achieving net zero by 2050-and external outlook data from the IEA and NGFS. The result showed that the increase in production cost due to changing energy prices, as well as the increase in cost of purchasing carbon credits, represent key transition risks. Meanwhile, the use of renewable energy and the reduction in water use and consumption were identified as key opportunities. The below explains how some of these factors influence our operation as risk or opportunity.

Increase in Cost of Purchasing Carbon Credits Carbon credit prices are expected to increase due to strengthening GHG regulations and policies, potentially reaching USD 250 per tonne 1) by 2050 according to the IEA's Net Zero Emissions by 2050 scenario. Our Korean sites are subject to South Korea's Emissions Trading System (ETS), being responsible for additional costs corresponding to any potential GHG emissions beyond nationally allocated quotas. Furthermore, should the carbon credit prices increase due to national GHG reduction targets and carbon neutrality policies, the cost of purchasing carbon credits is expected to increase.

1) Prices based on advanced economies with net zero emissions pledges

Reduction in Water Use and Consumption We  are  expanding investments in and operations of facilities to enhance water reuse rates as part of our response to climate change. Financial impact analyses revealed that cost savings from reduced water purchases significantly outweigh facility investment and operational costs over the short-, medium-, and long-term. This is expected to have positive impacts by offsetting potential losses from physical risks such as droughts.

<!-- image -->

## Assessment of Financial Impact Levels from Drought

<!-- image -->

## Resilience Assessment

A quantitative and qualitative evaluation was conducted on key risks and opportunities having financial impacts to assess our capacity to respond, recover and adapt. Representative examples of the results are as follows.

Drought We are actively implementing measures to minimize financial impacts resulting from droughts. By diversifying water sources and collaborating with suppliers, we established an emergency water supply system that enables stable operation of our sites even during periods of water scarcity. In addition, as the semiconductor industry is a national strategic industry in Korea, it benefits from diverse policy support from the government regarding the stable water supply. It serves as a critical foundation for strengthening our resilience.

Increase in Cost of Purchasing Carbon Credits We mitigate financial impacts from rising carbon credit prices by pursuing our net zero Scope 1 and 2 emissions target under the New Environmental Strategy. We reduce direct emissions through large-scale integrated process gas treatment facilities (RCS) and waste heat recovery systems. For indirect emissions, we reduce production process power usage while simultaneously transitioning to renewable energy. This helps mitigate vulnerabilities to fluctuations in energy cost and emission-related policies, enabling a reduction in carbon credit costs at our sites subject to the Korean emissions trading system.

Reduction in Water Use and Consumption We set goals for water reuse rates and systematically manage related facility investment and operational costs. This approach not only mitigates water risks due to climate change but also creates financial opportunities by enhancing operational efficiency and reducing costs, thereby strengthening our climate resilience.

<!-- image -->

23

## Activities

## DS Division GHG Reduction (2024)

<!-- image -->

## Direct GHG Emission Reduction

We are making various efforts to minimize direct GHG emissions (Scope 1) from process gases and LNG used in semiconductor manufacturing. First, we applied GHG reduction technologies that significantly improve process gas treatment efficiency and is actively expanding the use of waste heat to gradually reduce fuel consumption. Additionally, we are developing technology to purify and reuse CO 2 generated during semiconductor manufacturing as a material resource, with plans to apply it to semiconductor manufacturing facilities by 2030.

[Carbon capture research](https://www.samsung.com/global/sustainability/planet/clean-tech-Innovation/#anchor1)

<!-- image -->

## Process Gas Management

Large-scale integrated process gas treatment facilities We have developed and are utilizing the RCS, the first large-capacity integrated processing facility for process gases in the semiconductor industry. By 2024, 4 additional RCS units were installed 1 production line, bringing the cumulative total to 52 units currently operational. Furthermore, through the development and field application of the third-generation catalyst, we have improved the PFCs treatment efficiency up to 97%. Moving forward, we plan to continue expanding RCS installations not only in new production lines but also in existing lines, excluding cases deemed impossible.

1) Perfluoro Compounds

## [Regenerative Catalytic System (RCS)](https://www.samsung.com/global/sustainability/planet/climate-action/#AYUpg9lKFQoAIx-G/#RCS)

<!-- image -->

<!-- image -->

## RCS Treatment Process

<!-- image -->

Reduction of Process Gas Usage We have improved 1 of the 8 semiconductor manufacturing processes - Chemical Vapor Deposition (CVD)- into a more sustainable manner from the perspective of Green Engineering, reducing GHG emissions and cutting down on the use of gases and chemicals. To achieve this, we developed and implemented the Minimum Input Stable Output (MISO) technology through process recipe optimization and byproduct reduction methodologies, which ensures consistent film quality while maintaining stable production yields using minimal input gases. Notably, we developed a recipe to reduce nitrogen trifluoride (NF₃) usage in the silicon nitride oxide (SiON) process, achieving approximately a 25% reduction in NF₃ consumption. Additionally, we implemented measures across all CVD processes to decrease nitrous oxide (N₂O) usage. As a result, we have consistently reduced GHG emissions since 2020.

Development of Alternative Gases We  have been developing alternative gases with lower Global Warming Potential (GWP), achieving significant results such as replacing perfluorocarbons (PFCs) in some product processes. We have been applying G₁ gas to replace C₄F₈ since 2018, and from 2025 onward, we introduce replacement G₃ gas for CF₄ that accounts for the largest share of GHG emissions in DS Division's processes. We plan to continue research on developing alternative gases applicable across our operations.

1) Octafluorocyclobutane, IPCC AR6 standard GWP = 10,200 2) Carbon Terafluoride, IPCC AR6 standard GWP = 7,380

<!-- image -->

## Fuel Reduction

We are actively promoting operational optimization, waste heat recovery, and the development of non-fuel-based equipment to reduce fuel usage within our sites. In particular, the latest lines are designed to recover waste heat from chillers year-rounds, significantly reducing LNG consumption for preheating outdoor air in air handling units. As a result, waste heat usage rate has been increased to 51% at the Giheung, Hwaseong, and Pyeongtaek sites in 2024.

We plan not only to continue introducing facilities replacing LNGbased heat sources but also to expand waste heat recovery to existing lines. We will also increase the waste heat utilization rate in new lines from 70% to over 90%.

## Manufacturing Site Waste Heat Recovery System

<!-- image -->

## Transition to Zero-Emission Vehicles

As part of our efforts to reduce direct GHG emissions, We have transitioned a cumulative total of 106 vehicles to zero-emission vehicles (electric and hydrogen-powered) by 2024.

<!-- image -->

24

## Indirect GHG Emission Reduction

The semiconductor industry is highly energy-intensive. We are making efforts to optimize energy use in the manufacturing process and expand renewable energy transition to reduce Scope 2 emissions.

To achieve this, we are promoting improvements in equipment efficiency and process to optimize energy use, as well as continuously expanding the use of renewable energy at Korean and global business sites.

## Power Usage Reduction

Manufacturing Facilities In semiconductor manufacturing processes, we minimize increases in Scope 2 indirect emissions by reducing electricity consumption through shortening test times and optimizing auxiliary equipment operation. To this end, we have implemented systems that identify energy-saving measures and monitor equipment's power usage by time period.

In 2024, we have significantly reduced standby power by using the analysis of power consumption of all components within our facilities unused or unnecessary components are systematically shut down, and equipment are turned off during the idle or low-efficiency periods with low operating rates. Additional reduction in overall power consumption has been achieved through the improvement of operational logic, as well as reducing the use of heating jackets on vacuum pipes and prioritizing the operation of high-efficiency chillers. Furthermore, by recovering waste heat from the high-temperature cooling water produced by chillers, we are able to improve the efficiency of cooling tower fans and optimize overall cooling tower performance.

Looking ahead, we plan to continue research into developing new, low-power, and highly efficient equipment while identifying and implementing energy efficiency measures to further reduce power consumption across our facilities.

## Power Savings from Waste Heat Recovery

<!-- image -->

Non-Manufacturing Facilities In 2024 we introduced smart lighting systems in selected parking towers. By utilizing natural daylight and automatically controlling brightness based on time zones, we achieved significant power savings compared to conventional lighting. Plans are underway to expand the implementation of smart lighting across all DS Division parking towers in 2025.

## Business Site Parking Tower Smart Lighting Operation by Zone

<!-- image -->

## Renewable Energy Status by Key DS Division Regions

We transitioned 100% of power used at our global manufacturing and non-manufacturing business sites to renewable energy since 2020. To expand renewable energy transition at Korean sites, we are utilizing and exploring various options including the procurement through Power Purchase Agreements (PPAs).

## DS Division Renewable Energy (RE) Transition Rate and Usage

| Classification   |   2022 |   2023 |   2024 |
|------------------|--------|--------|--------|
| RETransition (%) |   23.2 |   24.3 |   24.8 |
| REUsage(GWh)     |  5,849 |  6,569 |  7,184 |

Republic of Korea In  June 2024, we signed a 20-year solar PPA of 115MW with Hanmaeum Energy and a 10-year 254MW tidal power plant PPA with the Korea Water Resources Corporation, securing an annual supply of approximately 620GWh of renewable energy. Additionally, we  produced and used 4.5GWh of power from a total of 4.0MW of on-site solar self-generation facilities. We also operate a geothermal heating and cooling system with a capacity of 1,803RT 1) .

1) Ton of Refrigeration Planet United States Through the purchase of renewable energy certificates (REC), on-site power generation facilities, and PPAs, we transitioned 100% of our U.S. sites' power usage to renewable energy starting in 2020. The Austin site was recognized for its efforts to expand renewable energy use and received the Green Power Leadership Award for Excellence in Green Power Use from the U.S. Environmental Protection Agency (EPA) in September 2019. It also secured renewable energy by signing a 75MW wind power PPA with Apple, eBay, and Sprint in November 2019, which began in 2021.

China Since 2020, our Chinese sites have achieved 100% energy transition through the purchase of renewable energy certificates and the installation of on-site solar power generation facilities. We plan to diversify renewable energy procurement options gradually, according to China's renewable energy policies and market conditions.

## Furthering Efforts to Reduce Indirect Emissions

The DS Division strives to address social and customer demand for carbon-free future. Adding to our continuous efforts for transition to renewable energy, we join the promotion of Carbon-Free Energy (CFE) utilization by participating in related initiatives and studies, aiming for the acceleration of both carbon neutrality and enhanced industrial competitiveness.

## Carbon Free Alliance (CFA)

‧   Samsung Electronics is a member of the Alliance's Board and Working Group, contributing to discussions on international technical standards and certification framework for Carbon-Free Energy.

## Collaboration with academia

‧   The DS Division collaborated with the Seoul National University Nuclear Energy Policy Center in 2024 to investigate feasibility of CFE certification and implementing measures.

25

## Value Chain Carbon Reduction

We operate an internal consultative body to strengthen Scope 3 indirect emissions management, establishing specific reduction targets and developing implementation plans to systematically advance Scope 3 emissions reduction.

## Upstream Reduction Activities

We have developed medium- to long-term reduction roadmaps for Scope 3 upstream categories to concretize our Scope 3 reduction implementation strategies. As part of this effort, we carry out activities to progressively enhance suppliers' capabilities.

We regularly conduct employee training and executive seminars to enhance suppliers' GHG management capacity, and provide dedicated tools to enable suppliers to independently calculate and manage their emissions. In collaboration with the Korea Semiconductor Industry Association (KSIA), we developed standardized industry common forms for Scope 3 emissions surveys within the semiconductor industry. For major suppliers with high emission contributions, we encourage the establishment of tailored reduction targets through one-on-one consulting.

As a result of these efforts, suppliers' target-setting rate has nearly doubled from 39% in 2023 to 75% in 2024, significantly strengthening participation across the supply chain in reduction activities. We plan to build and operate a system by the end of 2025 to systematically support suppliers' emission calculation and management, thereby improving efficiency of supplier emissions management.

## Downstream Reduction Activities

We are a founding member of the Semiconductor Climate Consortium (SCC), and have actively participated in industry-wide efforts to address climate change since 2022. Notably, within SCC's Scope 3 Working Group, we have played a leading role in standardizing emission calculation methodologies for key Scope 3 emissions categories specific to the semiconductor sector- "Purchased Goods and Services" and "Use of Sold Products." Taking into account the unique characteristics of the industry, we collaborated with various Korean and global material suppliers, equipment manufacturers, semiconductor manufacturers, and customers to enhance the management of Scope 3 indirect emissions across the industry and contribute to identifying joint reduction opportunities.

## Semiconductor Product Carbon Reduction

## Semiconductor Product LCA Process

We established an LCA process based on ISO 14040, 14044, and 14067 international standards to assess the environmental impact of semiconductor products and calculate our carbon footprint.

LCA quantitatively analyzes and assesses environmental impacts throughout the entire lifecycle of a product, from raw material extraction, raw material transportation, product manufacturing, product use, to disposal. By calculating vast amounts of data using optimal methodologies, we accurately and transparently calculate and disclose the environmental impact of semiconductor products.

We effectively manage carbon emissions at the product level across all semiconductor products through the LCA, Long-term efforts focus on establishing a comprehensive management system, which can be a basis of not only reducing carbon emissions but also evaluating overall environmental impact including water resources.

## Development and Operation of Product Carbon Footprint (PCF) System

We established and operate an automated system for calculating the PCF for semiconductor products. The scope covers all processes from raw material procurement to production, packaging, and inspection (Cradleto-Gate), and the PCF is calculated using emission factors of target items derived from life cycle assessment databases. By calculating detailed unit carbon emissions by facility and process, we identify major carbon emission sources in product manufacturing and prepares emission reduction measures. The reliability of the calculated data has been secured by completing third-party verification from a global certification body for the LCA methodology and automation system.

[Third-Party LCA Validation Report](https://download.semiconductor.samsung.com/resources/others/Samsung_PCF_Independent_Validation_Opinion_eng.pdf)

## Low-Power Semiconductor Products and Processes

Since 2009, we have provided memory semiconductors and solutions that maximize low-power characteristics annually, contributing to the reduction of GHG emissions from data centers, PCs, mobile devices, and other IT equipment.

We developed SOCAMM2 1) , a server module optimized for AI computing based on LPDDR, and provides the best high-performance, lowpower solutions for the AI era through SSD products based on PCIe 2) 5th generation with a 5nm controller. The mobile processor Exynos integrates various functions such as the Central Processing Unit (CPU), Graphics Processing Unit (GPU), Neural Processing Unit (NPU) for artificial intelligence, Digital Signal Processor (DSP), and modem for 5G, increasing power efficiency. It also provides AI computing performance of 26TOPS (Tera Operations Per Second) through a powerful NPU.

Furthermore, to reduce power consumption of associated with producing customer products, we apply processes that enhance power efficiency, such as forming fine patterns using EUV and introducing GAA 3) -structured transistors to lower operating voltage for sub-3nm ultra-fine circuits.

1) Small Outline Compression Attached Memory Module

2) Peripheral Component Interconnect Express

3) Gate-All-Around, a next-generation transistor structure technology

[Low-Power Memory Semiconductors](https://www.samsung.com/global/sustainability/focus/products/semiconductors/#AYs7ODuaXE0AIx-y)

[Low-Power Foundry Process](https://www.samsung.com/global/sustainability/focus/products/semiconductors/#AYs7OfcaXGwAIx-y)

## Collaborative Efforts on Climate Action

We continue various climate change response efforts including SCC initiative activities and participation in global conferences (SEMICON). We discuss policy recommendations for strengthening semiconductor companies' competitiveness and improving Korean energy systems and collaborate with various companies in our supply chain such as materials or equipment providers to drive GHG reduction across the

semiconductor industry.

## Initiative

·   RE100, ACEC 1) Working Group Participation, CoREi 2) Activities ·   SCC, EC 3) Board and Working Group Participation

1) Asia Clean Energy Coalition    2) Corporate Renewable Energy Initiative 3) Energy Collaborative

## Policy Engagement

·   Korean Renewable Energy Systems Improvement Roundtable and CEO Roundtable (Ministry of Trade, Industry, and Energy)

·   Corporate PPA Activation Roundtable (Korea Energy Agency)

·   Request to Ease Setback Distance Regulations for Solar Power Installations and Expand PPA Grid Access Fee Support Program

Facts &amp; Figures

26

## Circular Economy

## Strategy

The DS Division is continuously striving to achieve its goal of a 99.9% 1) waste recycling across its 5 Korean sites by 2030. By strengthening the separation system for non-recyclable waste, and identifying suitable recycling technologies and partner companies, we have improved waste recycling efficiency. We successfully achieved  the integrated Platinum Zero-Waste-to-Landfill Validation for all global sites.

Through the application of recycling technologies, we are building a circular structure by reusing materials and components used in semiconductor manufacturing or converting them into resources by adding value to waste. Obtaining Recycled Resource Certification 2) since 2019, we have become the holder of the largest number of such certifications in Korea as of 2024. Additionally, we have achieved the industry's first Circular Resource Use Product Certification 3) in 2024, enabling the use of recycled materials within our semiconductor manufacturing processes.

Recycled materials are also being applied to products and packaging. We use recycled aluminum for product cases and use paper and recycled materials for packaging, and plan to further expand the use of recycled materials in the future.

1) Korean legal standards

2)   Issued by the Minister of Environment if environmental, economic, and technical feasibility under the 'Framework Act on Resource Circulation' is met

3)   Circular Resource Use Product Certification is issued for products that use at least 10% of certified circular resources as raw materials.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## Expansion of Recycling and Waste Reduction to Minimize Environmental Impact

‧   Expand waste recycling and reduce single-use item usage within the company

## Expansion of Resource Reuse

‧   Resource circularization of product manufacturing consumables

## Expansion of Circular Resources

‧   Expand certified circular resources items and obtain Circular Resource Use Product Certification

## Products/Packaging Management

‧   Make product cases from recycled aluminum and reduce plastic packaging materials

## Risk Management

We identify the characteristics of waste by type, discover stable disposal partners, and work to enhance their expertise. Since 2021, we conduct regular comprehensive assessment of waste disposal partners through specialized consulting services, to inspect waste treatment status and compliance with regulations, and provided advisory services by sharing waste management best practices. As a result, the evaluation index of waste disposal partners (DS Division's self-assessment) has continued to improve.

## Waste Management Process

<!-- image -->

## Activities

## DS Division Korean Sites Waste Flow Chart (2024)

<!-- image -->

<!-- image -->

Climate Change / Circular Economy / Water / Pollution

## Expansion of Recycling and Waste Reduction to Minimize Environmental Impact

## Waste Reuse Expansion

We are making various efforts to recycle waste items that are currently incinerated, neutralized, or solidified. We expanded our recycling efforts by separating and sorting non-recyclable waste mixed during disposal and by developing appropriate processing technologies as well as identifying new waste management partners.As a result, our recycling rate at Korean sites 1) increased by 0.6%p compared to 2023, reaching 99.0% in 2024.

1) Giheung, Hwaseong, Pyeongtaek, Cheonan, Onyang sites

## Reduction of Waste Generation through Reduction of Single-Use Items

Starting in 2019, we initiated activities to reduce office waste and singleuse items. In 2021, we established separation and disposal criteria for 10 types of office waste 1) and built the necessary infrastructure. From 2022, we initiated activities to replace single-use items with reusable ones, and expanded activity scope to company cafeterias and cafes.

1)   Non-recyclable, plastic, bottles, cans, milk cartons, food waste, paper, plastic bags, coffee capsules, transparent PET bottles

<!-- image -->

## Integrated Platinum Grade Zero-Waste-to-Landfill Validation

Our 10 business sites 1) has undertaken an integrated Zero-Waste-to Landfill validation by the global environmental safety certification agency UL Solutions. To minimize energy recovery rates (WtE) 2) ,  we made various efforts to recycle single-use items that were previously incinerated, such as improving separation systems and applying reusable items. As a result, we obtained the Platinum grade, the highest level of UL Solutions' Zero-Wasteto-Landfill validations, across all our sites. We plan to maintain this Platinum validation across all our sites in 2025 as well.

1) Giheung, Hwaseong, Pyeongtaek, Cheonan, Onyang, SCS, SESS, TSLED, SAS, SAIT 2) Waste to Energy: Renewable fuel and energy recovery incineration

<!-- image -->

27

## Expansion of Resource Reuse

## Circular Resource Utilization of Manufacturing Consumables

Chemical Mechanical Polishing (CMP) Retainer Ring We  are expanding the circular structure for consumables generated during the manufacturing process. CMP retainer rings, which were previously separated and incinerated after use, are now processed through a regeneration process that includes separation, sorting, cleaning, melting, and pelletization. This enables the purchase and reuse of products made from these rings, reducing carbon emissions when compared to incineration.

## CMP Retainer Ring Reuse Process

<!-- image -->

Ventilation Adsorbents A  circular  system for reuse has been established for air conditioning adsorbents. Previously, adsorbents that reached the end of their service life were incinerated and disposed of. Now, they are reused for the same purpose after being calcined to remove impurities, sorted and crushed, reshaped, and tested for quality.

## Ventilation Adsorbents Reuse Process

<!-- image -->

<!-- image -->

Wafer Tray Recycled plastic from wafer trays discarded during semiconductor production has been applied to the side and volume buttons of the Galaxy S25 series. These discarded and recycled wafer trays are fostering collaboration between the DX and DS Divisions for resource circularity.

## Expansion of Circular Resources

## Recognition of Circular Resources

The Circular Resource Certification Policy, implemented since 2018, recognizes waste as a resource if it meets the criteria of the 'Framework Act on Resources Circulation" 1) , exempting it from waste regulations. We have been obtaining Quality Mark Certification for Circular Resources since 2019. In 2024, we obtained certificates for 12-inch wafer boxes (PC 2) and PBT 3) composites) for our Giheung, Hwaseong, and Pyeongtaek sites, bringing the cumulative total to 18 certificates. This recognition allows 2,749 tons of waste to be acknowledged as resources annually.

- 1)   The 「Act on Promotion of Transition to a Circular Economy and Society」, which replaced the 「Framework Act on Resource Circulation」 on December 31st, 2022, has been fully amended and is in effect since 2024.

2) Polycarbonate

3) Polybutylene terephthalate

## Materials Recognized as Circular Resources

<!-- image -->

<!-- image -->

## The First Circular Resource Use Product Certification in the Korean Manufacturing Industry

The "Circular Resource Use Product Labeling System," newly established in March 2024, is a system that allows products using at least 10% of recognized circular resources as raw materials to be labeled, in accordance with the 「Act on Promotion of the Transition to a Circular Economy and Society」. We became the first in the manufacturing industry to receive confirmation from the Korea Environment Industry &amp; Technology Institute for two items of "IC Trays" 1) at the Onyang site. By repurchasing these items, we are creating a circular structure.

1) IC Tray (MPPO), IC  Tray(ABS)

## IC Tray Circular Structure

<!-- image -->

## Products/Packaging Management Application of Recycled Aluminum in SSD Products

Since 2024, the we have been applying recycled aluminum to the Portable Solid State Drive (SSD) T7 Shield product case, which has received recycled material certification from TÜV 1) .

1) A leading German private certification provider

## Transition to Paper Packaging

We continue to make efforts to reduce plastic packaging in our products. In 2020, we transitioned from plastic trays to paper trays for consumer SSDs. We completed transitions to paper trays for portable SSDs and Heatsink products in 2023 and for 2.5'' products in 2024. We plan to expand our transition to paper trays for M.2 SSD products in 2025.

## Expansion of Recycled Material Certified Packaging

In 2024, we received ISO-14021 based recycled material certification from Intertek 1) for  the  recycled content in the plastic trays of component products.

1) A UK-based global inspection and certification organization

<!-- image -->

28

## Strategy

As semiconductor production lines expand, the required water intake is expected to continue increasing. Nevertheless, we declared our goal to reduce water withdrawal to 2021 levels by 2030 through the New Environmental Strategy announced in 2022 and is making various efforts to achieve this goal.

Firstly, we are working to fundamentally reduce water usage through equipment improvements and process optimization. We are actively investing in technologies for water reuse within our sites and collaborating with local communities to promote the reuse of treated wastewater.

Additionally, In water resource management, we place great importance on the conservation of natural capital and biodiversity. In this regard, we continuously monitor the status of surrounding ecosystems including rivers into which wastewater from our sites flows, and and also undertake activities to enhance biodiversity.

<!-- image -->

<!-- image -->

## Risk Management

We annually review whether its manufacturing sites are located in water-stressed areas or regions at risk of water resource issues. We also established a biodiversity-related risk management system. Identified key risks are incorporated into our sustainability strategy and implementation actions.

## Water Risk Management

Using the Aqueduct Water Risk Atlas 1) , a global water risk mapping tool, we identified the regions experiencing water stress and water resource risks, as well as four key risk factors affecting the sites located therein. We have then developed strategies tailored to each site, to mitigate these risk through effective responses.

1) Assessment of water resource quantity and quality data, policy, reputation risks, etc.

## Site

## Water Stress Level

| Korea (Giheung/Hwaseong/Pyeongtaek/Cheonan/Onyang)   | Medium-High    |
|------------------------------------------------------|----------------|
| China (Xi'an/Suzhou)                                 | Extremely high |
| China (Tianjin)                                      | Medium-High    |
| United States (Austin/Taylor)                        | Medium-High    |

## Water Risk and Responses Strategy

- Drought, Water Shortage
-   Diversify water sources such as establishing emergency supply systems
-   Estimate potential losses from droughts
- Increasing Korean Water Stress Index
-   Review water stress/risks by site annually, establish response strategies
- Water Depletion, Contamination
-   Participate in World Water Day activities
-   Prevent water risk occurrence, engage with local communities
- Water Related Regulations
-   Monitor local environmental policies and regulations, manage at legal standards and stricter internal standards

<!-- image -->

## Biodiversity Risk Management

The DS division conducted an analyses on its five business sites in Korea using tools recommended by the Taskforce on Nature-related Financial Disclosures (TNFD) - Exploring Natural Capital Opportunities, Risks and Exposure (ENCORE 1) ) and World Wide Fund for Nature - Risk Filter Suit (WWF-RFS 2) ) - aiming to identify natural impacts and dependencies related to corporate activities as well as evaluate physical biodiversity risks. As a result, two risk factors were found to be at medium or higher ratings. Based on these findings, response strategies have been developed accordingly.

1) A UNEP provided nature impact and dependency analysis tool 2) A biodiversity risk assessment tool provided by the World Wildlife Fund

## Physical Biodiversity Risks

- Pressures on Biodiversity
-   All Korean Business Sites: Medium Rating
-   Overall rating determined by aggregating four sub-risk factors: pollution, land use, deforestation, and invasive species. Due to the geographical characteristics of sites located in development areas and the nature of the semiconductor industry, impact from pollution was very high.
- Natural Disaster Impact Risk (Regulating Services-Mitigating)
-   Giheung, Hwaseong, Pyeongtaek Sites: Medium Rating
-   Cheonan, Onyang Sites: High Rating
-   Reflecting the geographical characteristics of Korea's West coast, prone to disasters such as typhoons and extreme heat, and the lower disaster impact of the semiconductor industry resulted in medium and high risk ratings.

<!-- image -->

<!-- image -->

29

## Activities

## Water Resource Flow Chart for DS Division's Korean Sites (2024)

(unit: 1,000 tonnes)

<!-- image -->

We continuously engage in various activities to protect water resources. To reduce water intake at our facilities, we are actively introducing "water usage reduction," which fundamentally decreases water consumption, "water reuse," which recycles industrial water, ultrapure water, and wastewater used internally after treatment, and "wastewater reuse," which uses treated water from local wastewater treatment plants. In the future, we plan to implement external restoration projects 1) to return the water resources consumed at our facilities to the environment.

To minimize the impact on ecosystems around our facilities and improve biodiversity, we monitor discharged river water quality and surrounding ecosystems and survey ecological status maps around our sites to understand the surrounding natural conditions. We regularly carry out biodiversity enhancement activities in collaboration with local governments and our employees.

1) Currently pursuing restoration projects such as the Jangheung Dam Wetland Restoration, with plans to secure water resource restoration volumes starting in 2025

## Water Use Reduction

We are practicing water usage reduction by improving processes such as optimizing equipment cleaning processes, and maximizing equipment efficiency.

Through data-based deep learning analysis, we reflect optimized cleaning cycles in the cleaning processes of production equipment and use real-time data analysis to immediately apply the results to the process, striving to use water as efficiently as possible.

As a result of maximizing the water use efficiency of facilities, we achieved a fundamental reduction of approximately 16.76 million tons of water usage at Korean sites in 2024.

<!-- image -->

## Water Reuse Expansion

We are actively reducing water intake by maximizing the reuse of water taken from water sources. We recycle wastewater generated at our production facilities, or treat it through internal treatment facilities for reuse.

Especially through wastewater source analysis, we maximized water reuse rates, achieving a reuse of approximately 101 million tons of water at Korean sites in 2024. In the future, we will continue to expand water reuse efforts to take the lead in protecting water resources.

<!-- image -->

<!-- image -->

## Concentrated Water Reuse

Previously, the concentrated water generated during ultrapure water production was discharged to the wastewater treatment plant. However, since 2024, it has been reused as cooling water after improving the water quality to meet standards for alternative purposes.

<!-- image -->

## Wastewater Reuse

Wastewater from local governments is treated at public wastewater treatment plants and discharged into nearby rivers. In December 2024, we signed a memorandum of understanding with the Ministry of Environment and Gyeonggi Province for the "Gyeonggido Region Semiconductor Site Reclaimed Water Project (Phase 1)." We plan to treat and reuse wastewater that would otherwise be discharged into nature for semiconductor manufacturing. To this end, We are conducting feasibility studies and building reuse facilities, preparing to reuse wastewater from Hwaseong and Osan City wastewater treatment plants (approximately 120,000 tons/day) as industrial water at the Giheung and Hwaseong sites by 2029.

## Alliance for Water Stewardship(AWS) Certification

Samsung Electronics' Hwaseong site became the first in Korea to receive the highest AWS certification grade of Platinum in March 2023. In January 2024, we expanded the certification to Giheung and Hwaseong sites (combined) and the Pyeongtaek site, and in February, we acquired the Platinum grade for our Xi'an site in China. By November 2024, the Cheonan and Onyang sites were added, resulting in all Korean DS Division manufacturing sites holding the Platinum certification.

<!-- image -->

<!-- image -->

30

## Biodiversity Management

## Survey and Analysis of Nearby Natural Environment at Manufacturing Sites

The ecosystem expected to be most impacted by our activities is the aquatic ecosystem. We regularly survey the natural environment around our business sites to manage and conserve natural capital and biodiversity effectively.

We conducted surveys of various ecosystems such as forests, rivers, farmland, and urban areas within approximately 2,010㎢ around Korean business sites and built spatial information using the LEAP methodology 1) .  Using this data, we analyzed three natural capital factors related to TNFD core indicators 2) : ecosystem health, protected areas 3) ,  and the status of endangered, invasive, and alien species, visualizing them on maps. Based on these survey and analysis results, we will continue to promote activities that contribute to enhancing and conserving biodiversity around our business sites.

- 1)   TNFD's nature information disclosure methodology, consists of 4 steps

(Locate, Evaluate, Assess, Prepare)

- 2) TNFD's core indicators: 10 indicators related to impact and dependence, 5 indicators related to risk and opportunity
- 3) World Database on Protected Areas (WDPA), a database of protected area information registered by each country's government

## Survey/Analysis Results of Natural Environment Near Manufacturing Sites

<!-- image -->

<!-- image -->

## Protected Areas (WDPA) 1)

-   No Protected Areas within a 2㎞ Radius of Korean manufacturing sites ·   Protected area coverage of 0.2~2.4% within a 5㎞ radius, mostly urban natural parks
-   Including Palgong Lake and water source protection zones, as well as natural environment conservation areas within a 10㎞ radius
- High Integrity Ecosystem Areas (Biotope type assessment grade 1) 2) ·   Located within a 5㎞ radius of Korean manufacturing sites, the area of high integrity ecosystems ranges from 6.6% to 20.3%, (Onyang 20.3%, Cheonan 12.1%, Giheung/Hwaseong 8.1%, Pyeongtaek 6.6%) ·   High integrity ecosystem identified within the Hwaseong site (Donghak Mountain, currently under conservation and management)

## Endangered Species 3)

-   Frequent occurrence in rivers, estuaries, and tidal flats within survey area ·   Key species identified: Eurasian Otter (class I endangered), Leopard Cat (class II endangered), Oriental Stork (class I endangered), Black-faced Spoonbill (class I endangered), Suwon Treefrog (class I endangered), Seoul Pond Frog (class II endangered)

## Disruptive Species 3)

-   High habitat frequency in rivers and urban parks within survey area ·   Invasive species such as Japanese honeysuckle, common ragweed, largemouth bass, and bullfrogs identified within a 5㎞ radius; removal activities are ongoing at the Hwaseong site and its discharge rivers, both within and outside the site
- 1)   Protected Koreans sites in World Database on Protected Areas (KDPA, 30 types across 5 departments)
- 2)   Application of the ecological space (biotope) evaluation criteria from the Ministry of Environment's Urban Ecosystem Status Map Guidelines
- 3)   Wildlife designated as endangered by the Ministry of Environment and invasive species in ecosystems

Additionally, we monitor the water quality and ecosystems of discharge rivers into which our wastewater flows. In 2024, we confirmed the presence of otters in the discharge rivers of all Korean business sites. The presence of otters indicates that the ecosystems of the discharge rivers are healthy and that biodiversity is high.

<!-- image -->

## [Survey of Natural Environment Near Our Sites](https://www.samsung.com/global/sustainability/planet/sustainable-operations/#AYUqipYaCXUAIx_C)

## Key Endangered Wildlife Near Business Sites

Suwon Treefrog (class I endangered)

<!-- image -->

<!-- image -->

Bean Goose (class II endangered)

<!-- image -->

Oriental Stork (class I endangered)

<!-- image -->

## Biodiversity Enhancement Activities

We are making efforts to positively impact biodiversity. Following the AR3T 1) framework of the Science Based Targets Network (SBTN), we review and implement measures to avoid and reduce natural impacts during the creation, operation, and management stages of our business sites. As a major reduction measure, we created natural spaces such as greenery and forests within our sites, resulting in approximately 1.67 million ㎡ of natural space, as confirmed by the Ministry of Environment's Land Cover Map.

We are also actively promoting activities to restore and regenerate nature. The SCS site in Xi'an, China, has been collaborating with the Shaanxi Provincial Government since 2024 to create the Samsung Public Forest in Y ulin City. We plan to establish a total of 600,000㎡ of forest  over  3  years,  from  2024  to  2026,  expecting  not  only  the restoration of forest ecosystems and biodiversity enhancement but also carbon reduction and desertification prevention effects.

Our Korean sites continue to promote activities such as the "One Company, One River" initiative for river ecosystem conservation and the Sohwang sand dune marine ecosystem conservation project. In the future, we plan to establish and implement a nature conservation strategy that contributes to achieving the Kunming-Montreal GBF 2) and national biodiversity strategy goals.

- 1)   SBTN's biodiversity impact reduction activities, recommended in the order of Avoidance, impact Reduction, Restoration &amp; Regeneration, and Transformation. 2) Global Biodiversity Framework

## Key Biodiversity Enhancement Activities

## SCS Site Samsung Public Forest Project

## Onyang Site Ecological Conservation Activities 2)

<!-- image -->

<!-- image -->

- 1)   Signed the "Basic Agreement to Support the Shaanxi Province Northern Ecological Civilization Construction Project" with the Shaanxi Provincial Forestry Bureau and others
- 2)   River beautification activities (1 Company, 1 River), ecological conservation activities at Gokgyo Stream

<!-- image -->

31

## Pollution

## Strategy

The DS Division manages our operations based on internal standards that are stricter than legal requirements for water and air pollutant emissions.

Through the New Environmental Strategy announced in 2022, we declared our goal to limit pollutant emissions to natural levels by 2040 and is continuously developing advanced pollutant reduction technologies to minimize emissions. Additionally,we conduct research on air pollution reduction technologies through the Air Science Research Center.

We built a safe workplace by thoroughly managing all chemicals used at our sites, from their receipt to disposal, and conduct a preassessment on all chemicals within the site, to meet international standards and minimize their negative impact on the environment and human health.

<!-- image -->

## Minimize Water and Air Pollutant Emissions

‧   Apply strict internal standards on pollutant emissions and develop pollutant reduction technologies

<!-- image -->

## Safely Manage Chemical Substances

‧   Safely manage site chemical substances and enforce management of substances of concern in products

## Risk Management

We ensure compliance with legal discharge standards for water and air pollutants and has established our own internal standards to address stakeholder requirements and minimize its impact on nature.

<!-- image -->

<!-- image -->

The chemical substance life cycle (from receipt to disposal) is managed through an operational process. Legal standard information is updated periodically, and high-risk chemical substances are either replaced or usage reduced to manage risks.

## Chemical Material Pre-assessment and Life Cycle Management Process

<!-- image -->

## Activities

## Minimize Water Pollutant Discharge

We have established and implemented stricter internal standards than legal requirements 1) in  complying with discharge limits for water pollutants. We implement optimal prevention technologies and manage wastewater treatment processes through a four-stage system, utilizing advanced wastewater treatment facilities to purify and discharge into local rivers. Additionally, for strict effluent quality control, a Central Control Room (CCR) monitors the entire wastewater treatment process and has automated all pollution treatment operations except for on-site valve manipulations in emergency response situations.

To minimize the impact of water pollution discharge on the environment, we are developing technologies to minimize pollutant emissions and aim to treat wastewater to natural levels.

To reduce chemical usage, we are modifying process recipes, reusing chemicals from production processes in other facilities, and researching and developing filter technologies that can selectively separate and remove target substances.

<!-- image -->

People Climate Change / Circular Economy / Water / Pollution Additionally, we continuously strive to improve treatment efficiency by optimizing processes for the best prevention technologies applied in wastewater treatment. Efforts are also being made to replace hazardous substances.

1) Act on the Integrated Control of Pollutant-discharging Facilities

## Constructing a Multi-Layer Defense System Against Water Pollution

We have installed triple interception facilities across the 'inflow stageprocess stage-discharge stage' of our wastewater treatment facilities to prepare for potential environmental accidents. Each interception facility operates according to a multi-layered defense mechanism, which triggers emergency recovery if the pollutant concentrations exceeds set levels based on real-time monitoring. This ensures prevention of untreated wastewater discharge into streams.

Specifically, at the Austin facility in the United States, a retention pond has been installed upstream of the stream discharge point, equipped with a real-time pollutant monitoring system. As a result, if untreated pollutants are detected, the discharge point is automatically blocked.

## Process of Multi-Layer Defense System Against Water Pollution

<!-- image -->

<!-- image -->

32

## Minimizing Air Pollutant Emissions

We manage our air pollutant emissions to ensure full compliance with legal requirements 1) by adhering to strict internal standards. We apply optimal prevention technologies related to air quality and has established multi-stage treatment systems (1-3 stages) tailored to the characteristics of pollutants. To prepare for potential environmental accidents related to air pollutants, we installed backup treatment facilities across all lines and operates a real-time monitoring system to proactively prevent issues.

We continuously develop and apply pollution treatment technologies to ensure that air pollutants from production processes are discharged at levels that do not impact the surrounding environment. Notably, we installed ultra-low NOx burners and Selective Catalytic Reduction (SCR) facilities for nitrogen oxide reduction, as well as wet treatment facilities (ozone oxidation + absorption). Additionally, we replaced existing boilers with lowenergy steam supply facilities. We are also developing advanced treatment technologies, including adsorption using membranes, enhanced treatment processes utilizing ambient and high-temperature plasma and catalysts, and integrated treatment technologies to improve processing efficiency. 1) Act on the Integrated Control of Pollutant-discharging Facilities

## Research on Fine Particulate Matter Reduction Technologies

Our Air Science Research Center (formerly the Particulate Matter Research Center), established in January 2019, is developing nextgeneration filters and air purification system technologies. We have developed the world's first air purification filter technology that removes both particulate matter and harmful gases with a single filter, usable for up to 20 years with simple water washing.

To build environmentally friendly facilities, we are conducting pilot tests for the ShareAIR (Share the clean Air) project at our Hwaseong site, aiming to launch it fully by 2030. We continue to develop technologies to improve fine dust treatment efficiency, achieving a 98% efficiency rate by 2024.

## Voluntary Agreement for Seasonal Control of Fine Particulate Matter

We participated in the "Voluntary Agreement for Seasonal Management of Particulate Matter" with the Seoul Metropolitan Air Quality Management Office (February 2023 - March 2025, 2 years). During the seasonal management period (December to March), we strengthened our nitrogen oxide reduction targets by 10% compared to legal standards and agreed to operate our fine particulate matter prevention facilities at optimal levels.

## Chemical Safety Management

At Samsung Electronics, all chemicals used across our global facilities are strictly restricted based on national regulations and the company's internal 'Controlled Substance List." We support various activities, such as on-site inspections and work environment improvements, to ensure that employees and suppliers can use chemicals safely under optimal working conditions.

## Chemical Management Progress and Target

|   2024 | · Managechemical exposures by setting internal standards that are stricter than legal requirements   |
|--------|------------------------------------------------------------------------------------------------------|
|   2030 | ‧ Ensure 0cases of direct worker exposition to chemicals                                             |

## Reinforce Site Chemical Substance Safety Management

We have strengthened chemical management across all our facilities to prevent chemical accidents. We conducts legal impact assessments and pre-assessments of chemicals to monitor environmental regulations and ensure compliance with mandatory requirements.

For all chemical-related high-risk tasks, a risk assessment is conducted before work begins. Based on the assessment results, safety management levels are applied differently on-site, with higher-risk tasks being managed more strictly. In particular, we are developing and applying automation and unmanned technologies for hazardous tasks such as chemical injection to fundamentally eliminate the risk of accidents. Additionally, we conduct regular training for personnel handling chemicals according to legal standards to prevent chemical incidents.

Furthermore, to respond to potential accidents, including chemical leaks, we conduct emergency response training for employees twice a year and for response teams, including the fire department and Emergency Response Teams (ERT) 1) , once a month.

1) Emergency Response Team

## Reinforce Chemical Control

‧ Automate chemical injection

‧ Facility-specific overhauls

‧ Perform pre-assessments before chemical introduction ‧ Establish system for early detection of and response to leakage

## Minimizing Leakage Risks

- ‧   Establish detection and response system for leaks in interiors/exteriors, rainwater drainage pipes, and outer fences
- ‧   Focus on research related to chemical mixing risks to prevent relevant accidents
- ‧ Establish chemical mixing prevention system
- ‧ Reinforce construction and work standards around chemicals

## Chemical Substance Safety Management Activities

- ‧ Provide regular training for handling facilities and personnel
- ‧   Operate advanced chemical safety and accident prevention training programs
- ‧ Inspect handling facilities (usage, storage, deposit, etc.)
- ‧   Establish safety measures for chemical handling facilities with expert diagnostics from specialized organization

## Management of Substances of Concern in Products

We commit to minimizing the adverse impact on the environment and human health by rigorously managing substances of concern that may be present in our products after the manufacturing process. The DS Standards for Control of Substances Used in Products was published to meet international standards and our customer requirements.

## [DS Division Standards for Control of Substances Used in Products](http://download.semiconductor.samsung.com/resources/others/DS_ERU_026_ver1_EN.pdf)

All our products comply with global regulations, including EU Restriction of Hazardous Substances Directive (RoHS), EU Registration, Evaluation, Authorization, and Restriction of Chemicals (REACH), Halogenfree Standards, and the U.S. Toxic Substances Control Act (TSCA). We mitigate regulatory risks through systematic control of raw materials and comprehensive inspections of finished products across the entire product life cycle. Declaration of Compliance for International Regulations

As global regulations on hazardous substances evolve and become more stringent, the need for specialized management has grown. We closely monitor international trends and proactively develop strategies to manage emerging substances of concern. In 2023, we conducted a comprehensive survey of PFAS 1) usage across all raw material suppliers and are currently working to achieve PFAS-free status by identifying and implementing alternative substances.

To ensure strict control of hazardous substance use within the supply chain, we operate the Eco-Partner certification program. This program verifies the supplier compliance with our internal standards and conducts audits of their environmental quality management system. Only certified suppliers are eligible for business through this program. 1)Per-and Polyfluoroalkyl Substances

33

<!-- image -->

<!-- image -->

We move together into the future while fulfilling our social responsibility.

Our People Sustainability in Supply Chain Empowering Communities Privacy Protection &amp; Security Product Quality &amp; Safety

## Our People

## Governance

Samsung Electronics oversees and manages agendas such as labor and human rights, diversity, equity, and inclusion (DEI), and talent development across the business at various levels, led by the Sustainability Committee under the Board of Directors, the DX Division's Sustainability Council, the DS Division's ESG Management Council, and relevant interdepartmental councils.

The Sustainability Committee reviews the direction of our sustainability efforts to ensure that employee-relevant sustainability issues are considered an essential part of the decision-making process for business-related matters. This lets the Board more effectively oversee sustainability-related agenda items. In 2024, the Sustainability Committee discussed issues such as ESG stakeholder response improvement methods, expansion of the Stellar Forest business (a subsidiary-type standard workplace for employees with disabilities), and results of EU stakeholder engagement efforts.

In addition, the implementation of employee-related policies is also managed by dedicated councils and organizations such as the Labor and Human Rights Council, DEI Office, DS Culture &amp; Diversity Lab, Samsung Electronics University (SEU), and DS University.

## Labor and Human Rights Council

The Labor and Human Rights Council is a Council of departments that discuss labor and human rights matters. The Council consists of the People Team, Partner Collaboration Center, Vendor Management Improvement Task Force, Global Technology Research, Global EHS Office, Corporate Legal Office, Investor Relations Team, and the Corporate Sustainability Center. The Council acts as an office to review response measures to human rights risks, discussing and coordinating labor and human rights issues at our business sites and across our supply chains. Depending on the saliency and urgency, agenda items discussed at the Labor and Human Rights Council are escalated to the Business Risk Management Council, the Sustainability Council, and the Sustainability Committee.

Samsung Electronics Labor and Human Rights Governance The People Team develops training programs on respecting human rights and related policies for our employees, and leads due diligence programs, including third-party Responsible Business Alliance (RBA) 1) audits and Human Rights Impact Assessments. An executive within the People Team, responsible for overseeing personnel and labor affairs at our global locations, leads the implementation of human rights respect activities within the company. This executive is evaluated in alignment with the company's human rights due diligence goals; evaluation results are reflected in the executive's compensation. A group of colleagues within the People Team manage daily human rights risks related to employees and integrates human rights risk management strategies into company policies, establishing them as standard practices and disseminating them throughout the organization. Additionally, since 2017, a separate, dedicated group has been established under the People Team to engage with external stakeholders in the area of labor and human rights and play a role to provide internal and external information on business and human rights.

The Global EHS Office establishes standards related to occupational health, safety and environment in our Korean and global workplaces and supports their implementation in and across our workplace and supply chain. The Corporate Legal Office, Investor Relations Team, and the Corporate Sustainability Center communicate global legislative developments and stakeholder expectations, including those of investors and customers, within the organization. The Partner Collaboration Center, Vendor Management Improvement Task Force, and Global Technology Research are responsible for monitoring the implementation of human rights policies in the supply chains.

1) An industry coalition dedicated to responsible business conduct in global supply chains

## DEI Office·DS Culture &amp; Diversity Lab

The DEI Office, established under the People Team of the DX Division, is a dedicated group responsible for diversity, equity, and inclusion. It aims to create an inclusive organizational culture where all members have equal opportunities and can fully develop their capabilities without discrimination. To achieve this goal, it collaborates with business units, regional Heads, and local managers to support various programs. The DS

Division has been operating the Culture &amp; Diversity Lab since 2022 with the goal of fostering an inclusive organizational culture. It conducts education for all leaders and members to enhance awareness of inclusive organizational culture and mutual cooperation. Additionally, it collaborates with external experts by operating a DEI advisory board.

## SEU·DS University

The DX Division's Samsung Electronics University (SEU) is an educational governance system that integrates employee training groups, previously scattered across different job functions, into a unified structure, enabling employees to grow autonomously. Additionally, the DS Division provides job training through the DS University.

## Strategy

Samsung Electronics respects human rights, diversity, and inclusion based on its 'People First' corporate philosophy and strives to ensure that these values are reflected in our corporate practices. In addition, we promote improvement activities to foster a safe work environment and foster a corporate culture that is conducive to work by actively supporting their personal growth. We also conduct activities to expand positive impacts on and mitigate negative impacts from sustainability issues related to employees.

[Human Rights Management Mid- to Long-Term Goals](https://www.samsung.com/global/sustainability/people/human-rights/#AYUqpazKDLYAIx_C)

## Key Sustainability Issues for Employees

| Working Conditions · Freedomofassociation andright to collective bargaining · Right to an adequate standard of living · Health and safety · Work-life balance and benefits   | Forced Labor · Prevention of forced labor   | Equal Treatmentand Opportunity · Non-discrimination · Support for employees with disabilities ·Empowermentofwomen in the workforce · Talent development   |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------|

35

## Risk Management

## Policy

Samsung Electronics respects and supports internationally recognized human rights standards. We announced the 'Samsung Electronics Global Human Rights Principles' (the Policy) which reflect our top management's commitment to respect human rights. The Policy expresses our commitment to respecting and supporting the human rights of all individuals in accordance with international human rights standards and principles. The Policy also commits to to preventing human rights violations that may occur during global business activities and providing effective remedies in cases where harm has occurred. Additionally, the Policy introduces human rights governance, including human rights training and due diligence, as well as the management of 11 salient human rights impacts identified as actual or potential human rights risks for the company.

## [Samsung Electronics Global Human Rights Principles](https://www.samsung.com/global/sustainability/policy-file/AYZO1Ym6CLsALYN7/Samsung_Electronics_Global_Human_Rights_Principles_en.pdf)

## Respect for International Human Rights Standards

Samsung Electronics respects the following international human rights standards.

- ‧ Universal Declaration of Human Rights
- ‧ International Covenant on Civil and Political Rights
- ‧ International Covenant on Economic, Social and Cultural Rights
- ‧   International Labour Organization (ILO) Declaration on Fundamental Principles and Rights at Work
- ‧ UN Guiding Principles on Business and Human Rights
- ‧ OECD Guidelines for Multinational Enterprises
- ‧ UN Convention on the Rights of the Child
- ‧   UN Protocol to Prevent, Suppress and Punish Trafficking in Persons, Especially Women and Children

<!-- image -->

## [Samsung Electronics Code of Conduct](https://www.samsung.com/global/sustainability/policy-file/AYVhRDv6BbgAIx95/Samsung_Electronics_Global_Code_of_Conduct_en.pdf)

We established the 'Samsung Electronics Code of Conduct' based on the 'Samsung Business Principles' to comply with laws and ethics, fulfill our corporate role, and take on social responsibilities. This code sets out the standards for employee behavior and values that employees should adhere to in all business activities.

## [Child Labor Prohibition Policy](https://www.samsung.com/global/sustainability/policy-file/AYVhQx26BX4AIx95/Child_Labor_Prohibition_Policy.pdf)

We consider child labor to be a serious criminal act that is unacceptable at any stage of our business activities. We established and apply a zerotolerance policy against child labor, which is prohibited by international standards and laws.

## [Migrant Worker Policy](https://www.samsung.com/global/sustainability/policy-file/AYVhQm_KBWEAIx95/Migrant_Worker_Policy.pdf)

We protect the rights of migrant workers, who may be particularly vulnerable to the risks of human trafficking and forced labor, and maintain a zero-tolerance policy against workers paying recruitment fees.

## [Anti-Discrimination and Harassment Policy](https://www.samsung.com/global/sustainability/policy-file/AYVhPVsqBMEAIx95/Anti-Discrimination_and_Harassment_Policy.pdf)

We do not discriminate against any current or prospective employees based on gender identity, race, ethnicity, nationality, religion, age, marital status, sexual orientation, among others or in HR matters such as job assignment, promotion, compensation and disciplinary measures. We also recognize and seek to prevent harassment, which includes inappropriate, unwelcome behavior and threats that result in physical, psychological, sexual, or economic harm.

## [Global Grievance Resolution Policy](https://www.samsung.com/global/sustainability/policy-file/AY8FPchqja4ALYMK/Samsung_Electronics_Global_Grievance_Resolution_Policy.pdf)

We established the 'Global Grievance Resolution Policy' to handle grievances in a fair and consistent manner. This policy sets out a standard for processing all grievances received by Samsung Electronics. It covers grievance channels, procedures, and principles. We apply the following principles to resolve grievances: adherence to the effectiveness criteria of grievance mechanisms outlined in the UN Guiding Principles on Business and Human Rights, prohibition of retaliation against whistleblowers, protection of human rights defenders, confidentiality and data protection, and ensuring participation in external grievance mechanisms to facilitate grievance resolution between parties.

## Human Rights Training

Samsung Electronics conducts annual human rights trainings to ensure that employees understand their rights and embed respect for human rights in all aspects of business activities.

## Training for General Employees

Samsung Electronics conducts human rights trainings for all employees annually. The company-wide human rights education covers understanding human rights, the corporate responsibilities to respect human rights, integrating the respect for human rights throughout business activities, employee rights in the workplace, and employee respect towards human rights. In manufacturing sites, mandatory human rights training for all employees includes both offline and online courses, with the offline sessions conducted in the local languages. In 2024, 95.7% of all employees completed the training for general employees, with online and offline completion rates of 93.4% and 98.8%, respectively.

## Training for Employees in Specific Roles

In 2021, Samsung Electronics introduced human rights training for personnel, security, administration, and procurement functional role holders who work in areas with significant human rights risks. Notably, human rights training for procurement personnel is conducted annually. In 2024, the human rights training for functional role holders was tailored to meet the strengthening global due diligence requirements, targeting due diligence officers at overseas production sites, sales locations, and research centers. As part of the 2024 due diligence officer training, which was conducted as part of the Human Rights Risk Assessment, the program covered the company's commitment to respecting human rights, major human rights risks, human rights due diligence frameworks, best practices in the IT industry, relevant international standards, and legislative situations in key countries.

## [Procurement Personnel Training](https://www.samsung.com/global/sustainability/people/supply-chain/#AYUquOkKDt4AIx_C)

## Human Rights Champion Training

Since 2020, Samsung Electronics has designated approximately 60 staff in human resources, labor relations, and training roles at our global locations as 'Human Rights Champions' and conducts training to share the importance of corporate human rights respect and best practices. In 2024, the Human Rights Champion training covered topics including the EU's legislative situation regarding due diligence, the implications of such legislation, international standards on freedom of association and collective bargaining, and the company's global grievance policy.

36

## Human Rights Due Diligence

Samsung Electronics strives to identify, prevent, mitigate, and address the negative impacts of our business activities on human rights. Through various human rights due diligence processes, including human rights risk assessments, third-party audits, and self-assessments, we identify potential and actual human rights risks and incorporate insights gained into our policies and systems.

In 2023, Samsung Electronics hosted our first Human Rights Stakeholder Workshop in collaboration with experts from the International Labour Organization (ILO), UN human rights experts, global NGOs, and labor unions to discuss our approach to human rights due diligence. We incorporated the feedback from the experts at the workshop into our human rights risk management process. Additionally, to diligently fulfill the corporate human rights due diligence obligations being legislated in various countries, Samsung Electronics began reviewing and improving its human rights risk management system in 2024.

## Samsung Electronics Human Rights Risk Management Process

<!-- image -->

## Step 4.

## Implement Plans and Monitor Effectiveness

Samsung Electronics strives to build systems that enable all business sites to manage human rights risks and monitor the effectiveness of the measures taken.

① Labor Rights Risk Management System Samsung Electronics upgraded our monitoring system, originally established in 2013 to support compliance with labor rights and corporate governance, to the 'Business &amp; Human Rights Benchmark (BHRB) System' in 2023. This system evaluates whether Samsung Electronics' DX Division manufacturing sites comply with international human rights standards, such as the 'ILO Declaration on Fundamental Principles and Rights at Work' and the 'UN Guiding Principles on Business and Human Rights'.

Evaluation indicators consist of 4 major categories-labor rights, organizational culture, working environment, and diversity, equity, and inclusion-covering 39 items and 159 detailed indicators. Each site is evaluated on an annual basis and, for sites requiring improvement, consulting and simplified human rights impact assessments are conducted. Additionally, the system enables sites to identify best practices by indicator, helping them to improve respect for human rights.

In 2024, Samsung Electronics conducted BHRB evaluations for 19 manufacturing sites and issued consulting reports for each site, providing guidance on areas requiring improvement. In 2025, we plan to further systematize site operations using the BHRB evaluation indicators and support each location in embedding human rights respect into its management practices.

② Simplified Human Rights Impact Assessment Samsung Electronics' internal labor and human rights experts carry out Simplified Human Rights Impact Assessments using a streamlined approach compared to third-party human rights impact assessments.

Our internal labor and human rights experts identify business sites that need improvement, and take an in-depth look at the level of respect for labor and human rights in the country of operation, the organizational culture diagnosis results, grievances received, workforce changes, potential violations of company policies, and previously identified human rights risks.

The assessment includes interviews with vulnerable groups within the site as well as interviews with local external stakeholders. The assessment evaluates potential and actual human rights impacts resulting from business activities and develops measures to prevent, mitigate, and address identified impacts, tracking their implementation.

③ Topic-Specific Assessments We created an assessment tool that complies with international standards for vulnerable groups within the company such as migrant workers and female employees, and conducted on-site inspections. Notably, we implemented migrant worker audits for four sites employing migrant workers, using the Responsible Business Alliance (RBA) audit standards and key industry references to verify compliance with migrant worker policies and Samsung Electronics policy implementation guidelines.

In 2024, we selected 7 manufacturing sites within the DX Division that had previously raised labor relations grievances as inspection targets. We conducted assessments to identify labor relations risk factors at the sites. The assessments focused on over 100 checkpoints, including external factors such as the country's inflation rate and wage levels of neighboring companies, the site's HR systems, grievance handling channels and representative bodies, communication between site managers and the general manager with employees, and the capabilities of labor relations officers.

④ RBA Third-Party Audits Samsung Electronics, as a member of the Responsible Business Alliance (RBA), supports the RBA's vision and goals in its global operations and strives to comply with the RBA Code of Conduct. The RBA Code of Conduct is based on international norms and standards including the Universal Declaration of Human Rights and ILO International Labor Standards, and is regularly updated to reflect changes in international standards. Samsung Electronics' manufacturing sites conduct annual RBA self-assessments. All manufacturing sites undergo third-party audits of Labor, Health and Safety, Environment, Ethics, Supply Chain Management by RBA certified audit firms at least once every two years based on the Validated Assessment Program (VAP) or Auditee Managed Assessment criteria.

Worker interviews are mandatory during on-site audits, and any findings identified in manufacturing sites are addressed by developing corrective action plans to address findings and improve systems to prevent recurrence. The corrective action plans developed by each manufacturing site shall be approved by third-party audit experts, and approved plans must be completed within the timeframe specified by the RBA VAP criteria. In 2024, a total of 13 manufacturing sites (7 in DX and 6 in DS Divisions) underwent RBA audits. 9 of the sites earned the full score of 200 points, achieving the Platinum grade, the highest level in the RBA VAP Recognition Program. For some manufacturing sites with findings in labor and occupational health and safety areas, all corrective measures were completed.

## [2024 RBA VAP Summary](https://www.samsung.com/global/sustainability/policy-file/AZA0youKHCsALYNu/RBA_VAP_summary_en.pdf)

⑤ Tracking Effectiveness Samsung Electronics monitors our effectiveness of measures to respect human rights through various methods. The effectiveness of the grievance mechanism is assessed via an annual satisfaction survey of employees. The effectiveness of anti-discrimination activities is tracked through employee responses to related items in the annual organizational culture diagnosis conducted for all employees.

[Samsung Culture Index Results - DEI](https://www.samsung.com/global/sustainability/people/diversity-inclusion/#anchor1)

## Grievance Resolution

Samsung Electronics is committed to conducting thorough due diligence to prevent our business operations from causing or contributing to any adverse impacts on human rights or engaging in human rights abuses. If individuals or groups of individuals affected by the company's business activities submit a grievance for experiencing negative impacts from the company's business activities, we strive to provide effective remedies to those affected. In April 2024, Samsung Electronics established and disclosed our Global Grievance Resolution Policy and distributed guidelines to global business sites to ensure  effective implementation.

In January 2025, staff members to deal with grievances were put in place at several sales offices and research centers where grievance channels and governance structures were unclear. Additionally, staff members dealing with grievances including new hires were trained on the grievance policy and guidelines. This training is to ensure that the company's grievance mechanisms meet the effectiveness criteria set out in the UN Guiding Principles on Business and Human Rights.

## Grievance Resolution Channels

Samsung Electronics operates various grievance channels, including online, offline, hotlines, and worker representative bodies, ensuring that not only employees but also supply chain workers, NGOs, and others can raise grievances.

In addition, in some countries and a region the company collaborates with third-party organizations to provide additional grievance handling channels. A third-party grievance channel launched in Brazil in 2018 has proven effective and has been expanded to the entire Latin America region. It has been used in sites located in Germany, France, and Nordic countries. Additionally, at a business site, an employeeparticipatory grievance committee was established and operates based on suggestions from worker representative bodies.

## Grievance Resolution Channels

Online

<!-- image -->

<!-- image -->

Company intranet grievance resolution system or email Hotline Direct line or anonymous Employee Representative Bodies (ERBs)

Offline Suggestion boxes located in non-public areas

<!-- image -->

<!-- image -->

Employee Council, Labor Unions

## Operation and Management

Samsung Electronics regularly reviews and improves its systems and processes to ensure that grievants can access grievance channels effectively and receive appropriate remedies.

Grievance Management Status Assessments Samsung Electronics conducts annual assessments on the status of grievances received through its grievance channels to track the number, types, and trends of grievances. The dedicated members in charge of human rights review these assessment results to identify changes in the use of grievance channels and the types of grievances received. These findings were utilized in the development of the 2024 Global Grievance Resolution Policy.

Employee Satisfaction Survey on Grievance Resolution Samsung Electronics conducts an anonymous annual survey on grievance resolution to manage the utilization of grievance channels by employees, their trust in the process, and the outcomes. The survey assesses grievants' awareness of and satisfaction with the grievance channels. Additionally, we verify whether local grievance channels are operated in accordance with the effectiveness criteria of the UN Guiding Principles on Business and Human Rights as committed to in our grievance policy. The survey, which was conducted primarily in manufacturing sites until 2024, will be expanded to to include sales sites and research centers within the DX Division in 2025, as part of the implementation plan for the Global Grievance Resolution Policy.

<!-- image -->

1) Grievance resolution performance disclosure scope: DX Division, DS Division

- ※   Grievance resolution performance disclosure scope changed in 2024 to include DS Division

<!-- image -->

## Employee Communication

## Employee Representative Bodies

Employee representative bodies communicate with the company to improve working conditions and convey workers' opinions on strategic decisions. The company communicates with employee representative bodies through collective bargaining and regular meetings, and collects employee opinions.

Labor Unions There are 33 unions representing employees worldwide. Samsung Electronics negotiates employment conditions with these unions and signs collective agreements in accordance with the laws of each country. As of the end of 2024, 42.7% of global employees worldwide are covered by collective agreements.

Works Councils We have works councils at 45 sites around the world, depending on the laws of each country and the circumstances of each site. Employees at each site elect their representatives and works councils through voting. Each works council holds regular meetings to discuss various agenda items aimed at improving employee working conditions, such as wages and welfare benefits.

## Communications with Executive Management

Samsung Electronics conducts annual town hall meetings, led by Division Heads and business unit leaders, to share management philosophy, business direction, and key management agendas with employees, addressing their questions and suggestions. Additionally, team and group leaders build rapport with employees through monthly meetings and organizational activation events, and directly listen to employee concerns through one-on-one meetings and regular briefings.

## Organizational Culture Diagnosis

The Samsung Culture Index (SCI) is an annual organizational culture diagnosis conducted among Samsung Electronics employees worldwide. The SCI assessment covers three areas: 'Enjoyable Work,' 'Colleagues Working Together,' and 'Proud Company.' Each area includes Outcome questions to gauge the health of the organizational culture and Driver questions to identify improvement points, making it easier to discover and address issues specific to each organization. In 2024, employees from a total of 136 sites worldwide participated in the SCI assessment.

[Organizational Culture Improvements](https://www.samsung.com/global/sustainability/people/human-rights/#AYUqrjgqDcoAIx_C)

<!-- image -->

39

<!-- image -->

## Activities

## Ensuring Freedom of Association and Collective Bargaining

Freedom of association is the right of workers to form or join a trade union. Collective bargaining is one of the key vehicles that help employers and legitimate trade unions jointly work toward fair working conditions, equal opportunities, and sound industrial relations.

Samsung Electronics respects labor unions and all other forms of employee representation activities. It ensures that no workers are discriminated against, retaliated against, harassed, or otherwise adversely affected by joining or forming a labor union, requesting collective bargaining, participating in collective bargaining, or exercising their right to organize or bargain collectively.

Samsung Electronics engages in collective bargaining with an open attitude based on mutual trust between labor and management and strives to resolve issues through sincere labor-management discussions, considering respective labor practices by site and region.

Additionally, we operate a labor-management relations advisory group composed of four external experts under the Board of Directors. The experts review labor-management issues at Samsung Electronics, and make mid-to-long term recommendations for our practices to management and People Team leaders.

Samsung Electronics has signed a wage and collective bargaining agreement with unions in Korea in March 2025 through sincere negotiations. We strive to build cooperative labor-management relations by improving working conditions and expanding the infrastructure for union activities in accordance with the concluded agreement.

## Freedom of Association and Collective Bargaining

2020 2021 2022 2024 2025

‧   Established Labor Relations Advisory Group under Board of Directors

‧   Revised migrant worker policy and developed policy implementation guidelines

‧ Signed the first agreement on wages, leaves, and more (Korea)

‧   Reached tentative agreement on wage and collective bargaining (Korea)

‧   Concluded agreement on wage and collective bargaining (Korea)

## Protecting the Right to an Adequate Standard of Living

Paying a living wage is one of the ways to ensure an appropriate standard of living for workers, reduce inequality, and address issues related to working hours and other working conditions. A living wage is generally understood as sufficient income for a worker and their family to maintain an appropriate standard of living based on standard weekly working hours.

Samsung Electronics strives to provide an appropriate standard of living for its employees, offering compensations that meet the basic needs of workers and their families who depend on them.

Since starting the calculation of living wages in collaboration with the Business for Social Responsibility (BSR) in 2018, Samsung Electronics has been independently calculating the living wages for production workers at manufacturing sites in over 20 countries worldwide since 2022. We analyze wage gaps between these sites and the calculated living wages. To ensure the accuracy of living wage calculations, we apply the widely recognized Anker Methodology and refer to economic indicators published by credible institutions such as the OECD, UN, and Eurostat. We identify various items such as household food and nonfood expenses, number of workers and dependents in a household, and other factors in the regions where manufacturing sites operate. Based on this, we recommend improvements to ensure that wages and welfare benefits at manufacturing sites align with the living wage estimated by the Anker Methodology.

Additionally, Samsung Electronics participates in the RBA's Living Wage working group to learn about global discussions on legislation and standards as well as to study global best practices.

## Protecting an Adequate Standard of Living

<!-- image -->

‧   Started collaboration with BSR to calculate living wages in regions with our manufacturing sites

‧   Analyzed living wage gap for manufacturing employees in 20 manufacturing subsidiaries

‧   Recalculated living wage in collaboration with BSR and developed plans to align with updated figures

‧   Participated in RBA Living Wage working groups and reviewed collaboration with an intergovernmental organization

## Work-life Balance and Benefits

Samsung Electronics operates a flexible and efficient working system tailored to each job's characteristics. Through the flexible working hours system and annual leave planning, employees  flexibly manage their working hours according to individual circumstances. This is accompanied by enhancing employees' autonomy and responsibility to establish a work-smart culture. Additionally, Samsung Electronics supports various welfare and benefits programs for all employees, regardless of employment contract type to improve employees' quality of life, increase job satisfaction, boost morale, and enhance work immersion. In Korea, we provide support for personal pensions to ensure a stable retirement life and offer educational and medical expenses to help stabilize the lives of employees and their families. We also support employee health check-ups and group insurance and operate a flexible welfare system that allows employees to receive benefits tailored to their individual lifestyles.

## System for Work-life Balance

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## Development day for self-improvement (Korea)

Employees who meet required monthly working hours may use the pay week's Friday for self-development and recharging.

## Remote working for work-family balance

We implemented remote working even after the COVID-19 pandemic ended to maintain a better work-life balance, and increased collaboration and work efficiency through remote working under a pre-planned schedule.

## Pregnancy, childbirth, and parenting support (Korea)

Employees may apply for reduced working hours throughout their entire pregnancy. In high-risk pregnancies, they may use paid reduced working hours throughout the pregnancy. We operate a system providing 20 paid paternity leave days and 5 paid infertility leave days. Additionally, we support work-family balance through practices such as 3 paid days of miscarriage leave for spouses. We operate one of the largest daycare centers in Korea and introduced a rebounding program for employees returning from parental leave.

## Flexible workspace (Korea)

We have 8 flexible workplaces: 3 off-site offices in Seoul (Seocho Office Building), Daegu (ABL Tower), and Bundang (Mirae Asset Place) and 5 flexible work zones at Digital City (Suwon), Future Technology Campus (Suwon), Seoul R&amp;D Campus (Seoul), Smart City (Gumi), and Green City (Gwangju).

40

## Preventing Forced Labor

There are several factors leading to forced labor, but one of the most widely recognized is the recruitment fees paid by workers, especially migrant workers, to find and maintain employment. Samsung Electronics regularly evaluates overall working conditions in our manufacturing sites through self-assessments and third-party audits, considering "prohibition of forced labor" as one of the key indicators of working conditions in accordance with the RBA Code of Conduct.

We develop customized assessment tools for manufacturing sites employing foreign migrant workers. We conduct on-site audits of manufacturing sites and external dormitories, as well as face-to-face interviews verifying living conditions, to prevent forced labor. We perform pre-recruitment audits of employee sending country recruitment agencies and online/offline interviews with job applicants to prevent forced labor, and regularly hold compliance workshops with executives and staff members from partner companies and recruitment agencies.

In particular, we pay special attention to manufacturing sites in Malaysia, Poland, Hungary, and Slovakia, where migrant workers are employed. Most of these migrant workers are already residents in the host country, but we conduct onboarding training to help them understand their rights and ensure they can raise grievances in their native languages.

In 2024, Samsung Electronics' manufacturing site in Malaysia introduced its recruitment process improvements, treatment enhancements, and compliance conferences for partner companies at a regional seminar on "Eliminating Forced Labor."

## Preventing Forced Labor

<!-- image -->

‧   International Organization for Migration (IOM) workshop to raise awareness on labor rights protection

- ※   ~2022, targeting manufacturing sites and suppliers employing migrant workers

‧   Negotiated with joint labor union bargaining committee, signed first collective bargaining agreement (Korea)

‧   Reimbursed USD 136 of unpaid transportation expenses to 3 newly hired migrant workers

- ※ Based on average 2023 currency exchange rate: USD 1.00 = HUF 395.0

‧   Attended and presented at Malaysian Ministry of Labour's "Eliminating Forced Labor" seminar

## Non-Discrimination

The International Labour Organization (ILO) defines discrimination as any distinction, exclusion, or preference based on race, skin color, gender, religion, political opinion, nationality, or social origin. Discrimination negatively affects equality of opportunity or treatment in employment or occupation.

Samsung Electronics has established policies and guidelines prohibiting discrimination and harassment and has developed a gender equality self-assessment toolkit for use in our workplaces. We continuously conduct employee training on discrimination to reduce discriminatory practices.

In the global ICT industry, women make up a significant portion of the workforce, and it is necessary to consider the needs of women in the workplace. we prohibit discrimination based on gender, pregnancy, and other factors in our hiring and employment practices, including workplace health and safety, promotions, rewards, and training opportunities related to the work of pregnant and nursing mothers, in accordance with the RBA Code of Conduct. Furthermore, we take appropriate measures to transfer to other positions pregnant and breastfeeding employees identified as working in hazardous environments, or to eliminate or reduce occupational safety and health risks without changing employee salary or benefits levels. We also provide necessary facilities for breastfeeding mothers.

At our manufacturing site in Vietnam, where many female employees work, we have been collaborating with a Vietnam based international NGO since 2022 to conduct training on gender equality  and reproductive

## Progress on Non-Discrimination

<!-- image -->

‧   Developed anti-harassment guidelines

‧ Released Anti-Discrimination and Harassment Policy

‧   Developed gender equality self-assessment toolkit with 144 indicators and conducted self-assessments at 20 manufacturing sites

‧   Developed and distributed the Essential Guide to Gender Equality

·   Endorsed the Women's Empowerment Principles 1)

‧   Joined the Valuable 500 2)

1)   An initiative to advance women's competitiveness including equal opportunity, fairness, and nondiscrimination

2)   CEO Circle of the most influential 500 business leaders and companies established to promote the social participation of people with disabilities health for internal training staff. In 2024, training staff who received education from the NGO conducted dissemination training for all employees to raise awareness of gender equality and women's rights.

## Creating an Inclusive Culture for People with Disabilities

We aim to create an organization where all members feel a sense of belonging and can fully realize their potential based on equal opportunities, fostering an inclusive organizational culture. To achieve this, we strive to create an internal environment where employees with disabilities can demonstrate their abilities and expand employment opportunities for disabled employees. In December 2024 on the International Day of People with Disabilities we joined the Valuable 500, a global disabilities initiative, and promised to advance acceptance of the disabled.

## Accessibility Festival Week (AFW)

In May 2024, Samsung Electronics held an Accessibility Festival Week for DX Division employees in Korea to commemorate Global Accessibility Awareness Day (GAAD). We conducted activities to enhance understanding and improve accessibility features in our products, services, and designs through various programs such as accessibility idea contests, photo exhibitions, and seminars.

<!-- image -->

## Greater Possibilities Created by Diversity, Stellar Forest

Samsung Electronics established Stellar Forest, a subsidiary-type disability standard business, in March of 2023 to create sustainable employment opportunities for people with developmental disabilities. Stellar Forest is a disability standard business fully owned by Samsung Electronics, where 301 people with developmental disabilities were employed as of December 2024. In 2024, it expanded its business to include pop-up books and pop-up cards in addition to its existing bakery business, actively supporting the social participation of people with developmental disabilities. Additionally, Stellar Forest collaborates with the Samsung Stepping Stone of Hope 2.0 program to provide internship opportunities for independent youth who have completed baking and pastry courses.

<!-- image -->

<!-- image -->

<!-- image -->

41

## Empowering Women in the Workforce

## Women Leadership Targets

Samsung Electronics aims to increase the proportion of female executives to more than double the 6.9% in 2022 by 2030, striving to expand the quantitative and qualitative growth of female leaders. To achieve this, we systematically manage female employee proportions at all employment stages from recruitment to evaluation and retirement. We also operate programs such as workshops for nextgeneration female leaders and networking programs for female executives to support the growth of outstanding female talent into leadership roles.

## [Next-generation Women Leaders Workshop](https://www.samsung.com/global/sustainability/people/diversity-inclusion/#AYUqsJnKDg4AIx_C)

## Female Workforce Percentages

|                        | Categories       |   2014 |   2019 |   2024 |
|------------------------|------------------|--------|--------|--------|
| Womenin Leadership (%) | Executives       |    4.2 |    6.5 |    7.4 |
| Womenin Leadership (%) | Managers         |   12.4 |   14.7 |   18.2 |
| Womenby Job Type (%)   | Sales/ Marketing |   30.5 |   31.2 |   35.2 |
| Womenby Job Type (%)   | Development      |   16.7 |   17.5 |   19.7 |

## Managing the Gender Pay Gap

Under our Equal Pay policy, Samsung Electronics strives to provide equal pay for employees of the same job level based on similar levels of experience and performance, regardless of gender. In 2024, the gender pay gap in domestic workplaces was 23.7%, showing a slight improvement compared to the previous year. By career level (CL), CL2 had a 1.2% difference, CL3 had a 6.4% difference, and CL4 had a 5.1% difference, with men earning higher wages than women. In the case of CL1, women's wages were 1.5% higher than men's. To respond to legislation requiring public disclosure of wage equity, we conducted wage equity surveys in 2024, focusing on European sales workplaces, and derived improvement measures. In particular, we transparently disclosed gender pay gaps in the UK, France, and Brazil.

## Pay Gaps in the UK France Brazil

<!-- image -->

## Talent Development

## Talent Pipeline Management

Samsung Electronics continuously manages our internal talent pipeline to maintain a technological edge in the rapidly changing domestic and international business environment. We meticulously analyze our current business status and future core technology fields to predict medium- and long-term human resource needs by area. To secure top talent, we build a talent pool through various channels, including new recruitment and internal development.

## [Performance Evaluation and Regular Feedback Process](https://www.samsung.com/global/sustainability/people/human-rights/#AY6tdfX624QAIx-d)

## Establishment of Employee Driven Culture of Growth

Samsung Electronics' employees can apply for self-selected training during the Samsung Talent Review (STaR) Week twice a year. We provide customized programs tailored to job roles and responsibilities, and employees can now apply for courses in other job areas if they feel it is necessary, moving away from the previous system where training was limited to their own jobs. In the first semester of 2025, 825 courses were offered, and 49% of employees participated in STaR Week.

## [Enhancing the Effectiveness of Educational Programs](https://www.samsung.com/global/sustainability/people/human-rights/#AY6tdfX624QAIx-d)

Samsung Electronics University (SEU) Samsung Electronics' DX Division launched the SEU to meet the needs of employees who want to enhance their expertise and grow sustainably while performing their duties. SEU integrated the scattered training organizations for each job role into one entity. SEU supports job and leadership development training for all employees, including part-time and contract workers, through 12 schools in 3 academies. It operates various educational programs to establish an employee-led growth culture, build practical education closely linked to on-the-job needs, and promote convergence across jobs and fields.

## [SEU Educational Framework](https://www.samsung.com/global/sustainability/people/human-rights/#AY5kzZU61cUAIx-T)

DS University DS University is a comprehensive education program designed to help all DS Division employees grow as job experts. It is structured in the form of a virtual university with a department/ major system, consisting of 11 faculties and 46 departments, including design, devices, software, quality, processes, equipment, and more. It provides over 1,000 practical training courses tailored to job roles and levels, as well as various career development contents such as leadership classes and language education that match employees' growth paths.

## [DS University Educational Framework](https://www.samsung.com/global/sustainability/people/human-rights/#AY5kzZU61cUAIx-T)

## Training Programs

Samsung Electronics provides opportunities for all employees, including contract workers, to participate in various external development programs such as academic exchanges with domestic and international universities, Visiting Researcher programs, and Master of Business Administration (MBA/EMBA) courses.

Technical Competence Enhancement Samsung Institute of Technology (SSIT) began as an in-house technical university for semiconductor training in 1989 and was approved as a regular university in 2001, becoming the first in-house university in Korea to receive such accreditation. With an excellent faculty of external experts and employees, SSIT operates regular bachelor's degree programs in semiconductor and display fields, including for process/equipment and infrastructure. As of February 2025, 1,188 students have graduated from SSIT. Additionally, we established as in-house technical graduate programs the Semiconductor Display Engineering Department and the Digital Media Communication (DMC) Departments at Sungkyunkwan University to nurture the next generation of technical leaders. As of February 2025, 942 master's and 107 doctoral students have graduated from the in-house graduate programs.

Global Talent Training The 'Local Expert' program, introduced in 1990 to align with globalization trends, is an autonomous overseas training program that supports employees with more than 3 years of service to learn the language and culture of a host country for one year. To date, this program has nurtured 3,602 local experts in approximately 80 countries worldwide. Additionally, since 2023, we have operated the Samsung Talent Exchange Program (STEP), where outstanding talent from domestic and overseas workplaces can work in exchange for up to 2 years, fostering global talent.

Job Function Switching Opportunities The Job Posting system provides employees with opportunities for job transitions and is operated continuously through the internal system. Over the past 3 years, 4,176 employees have successfully transitioned to their desired roles, achieving a win-win effect for both the organization and individuals. We also actively support the smooth transition of job changers by providing change management mindset training, mentoring, and job skill education. Separately, the Free Agent (FA) system officially grants employees who have worked in the same job or department for more than 5 years the opportunity to transition to their desired roles or departments, along with opportunities to strengthen the necessary pre-transition capabilities.

42

## Safety &amp; Health

## Governance

Samsung Electronics designates a Chief Safety Officer (CSO) for each Division to oversee and manage occupational health and safety matters. In the DX Division, the Global EHS Director serves as the CSO, while in the DS Division, the Global Manufacturing &amp; Infrastructure Head holds this role. Additionally, each CSO operates specialized teams and site-specific EHS organizations teams at each site (6 Korean and 21 global sites in the DX Division, and 6 Korean and 4 global sites in the DS Division) to systematically manage potential occupational health and safety risks.

In compliance with amendments to the Occupational Safety and Health Act, we annually report occupational health and safety-related plans to our Board of Directors and obtain their approval. In 2024, the Sustainability Committee discussed key occupational health and safety issues and the status of occupational safety and health management.

## Strategy

Samsung Electronics prioritizes creating a safe and healthy working environment for all employees by setting the goal of achieving a workplace with zero major industrial accidents as its top priority. In April 2025, we established major industrial accident count and LostTime Injuries Rate (LTIR) as key performance indicators (KPIs). We plan to systematically implement initiatives to achieve zero major industrial accidents and reach a global top-tier LTIR by 2030.

<!-- image -->

## Risk Management

## Environment, Health &amp; Safety Policy

Samsung Electronics strives to create a safe workplace in accordance with our Environment, Health &amp; Safety Policy, which prioritizes environmental, safety, and health considerations. To ensure a safe working environment, we foster a safety culture that involves the participation of all employees. Additionally, we continuously conduct activities to promote employee health and improve safety risk factors.

## [Environment, Health &amp; Safety Policy](https://www.samsung.com/global/sustainability/policy-file/AYVheji6CZcAIx95/Environment_Health_Safety_Policy_EN.pdf)

## Workplace Safety Management

Samsung Electronics operates based on the international occupational health and safety management system standard (ISO 45001) and mandates ISO 45001 certification for all manufacturing sites, having completed certification at all sites in 2024. We regularly conduct environmental and safety expert diagnostics annually to identify potential risks, assess compliance with regulations, and inspect facility management practices.

## [Workplace safety management system](https://www.samsung.com/global/sustainability/people/human-rights/#AYUqqTYaDTAAIx_C)

<!-- image -->

| Incident Prevention Process                                                                 | Incident Prevention Process                                                                     | Incident Response Process   | Incident Response Process                                                                                           | Incident Response Process   |
|---------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------|-----------------------------|---------------------------------------------------------------------------------------------------------------------|-----------------------------|
| · · Safety · management 01                                                                  | Identifying Risk Factors 1) Outdated equipment regulation compliance failure Inadequate on-site | 01 02                       | Incident Occurrence · Occurrenceinformationdissemination · Incident type and crisis stage identification            |                             |
| Establish · Equipment 02                                                                    | Response life span                                                                              |                             | EmergencyAction · Crisismanagementcommitteeformation · Emergency evacuation and                                     |                             |
| projection · Safety regulation compliance measures · On-sitemanagement system               |                                                                                                 | 03                          | first aid implementation Investigation · Incident cause analysis · Secondary incident prevention                    |                             |
| Taking Remedial Action · Equipment monitoring · On-site investigations · Safety training 03 |                                                                                                 | 04                          | Restoration ·Restorationmeasureimplementation · Processamendment · Businesscontinuityplan implementation            |                             |
| Monitoring ·Performance management · Process improvement 1) Including risk analyses 04      |                                                                                                 | 05                          | Recurrence Prevention · Recurrence preventive measure establishment · Incident response system effectiveness review |                             |

## Activities

## Strengthening Our Autonomous Safety Management System

Samsung Electronics has been building a cloud-based EHS platform to integrate and manage occupational health and safety tasks at our business sites; by utilizing mobile and IoT technologies for construction and infrastructure inspections, we enhance autonomous safety management capabilities and operational efficiency on-site.

The DX Division plans to advance a real-time, site-specific risk assessment system by establishing an AI-driven data monitoring and analysis system. The DS Division aims to create sustainable workplaces through smart safety technologies like unmanned inspections using smart robots and real-time on-site monitoring with IoT technology.

## Improving Our Safety Culture

All Samsung Electronics employees strive to achieve the highest level of safety culture to not only understand and practice safety principles but also look out for the safety of our colleagues.

## Training Expert Personnel

Samsung Electronics operates a risk assessment expert training program to enhance the risk assessment capabilities of its employees. In 2024, we trained approximately 3,000 risk assessment experts.

## Risk Assessment Expert Training Process

|          | Work-specific                                                        | Process-specific                                                         |
|----------|----------------------------------------------------------------------|--------------------------------------------------------------------------|
| Basic    | Overview/theory of work-specific risk assessment &assessment methods | Overview/theory of process- specific risk assessment& assessment methods |
| Advanced | Hazardous factor identification                                      | Process risk assessment leadership training                              |
| Advisor  | Risk assessment result verification                                  | Risk assessment case studies and basic lecture methodology               |
| Expert   | Internationally recognized certification (NEBOSH) securement         | Internationally recognized certification (FSE) securement                |

43

## Spreading a Culture of Safety

Creating a workplace where everyone can work safely requires enhancing the safety culture among all employees. In July 2024, the DX Division declared the "DX Division Safety Principles,' 1) encouraging all employees to ensure each other's safety and actively participate in establishing a safety culture in daily life. To help employees naturally understand and practice safety principles, we implemented safety principle initiatives such as publishing educational webtoons, holding a safety principle best practice contest, and carrying out pedestrian safety campaigns. Meanwhile, the DS Division annually selects "Safe Influencers," a group of safety supporters so employees may autonomously identify and improve workplace hazards, and promote safety-related content to colleagues, proactively spreading a culture of safety at our business sites.

1)   Composed of 5 Basic Principles for Protecting Oneself and Colleagues and 5 Absolute Principles for Working Safely Only When Safe

<!-- image -->

## Reinforce Chemical Control

Samsung Electronics strives to create a healthy working environment by reducing chemical exposure in manufacturing sites, thereby minimizing the potential negative impact of chemicals on employee health. We implement improvements in chemical handling equipment and processes to provide a healthier workplace and actively replace or dispose of hazardous substances in manufacturing processes with less toxic alternatives. Additionally, we strengthened processes to easily confirm and manage the presence of regulated substances in chemical products used by employees. This ensures proactive risk management and exposure prevention.

In particular, the DS Division utilizes a Process Safety Management (PSM) system for equipment handling relatively high-risk chemicals to enhance safety measures and prevent major industrial accidents such as fires, explosions, and leaks caused by chemicals. In the 2024 regular assessment, the Giheung and Cheonan sites achieved the highest grade of "P".

<!-- image -->

## Musculoskeletal Disorder Prevention

## Musculoskeletal Disorder Prevention Exercise Centers

Samsung Electronics has been operating 28 exercise centers for the prevention of musculoskeletal disorders globally since 2010 to prevent and treat musculoskeletal disorders among employees and enhance their physical fitness. The centers offer a variety of programs, including group exercises, exercise prescriptions, and measurement consultations. Employees can undergo professional assessments, such as basic body composition analysis, balance testing, 3D body shape measurement, and deep muscle strength evaluation. They can also participate in diverse exercise programs tailored to their health needs through one-on-one consultations with experts. We provide musculoskeletal assistive tools to employees with musculoskeletal pain and offer a "Musculoskeletal Service on the Go' service to encourage everyone to easily engage in preventive exercises. We strive to create a healthy working environment through these initiatives.

## Work Environment Improvements

Samsung Electronics systematically investigates the risk factors for musculoskeletal disorders within our facilities to identify and address burdensome tasks. We conduct related improvement activities and focus on minimizing employee musculoskeletal strain through ergonomic work environment analysis and workspace design.

## Eliminating Musculoskeletal Disorders

The DS Division replaced all wafer boxes in Line 6 of the Giheung site in 2024 with an improved design to reduce wrist and finger strain for logistics workers, thereby enhancing the working environment and lowering risk of musculoskeletal disorders.

<!-- image -->

## Ergonomic Production Line Certification System

The Rapid Entire Body Assessment (REBA) ergonomically evaluates the impacts of a work environment within the manufacturing process on employee health and converts the results into a percentage to evaluate operational levels. Samsung Electronics' DX Division continuously improves our respective manufacturing process work environment by performing REBA.

## Employee  Wellness Promotion

Samsung Electronics provides various mental and physical health programs to create a health-friendly working environment for our employees. To enhance mental well-being, we expanded our team of medical professionals and psychological counselors. We also plan to expand personalized programs aimed at improving physical health.

## Employee Wellness Management

In order for our employees to healthily focus on their work throughout their working hours, Samsung Electronics operates specialized organizations and dedicated departments by site to promote employee health and prevent the outbreak of disease. Health check-ups are provided and in-house clinics are operated to maintain and improve employee health.

<!-- image -->

## Employee Mental Well-being Promotion

Samsung Electronics operates 30 in-house psychological counseling centers and mind health clinics in Korea and 29 in-house psychological counseling centers globally in order to assist in caring for the psychological health of our employees.

Through mind health promotion programs, stage-specific mental health education, and the activation of online counseling channels, we encourage employees to voluntarily participate in mental health initiatives. Additionally, we support mental health leave and sabbaticals for employees experiencing limitations in daily life or occupational functions.

## [Employee Mental Well-being Activities](https://www.samsung.com/global/sustainability/people/human-rights/#AYUqqueqDV4AIx_C)

<!-- image -->

<!-- image -->

44

## Sustainability in Supply Chain

## Governance

Samsung Electronics oversees and manages supply chain issues through the CEO led Sustainability Council and the Board of Directors led Sustainability Committee. The Labor and Human Rights Council also addresses labor and human rights issues across our suppliers. In 2024, Sustainability Committee supply chain-related agenda included responses to the EU Supply Chain Due Diligence Directive.

The Corporate Sustainability Center functions as the control tower for supply chain regulations such as the EU CSDDD, while the Partner Collaboration Center, Suwon Complex Support Center, Global Technology Research, and each subsidiary's dedicated departments are responsible for ensuring the day-to-day implementation of our supply chain policy. The Partner Collaboration Center oversees the establishment and distribution of Codes of Conduct for manufacturing suppliers and procurement staff to foster an environment of mutual trust based collaboration, and supports supplier operation, inspection, and capacity building activities. The Suwon Complex Support Center supports and trains in-house resident non-manufacturing suppliers, and the Global Technology Research supports and trains manufacturing suppliers on consignment. Conducting audits, improvements of practices, and information disclosures in order to enhance supplier sustainability management levels are reflected as KPIs for executives and working-level staff in responsible departments. Target achievement is linked to compensations including salaries and bonuses.

## Strategy

We not only support the business competitiveness of our suppliers but also support a wide range of issues including their labor and human rights, health and safety, and human resource development to build a sustainable supply chain. We also combined due diligence responsibilities to our supply chain risk management system to more effectively manage various sustainability issues that could arise within the supply chain. We plan to identify in advance and respond to supply chain human rights and environmental risks, minimizing negative impacts while expanding positive changes through continued improvement activities.

## Key Sustainability Issues in the Supply Chain

<!-- image -->

## Risk Management

## Policies

## Global Purchasing Code of Conduct

The Global Purchasing Code of Conduct contains core rules and ethical standards for purchasing managers, superseding any other rules or manuals.

| Ethical Procurement Standards of Practice                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            | Ethical Procurement Standards of Practice                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| · Whensourcing newsuppliers, SamsungElectronics evaluates sustainability items in addition to price and technology to register competitive suppliers, and provide all global companies with ample opportunities to do business with us through meanssuch as our OpenSourcing Program. ※Asof2024,average supplier transaction duration is 14 years · The purchase price is determined through market research, cost review, price negotiation, and price determination under agreement with the supplier. ※Accountfor issues like rawmaterial cost andlabor wagerate change whencalculating neworrenegotiated prices · SamsungElectronics maynotrequest that suppliers provide us or any other third parties with technology-related documents for price reviews or other purposes without justifiable cause. · SamsungElectronics should provide forecast (FCST) for mass production materials in order for the supplier to prepare production materials in advance. | · SamsungElectronics operates a system-based automated ordering system based on order quantities, lead times, etc. agreed with suppliers. · SamsungElectronics applies the principle of 100%acquisition of the order quantity, and unilateral change or cancellation of the quantity and delivery date is prohibited without consent from the supplier. If changes are required due to reasons such as discontinuation, specification change, or demandchange, it must be proceeded through the order change request process under agreement with suppliers. · Payment shall be determined in consultation with the supplier and paid in accordance with the terms and conditions set forth in the contract ※In2024,100%of579KoreanSMEsupplierswerepaid within 10 days |

## Supplier Code of Conduct

Samsung Electronics requires all goods and service providing suppliers to adhere to the RBA (Responsible Business Alliance) 1) Code of Conduct reflecting Samsung Electronics Supplier Code of Conduct as well as global standards and norms along with local laws and regulations including for human rights, environment, health and safety, and ethics. We also provide a Code of Conduct guide to help our suppliers voluntarily comply with the Code of Conduct and practice sustainable management.

In 2024, we revised our Supplier Code of Conduct to reflect the contents of RBA Code of Conduct, including new text specifying supplier responsibilities to participate in key supplier due diligence and improvement action item follow through.

1) Responsible Business Alliance, an industry coalition dedicated to social responsibility in the global supply chain

45

## Responsible Purchasing Policies

## Standard Supplier Contracts

Samsung Electronics strengthens the sustainability management foundation of our suppliers by explicitly stating the obligation to comply with supplier codes of conduct, including greenhouse gas (GHG) management, in the basic transaction contracts. In particular, contracts used at global sites are provided in multiple languages, such as English, Chinese, Vietnamese, and Portuguese, to ensure that local supplier representatives can easily understand them. These contracts are written in compliance with local laws, including prohibitions on child labor, forced labor, and adherence to the legal minimum wage.

## System-based Risk Management

Samsung Electronics defines various risk items, such as supplier sustainability, corruption, and natural disasters, to identify potential risks across the supply chain in advance and minimize their impacts. We are managing these risks using an integrated purchasing system.

Natural disaster risk Samsung Electronics connects with major global disaster information organization systems 1) to obtain information. When a disaster occurs, we analyze the supply chain impacts using location

information suppliers registered in the system and automatically share them with purchasing managers.

1) GDACS(Global Disaster Alert and Coordination System), USGS (United States Geological Survey)

Corruption risk Samsung Electronics conducts business transparently by systematically blocking abnormal business processes related to corruption, and regularly conducts spot checks and monitors compliance with laws and regulations related to fair trade and subcontracting.

Sustainability risk Samsung Electronics regularly monitors its suppliers' financial status, labor and human rights, environment, health and safety, and use of responsible minerals and hazardous substances, and proactively manages these issues through our systems.

## Sub-suppliers Supply Chain Management

To address the increasing volatility and uncertainty in the supply chain, Samsung Electronics is gradually expanding our information management to include not only first-tier suppliers but also sub-suppliers that supply key items. We map supply chain information (Supply Tree) for major suppliers and items to construct and operate a supply chain map. Utilizing collected information, such as actual production site details, we quickly respond to various supply chain issues.

Additionally, to establish a fair trading culture, we support and manage sub-suppliers based on the Samsung Electronics Supplier Code of Conduct. This includes improving payment conditions, ensuring labor rights compliance, supporting the creation of safe working environments, and promoting fair trade practices. Through these efforts, we are strengthening the compliance management of sub-suppliers.

## Selecting New Suppliers

Samsung Electronics comprehensively evaluates and systematically selects new suppliers based on six criteria of purchasing, quality, environment and safety, labor and human rights, anti-corruption, and finance. In-house experts in each criterion not only conduct document reviews but also additional on-site interviews and surveys to comprehensively evaluate all suppliers. We especially verify our suppliers' labor and human rights situations, including the journey of migrant workers, payment of recruitment fees, dormitory assignments, discriminatory treatment, and working hours, from the initial registration stage. In 2024, the DX Division selected 75 new suppliers while the DS Division selected 11 new suppliers.

## Comprehensive Supplier Evaluation

To encourage suppliers to improve their capabilities, Samsung Electronics conducts a comprehensive yearly evaluation of all suppliers and reflects evaluation results in the following year's purchasing policy. The DX Division grants preferential trading incentives to suppliers with excellent ratings, while the DS Division provides incentives to suppliers with excellent ratings by maintaining the previous year's rating.

Sustainability is classified as a key evaluation metric and is being considered in our evaluations. For example, suppliers with child or forced labor violations receive evaluation penalties and suppliers with exemplary GHG emission reduction records receive extra points in evaluations.

<!-- image -->

## Supplier Comprehensive Evaluation Process

<!-- image -->

## 2024 Comprehensive Supplier Evaluation Results

We conducted a comprehensive evaluation of 92% of our suppliers¹⁾ and found 75% were rated outstanding while 2.3% needed improvement.

1) Suppliers registered for less than one year excluded from evaluation.

<!-- image -->

<!-- image -->

46

## Responsible Mineral Management

Samsung Electronics established a responsible mineral management system for all suppliers that supply mass-produced materials 1) in accordance with the 5-step procedure of the OECD Due Diligence Guidelines 2) ,  and conducted a survey on the status of responsible minerals for all suppliers, carrying out preliminary verification and early improvement of any risk factor.

Samsung Electronics regularly obtains information on the status of conflict and responsible minerals of all its partners and information on smelters within its supply chain through the Samsung Electronics combined supplier management system, utilizing the Conflict Minerals Reporting Template (CMRT), Extended Minerals Reporting Template (EMRT), and Additional Minerals Reporting Template (AMRT). Furthermore, in accordance with Samsung Electronics' conflict mineral policy, we requested our suppliers to expand the implementation of the conflict mineral non-use policy.

In 2024, Samsung Electronics conducted on-site inspections for 202 global suppliers to verify the reliability of submitted information and compliance with conflict mineral policies and plans to continuously monitor not only conflict minerals but also minerals that raise issues of human rights violations or environmental destruction during the mining process and respond through global cooperation.

1)   Minerals mined in a socially responsible manner while respecting human rights and the environment

2)   OECD Due Diligence Guidance for Responsible Supply Chains of Minerals from ConflictAffected and High-Risk Areas

[Samsung Electronics' Responsible Minerals Report](https://www.samsung.com/global/sustainability/policy-file/AYVhOraaBIcAIx95/Responsible_Minerals_Report_en.pdf)

<!-- image -->

## Grievance System Construction and Operation

## Hotline

The DX Division operates a hotline for suppliers' employees to anonymously report any labor rights violations or unsafe working conditions. We also ensure the protection of informants' confidentiality throughout the entire grievance process so that our suppliers' employees can submit reports without fearing retaliation. Hotline instruction guides are displayed in local languages in offices, corridors, manufacturing facilities, dormitories, restaurants, and other frequently visited spaces. Reports are collected via phone, email, etc. Organizational units responsible for the hotline must verify the facts within 7 days of submission and send a specific remedial action plan to the whistleblower. Improvement implementations are regularly checked on and a satisfaction survey for the whistleblower is conducted to confirm grievance process efficiency. Hotline Reporting Status

## Cyber Sinmungo (Online Whistleblowing Channel)

Since 2010, Samsung Electronics' DX Division has been listening to the concerns and suggestions of various stakeholders, including firsttier suppliers, as well as sub-suppliers, with whom it deals directly or indirectly. Suppliers and their workers can report various issues or concerns through the grievance channel (Cyber Sinmungo) on our externally accessible Purchasing System or via an external email account, with the option to remain anonymous. All submitted cases are verified for validity and treated in accordance to pre-defined processes and standards in a responsive, transparent, and timely manner. In cases where an extended review of the facts is required, we strive to form a committee of all relevant units to resolve the issue even if it takes time. In 2024, all 190 grievances received were resolved. In 2025, we plan to restructure the Cyber Sinmungo system for user convenience and speedy responses.

<!-- image -->

## Partner Collaboration Portal Grievance Reporting Channel

The DS Division receives grievances from suppliers through various channels, such as anonymous and authenticated boards on the Partner Collaboration Portal , phone calls, and emails, and continuously promotes grievance channels to improve the work environment of suppliers.

In addition, we run 'CEO ON-TALK' for CEOs of suppliers to share grievances in the management of suppliers and seek solutions to grievances. We held monthly face-to-face and non-face-to-face meetings with 378 suppliers in the DS Division in 2024 to share environmental safety policies and accident analyses, reinforcing our supplier collaboration.

<!-- image -->

## Worker Participation

Samsung Electronics listens to supplier employees during supply chain management and due diligence policy establishment and operations, including new supplier registration, supplier site audit, and grievance process development.

<!-- image -->

| EmployeeParticipation Stages           | EmployeeParticipation Stages                                                                                                                                                                                            |
|----------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Participation Stage                    | Details                                                                                                                                                                                                                 |
| Newsupplier registration               | Conduct surveys/interviews of vulnerable workers to verify prohibition of forced labor, a mandatory evaluation item                                                                                                     |
| Supplier site audit / 3 rd party audit | Interview with workers and managers numbering the square root of the total number of supplier employees ※Interviewed 1,914 employees in the 2024 3rd party audit (on-site interviews : 1,882, off-site interviews : 32) |
| Grievance process development          | Establish a reliable grievance handling system, by collecting opinions during on-site audits, worker interviews, and compliance managementworkshops.                                                                    |

47

## Supplier Due Diligence

Samsung Electronics operates an integrated due diligence process consisting of self-assessments, on-site audits, and third-party audits to manage actual and potential risks related to human rights and the environment in its supply chain. Based on the results of these due diligence activities, the company implements necessary corrective actions and conducts regular monitoring to ensure effective implementation.

Key results of on-site audits and third-party audits are utilized to comprehensively evaluate suppliers and improve the following year's policies. Incentives such as cash prizes and comprehensive evaluation score bonuses are provided to outstanding suppliers. For the DX Division, since 2023, the results of labor and human rights and environmental audits have been used to select candidates for our

## Comprehensive Supplier Due Diligence Process

<!-- image -->

<!-- image -->

<!-- image -->

|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   | Methodology                                                                                                                                                                                                                | Subject                                                                                                      | Evaluator                                                                                                                                                                                                    | 2024Performance   |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------|
| Wedevelopself-assessment tool based ontheRBAcriteria anddistribute it to all suppliers. Suppliers use this tool to conduct a self-assessment once a year andsubmittheresults · Encourage acquisition of international standards related to corporate social responsibility (e.g. ISO, SA8000, etc.) by reflecting themin self-evaluation items, giving weight to important items such as forced labor including recruitment fees, child labor, industrial accidents, etc., to preemptively identify potential supplier risk · Conduct separate sampling on-site audits annually for suppliers highly likely to violate important items                                                                                                                                                                                                                                                                                                            | · All first-tier suppliers 1) 1) Nonmanufacturing purchasing agencies, distributors, andsales agencies excluded                                                                                                            | Supplier                                                                                                     | 2,140 suppliersconductedself-assessments · DXDivision : 1,719 suppliers · DSDivision : 421suppliers · Samplingon-siteaudits: 7 suppliers (DXDivision)                                                        | Self- Assessment  |
| Ourdedicated organizational unit consisting of RBA-certified auditors conducts on-site audits of our suppliers. · Identify problems and improvement tasks related to the work environment through review of documents such as worker salary information, contracts, and policies, and interviews with workers and managers of suppliers (register/ managein combined Purchasing System) · Require immediate remediation of serious violations, such as the use of child labor or forced labor or those that can be remedied immediately on site, and verify the completion of corrective action plans within 3 months of registration of the audit findings, which is typically the case for all others ※In 2024, the DXDivision introduced on-site audits for approximately 300major 2nd-tier suppliers of high-risk first-tier suppliers 1) 1) High-risk suppliers select 2nd-tier suppliers considering factors such as transaction importance | · High risk first-tier suppliers 1) 1) 21.4% of all DXDivision first- tier suppliers with high risk manufacturing facilities considering geopolitical risk, transaction amountandrate, sustainability, andother indicators | Relevant department professional 1) 1) DXDivisionwork conducted around employeeswithRBA Auditor certificates | 377 high risk suppliers audited · DXDivision : 368 suppliers 1) · DSDivision : 9 suppliers 2) 1) All high risk first-tier suppliers 2) Focus onSCSsubsidiary's purchasing suppliers                          | On-Site Audit     |
| Audits are conducted by RBA-certified third-party audit firms, in accordance with RBAauditstandards and processes 1) . · Audits are conducted every 3 years for top 90%offirst-tier suppliers based on transaction amount and immediately upon finding related issues for high-risk suppliers with significant actual/potential impacts related to humanrights, such as forced labor · During the initial audit, any issues that can be improved are immediately corrected on-site. The results of the improvement implementation are confirmed through a closure audit 1) Documentreview(employee salary information, contracts, policies, etc.), worker/manager interview (more than the square root of the total employee number), on-site audit (initial audit, closure audit),andimprovements                                                                                                                                                | · Top 90%first-tier suppliers based on transaction amount and a part of high-risk 1) suppliers · Major second-tier supplier 1) Those suppliers with significant actual/potential impacts related to                        | humanrights, such as forced labor RBAAuditor                                                                 | 123 suppliers audited · 90first-tier suppliers (DX Division : 67, DSDivision : 23) · 33 second-tier suppliers 1) (all DXDivision) 1) Major second-tier suppliers selected by high risk first- tier suppliers | Third-Party Audit |

<!-- image -->

People

<!-- image -->

48

supplier Sustainability Awards, and incentives such as cash prizes are provided to suppliers that achieve excellent results 1) .

We also expanded our scope of supplier risk management beyond first-tier suppliers to include sub-suppliers. In accordance with RBA standards and our own guidelines, first-tier suppliers are required to conduct due diligence and corrective actions on their subsuppliers, provided this is legally permissible in the relevant country. Furthermore, the scope of the Supplier Code of Conduct has been extended from manufacturing suppliers to all suppliers providing products and services to Samsung Electronics.

From 2024, we also began implementing a new program requiring high-risk first-tier suppliers to conduct on-site audits of their secondtier suppliers. To support this, we provided a dedicated inspection toolkit aligned with our own audit standards and conducted training for first-tier suppliers. Using our risk identification criteria, first-tier suppliers identified major second-tier suppliers and conducted audits on over 300 second-tier suppliers.

<!-- image -->

In 2023, we introduced third-party audits for major second-tier suppliers in Asia. In 2024, we expanded the scope to include 90 first-tier and 33 second-tier suppliers, ensuring a more objective evaluation of working conditions. Looking ahead, we plan to develop a strengthened integrated due diligence policy in 2025 to enhance risk identification and management processes in response to evolving global supply chain regulations.

1)   In 2024, a total of 6 suppliers were awarded, with 2 suppliers from each category (Environment, Social, and Fair Trade)

## Activities

## Preventing Forced Labor

Samsung Electronics applies human rights principles throughout our management and strictly prohibits forced labor and recruitment fees of migrant workers 1) in our supply chain through the Supplier Code of Conduct Violations related to recruitment fees for migrant workers are classified as serious forced labor violations. Depending on the occurrence of forced labor issues, we may downgrade the comprehensive evaluation grade of the supplier or terminate the business relationship if the violations persist and are deemed serious.

In all processes, including the selection of new suppliers, regular audits and special forced labor audits we monitor recruitment-related fees and costs through communication with supplier management and workers. If it is confirmed that a migrant worker has paid recruitment fees, the supplier must refund the amount within 90 days.

After resuming special audits on forced labor for migrant workers previously paused due to COVID-19 in Southeast Asia and Europe, where the proportion of migrant workers is high, such as in Malaysia, Hungary, and Slovakia, we continue to conduct training on responsible recruitment procedures to enhance understanding of the migrant worker recruitment process.

- 1)   Based on ILO Core Conventions No. 29 (Forced Labor Convention) and No. 105 (Abolition of Forced Labor Convention)

※ Proportion of migrant workers among suppliers: 4.3% (as of 2024)

## Prohibition of Forced Labor Performance

<!-- image -->

<!-- image -->

## [·   Begin special audits on forced labor involving](https://www.samsung.com/global/sustainability/people/supply-chain/#AY5k2eW61lwAIx-T)

[migrant workers](https://www.samsung.com/global/sustainability/people/supply-chain/#AY5k2eW61lwAIx-T)

<!-- image -->

[·   Begin responsible recruitment procedure](https://www.samsung.com/global/sustainability/people/supply-chain/#AYUquOkKDt4AIx_C)

<!-- image -->

‧   Forced labor special audit: 5 countries, 53 suppliers Returned USD 14,838 worth of recruitment fees to 41 migrant workers

- ‧   Responsible hiring procedure training
- 2,238 responsible staff across 1,355 suppliers

## Preventing Child Labor

Samsung Electronics strictly prohibits the employment of child workers and applies a zero-tolerance policy toward suppliers that employ them. If child workers are discovered, the supplier must immediately cease employing them and improve the age verification process in the hiring process as a corrective measure.

To prevent the influx of child workers, especially during middle and high school vacations, we conduct special audits at the hiring sites of first-tier and second-tier suppliers annually. These audits thoroughly review student and youth employment, identity verification procedures, official hiring policies, and issues in the hiring process. We collect information through various channels, from supplier job postings to worker interviews, in order to rigorously assess potential and actual risks related to child labor.

## Prohibition of Child Labor Performance

<!-- image -->

·   Begin special audits for child labor

·   Expand special audit scope to second-tier suppliers

‧   DX Division: Audited 67 first-tier suppliers,

32 second-tier suppliers in East

‧ DS Division: Audited 67 first-tier suppliers in East

- ※   None of the suppliers employed child workers, but three companies were found to have gaps in their recruitment process, such as not having facial recognition to verify identity or not explicitly stating the prohibition of child labor in their contracts. Samsung Electronics and suppliers took steps to improve the situation.
- ※ Winter and summer, twice a year, with overlap

## Appropriate Work Hours

Samsung Electronics ensures that supplier employees maintain appropriate working hours by implementing a working time management feature in our integrated purchasing system. This system monitors the average and maximum working hours of all employees at each site on a monthly basis. The system also includes a severity rating for working time violations to prevent excessive overtime among suppliers' employees. Additionally, it discloses individual employee compliance rates, including working hours over three-month periods (peak, off-peak, and regular), and the usage of weekly rest days, based on third-party audit results. To support responsible purchasing practices, we provide pre-forecasting of sales needs to help suppliers effectively manage working hours. We also continuously collaborate with suppliers by offering consulting services on working time management procedures to ensure compliance with working hour standards.

## Working Hour Compliance Rate Analysis for 2024

We analyzed working hour compliance rate 1) by first-tier suppliers based on third-party audited results and found that in 2024, the rate was 93%, a slight increase from the 2023 rate of 85%, showing a return to 2022 levels. This is understood to be due to a temporary increase in factory operating rates after the end of the COVID-19 pandemic leading to a slight decline in working hour compliance rates in 2023. However, by 2024, operations stabilized, and working hour management compliance rates returned to their previous levels.

- 1)   Employees must adhere to standard 48-hour work week and must not work more than 60 hours per week including overtime, with a guarantee of at least one day off per week.

<!-- image -->

49

## Health and Safety

Samsung Electronics has set a goal of strengthening our on-site partner companies' safety and health capabilities and management systems by 2030, led by the DX Division's Global EHS Head and the DS Division's Global Manufacturing &amp; Infrastructure General Safety Officer (CSO). To this end, we plan to support consulting and assessment for obtaining certification for suppliers that have not yet obtained external certification, and to support special training for strengthening execution capabilities and consulting for post-/renewal assessments for suppliers that have obtained external certification. We are operating a training course for professional risk assessment personnel for suppliers so that they can prevent major accidents in advance by discovering and improving harmful/dangerous factors in their work. We are also communicating with supplier executives and employees through the 'Supplier Environmental Safety Portal' and are operating a Work Stoppage Right Research Group to implement improvement suggestion activities to effectively operate the work stoppage right system.

## [Supplier Health and Safety Risk Management](https://www.samsung.com/global/sustainability/people/supply-chain/#AYwauc-6WtsAIx-7)

<!-- image -->

## 2024 Health and Safety Performance

<!-- image -->

| DXDivision suppliers Regular audit                                    | 1,863 individuals 69 suppliers ranked vulnerable Accident prevention support (consulting)          |
|-----------------------------------------------------------------------|----------------------------------------------------------------------------------------------------|
| DSDivision                                                            |                                                                                                    |
| 20 courses, 258,173 individuals Training Supplier questions submitted | Accident prevention support (consulting) 152 suppliers ranked vulnerable Subjecttostopworkstoppage |

## Partner Collaboration

## Funding Support

Samsung Electronics operates various financial support programs to support the establishment of business foundations for our suppliers. Representative support programs include the Win-Win Fund, which provides low-interest loans of up to KRW 9 billion for facility investment and technology development. In 2024, a new ESG fund worth KRW 1 trillion was created through agreements with 5 major banks to support SMEs to invest in environmentally and safety-friendly facilities and equipment.

## ESG Fund Supply Process

<!-- image -->

## Semiconductor Technology and Business Consulting

Semiconductor Training Support The DS Division provides approximately 500 training courses free of charge to supplier employees. As of 2024, based on DS Division suppliers, 684 companies and 26,355 individuals have completed the training programs. The DS Division opened the Semiconductor facilities Technology Academy (SfTA) in 2018, and 66 people completed the Academy's piping specialist training program in 3 separate sessions in 2024 for a cumulative total of 916 new piping specialists.

Semiconductor Business Consulting Support The  DS Division provides customized consulting to Korean materials, component, and equipment suppliers. In-house expert consultants visit first-tier and second-tier supplier sites to help identify challenges, resolve issues and support innovation activities. We provided training in desired areas of development, manufacturing, quality, environment and safety, purchasing, sales and marketing, and consulting support for 67 projects in 2024.

We also provided business management consultations for supplier executives, dispatched technology, manufacturing, management experts to first-tier suppliers and provided manufacturing enhancement consultations to second-tier suppliers.

## Partner Collaboration Academy

Samsung Electronics established the Samsung Electronics Partner Collaboration Academy in 2013 to practice collaborative growth with its suppliers. The academy is an approximately 9,917 m 2 learning center for suppliers near our Suwon business site, and provides free support for various consulting, training, and recruitment programs for suppliers.

Learning Center The Learning Center offers more than 350 different training programs to strengthen the capabilities of supplier employees, ranging from new employees to executives. In particular, in accordance with the sustainability management education system, in addition to essential areas such as job roles and leadership, new training programs on environmental safety, GHG target management, and supply chain audit response have also been added and are being operated.

## [Supplier Capacity-Building](https://www.samsung.com/global/sustainability/people/supply-chain/#AYUquOkKDt4AIx_C)

Youth Job Center Samsung Electronics operates the Youth Job Center, a dedicated recruitment support organization, to help its suppliers secure talented employees. The center helps recruit job seekers that reflect the needs of our suppliers, holds job fairs for our suppliers, and operates an online recruitment center exclusively for our suppliers in connection with online recruitment sites.

Consulting Center The Consulting Center is comprised of experts in areas such as manufacturing, product quality, product development, and purchasing, and provides consultations to our suppliers to transfer over 50 years' worth of our technology and knowhow.

<!-- image -->

50

## Empowering Communities

## Governance

Samsung manages its community-related agenda through the Board of Directors, the Sustainability Committee, and the Sustainability Council. In 2024, the Board of Directors discussed the Social Contribution Matching Fund operation plan and donation execution plan. The Corporate Citizenship Office (CCO), ESG &amp; Smart Factory Support Center, and Creative Development Center are responsible for running CSR flagship programs.

## Strategy

Under its "Together for Tomorrow! Enabling People" vision, we are implementing programs that focus on providing quality education to all youth, with no student left out of educational opportunities, while also transferring Samsung's management know-how to SMEs and startups.

## VI S I O N

T H E M E

<!-- image -->

Creating a sustainable future

Education for Future Generations Rising together with local communities &amp; suppliers Mutual Growth

<!-- image -->

## Activities

## Education for Future Generations

Samsung Electronics strives to empower young minds as leaders of the future to drive innovation and positive social change. To this end, we not only leverage our expertise, knowledge, experience, and resources to help them develop multifaceted skills needed for the future but also operate programs to develop their creativity, curiosity, and problem solving skills. Samsung Electronics plans to operate diverse social contribution programs in close collaboration with Korean and global government institutes and organizations so more students, without exception, may have equal access to educational opportunities.

[Corporate Social Responsibility (CSR) Website](https://csr.samsung.com/en/main.do)

<!-- image -->

## Samsung Solve for Tomorrow

Samsung Solve for Tomorrow is a global idea contest designed for youth to apply their STEM 1) competencies to actual projects related to the local community and advance their creative problem-solving skills. It was first started in the USA in 2010 and is currently operating in 68 countries. Teachers and Samsung employees serve as mentors, actively supporting students as they identify root causes of problems in the local community, find creative solutions, and make them come to life. Samsung Electronics provided a total of KRW 23.5 billion in funding to Samsung Solve for Tomorrow in 2024.

1) Science, Technology, Engineering, Mathematics

Operational Performance in 2024

Participating countries

68

Participating Students 269,698

<!-- image -->

People

<!-- image -->

## Samsung Innovation Campus

Samsung Innovation Campus is a global education program designed to support youth in obtaining state of the art IT skills and practical capabilities. The program started in 2019 and is operational in 40 countries. The program offers training in topics like programming, AI, IoT, and big data in partnership with local education authorities, academic institutions, and civil society organizations in various countries, accounting for national educational environments. The program offers theoretical and hands-on training to develop IT function skills. The program also provides soft skills such as creative thinking and empathy so youth may grow into future problem solvers. Samsung Electronics provided a total of KRW 8 billion to Samsung Innovation Campus in 2024.

Operational Performance in 2024

Participating countries Participating Students

40

35,231

<!-- image -->

## Samsung SW·AI Academy for Youth

Samsung Software‧AI Academy for Youth (SSAFY) is a software professional nurturing program aimed at strengthening youth competitiveness in the job market and expanding the scope of the Korean IT ecosystem. Chosen trainees are provided with tailored software and AI training at five training centers 1) across Korea based on Samsung's software education experience. Samsung Electronics provided a total of KRW 37.5 billion in funding to SSAFY in 2024, and plans to expand training opportunities to Meister School graduates in 2025.

1) Seoul, Daejeon, Gwangju, Gumi, Busan

Operational Performance in 2024

Training Operations Centers

5

Trainees

2,200

<!-- image -->

<!-- image -->

51

## Samsung Dream Class

Samsung Dream Class is an education program designed to support, with the support and participation of Samsung employees, middle and high school students in Korea who face barriers to educational access and prepare for the future. University students, Samsung employees, and subject matter professionals serve as mentors to operate three educational courses in career exploration, future skills, and basic education. Students grow their skills, design their careers, and find opportunities for their dreams through tailored skill training and basic education including not only English and mathematics but also topics like global communication and creative coding. Samsung Electronics provided a total of KRW 8.2 billion in funding to Samsung Dream Class in 2024.

Operational Performance in 2024

Middle school students

3,727

College students

400

<!-- image -->

## Samsung Stepping Stone of Hope

Stepping Stone of Hope provides independence training and experience to adolescents who are staying in protective care facilities. Stepping Stone of Hope provides a residence for adolescents in Korea who are forced to leave protective care facilities at the age of 18 due to the nationally-set age limit,  and supports their economic independence through vocational training. In 2023, we launched Stepping Stone of Hope 2.0, an employment and career design program supporting individuals' economic independence. We operate 15 centers in 12 regions, providing an effective independent living training including various job training courses, such as for electronics/IT manufacturing technicians and semiconductor precision piping technicians. Samsung Electronics provided a total of KRW 0.4 billion in funding to Samsung Stepping Stone of Hope in 2024.

<!-- image -->

<!-- image -->

## Blue Elephant

Blue Elephant is an education and support program that aims to prevent and heal youth cyberbullying and cyber violence. The program helps students who are victims or perpetrators of cyberbullying through 5 core projects including education, campaigns, therapy, academic research, and support projects. By 2029, the program aims to reach 3 million students with its initiatives. Samsung Electronics provided a total of KRW 0.9 billion in funding to Blue Elephant in 2024.

<!-- image -->

## Nanum Kiosks

Nanum Kiosk is a fund-raising program designed to support children in need with Samsung employees' voluntary donations. Employees donate KRW 1,000 every time they tag their employee ID cards to kiosks installed on site, and when donations reach the targeted amount, they are delivered to children of vulnerable demographic groups. Nanum Kiosks are installed and operated at all business sites in Korea, and are currently operating in five additional countries (Vietnam, India, Mainland China, the United States, and Thailand), starting with Vietnam in 2019.

<!-- image -->

People

## SME &amp; Startup Support

## Smart Factory Support Initiative

Through the Smart Factory Support Initiative, approximately 170 of Samsung's experts in a variety of fields, including quality assurance, logistics, and molding, work with SMEs at their sites and share their knowledge and knowhow in establishing production systems and automation solutions and advancing production innovation through technology. We supported a total of 3,453 SMEs in Korea from 2015 to 2024.

## [Smart Factory Support Initiative](https://www.samsung.com/global/sustainability/people/empowering-communities/#AYUr0oRaE24AIx_C)

<!-- image -->

## Startup Support

Samsung Electronics operates C-Lab (Creative Lab) to discover our employees' creative ideas, link them to business, and contribute to the revitalization of the domestic startup ecosystem. C-Lab Inside is an internal venture program that supports employees in realizing their creative ideas, while C-Lab Outside is an external startup incubation program that discovers and supports the growth of promising Korean startups. As of February 2025, a total of 959 in-house ventures and startups (423 internal and 536 external) have been nurtured through C-Lab.

## [C-Lab (Creative Lab)](https://www.samsung.com/global/sustainability/people/empowering-communities/#AYUr0zKKE4UAIx_C)

## C-Lab Inside

11 projects

## C-Lab Outside

31

companies

<!-- image -->

<!-- image -->

52

## Privacy Protection &amp; Security

## Governance

At Samsung Electronics, the Global Privacy Team Head serves as Chief Privacy Officer (CPO), managing and overseeing privacy related issues. The Global Privacy Team Head-led Privacy Steering Committee decides on privacy related policies and safeguards.

Business unit privacy protection officers perform privacy audits and training within business units, while applying and managing privacy technologies. Regional HQ privacy protection officers hold privacy reviews and training for regional offices, operating Privacy Councils.

## Privacy Governance

The Information Security Center Head, as the Chief Information Security Officer (CISO), serves as the control tower for security issues. The monthly CISO-led Security Council decides on key information security policies and discusses security incident/issue responses/ improvements.

Business unit and site information security departments respond to security issues while managing security infrastructure such as entry/ exits, IT security, etc. The regional HQ information security officer develops relevant policies considering local regulations and culture, responding to security issues within the region.

## Security Governance

| Global PrivacyTeam                                                                                                  | PrivacySteeringCommittee                                                                                                            | Information SecurityCenter                                                                                           | SecurityCouncil                                                                                                                  |
|---------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------|
| ‧ Build privacy strategy, policies, and processes ‧ Privacy legal advice and support ‧Employeeeducationandawareness | ‧ Deciding on key privacy policies and safeguards ‧ Share issues and discuss countermeasures by product, service, and business unit | ‧ Oversees business unit/site information security and build governance ‧ Operate global anomaly managementstructure | ‧ Discuss key information security policies and actions ‧ Discuss &disseminate information security issues and improvement plans |

## Strategy

Samsung Electronics collects and treats personal information minimally, transparently, and securely while prioritizing your right to choose. We also identify potential risks ahead of time, developing appropriate and robust security technologies to address such risks and applying them to our products.

## The Three Privacy Principles

## Transparency

We transparently share the details on our collection and processing of personal information

<!-- image -->

## Security

All our products are designed to provide reliable services and securely protect users' personal information People

<!-- image -->

## Choice

We enable users to choose the type and extent of personal information to be collected, accessed, and shared

## Risk Management

## Policy

Samsung Electronics provides all employees with our Global Privacy Policy and operates situation appropriate policies refiecting individual national laws and systems. We also provide employees with personal information protection guidelines such as the 'Privacy Protection Guidelines for Employees' and the 'Guidelines on Third Party Personal Information Processing' to strengthen our employees' privacy and security policy implementation. Additionally, Samsung Electronics has established a Privacy Legal Management System to review and address privacy-related matters throughout the entire lifecycle of products and services, from planning to development, operation, and discontinuation, enabling risk prevention in advance.

Samsung Electronics transparently addresses our privacy policy at our Samsung Privacy site, helping users to access, delete, and update personal information associated with their Samsung account at once. We also operate the Samsung Security Reporting Portal to relay product related security update information, and receive and process product level security vulnerability reports.

## Responding to Personal Data Breaches

Samsung Electronics takes preventive measures, including technical, managerial, and physical safeguards, to prevent data breaches. In the event of a breach, we promptly remove both direct and indirect causes to prevent further breaches. We also enhance protective measures and conduct personal information protection training to prevent recurrences and minimize user impact.

In accordance with the Personal Information Protection Act, we immediately notify users and relevant authorities of any detected breaches. We provide affected users with details such as breached personal information items, breach time and circumstance, methods to minimize potential damage, response measures taken, and contact information for the department handling victim consultations through emails, website announcements, and other methods.

[Personal Data Breach Response Process](https://www.samsung.com/global/sustainability/people/tech-for-all/#AYUqnfrKC-4AIx_C)

<!-- image -->

53

<!-- image -->

## Activities

## Privacy Protection Training

All employees from top management to contract/hourly workers must complete an annual privacy protection training. Employees handling personal information in the course of their work complete annual privacy protection training specific to their job duties.

| Employees Subject to Privacy Training              | Employees Subject to Privacy Training                                                    |
|----------------------------------------------------|------------------------------------------------------------------------------------------|
| Title                                              | Subject                                                                                  |
| Privacy Protection Training                        | All employees (including management, contract workers, and alternative schedule workers) |
| Training for Privacy Protection Managers           | Assigned managers of departments operating privacy system and service                    |
| Data Processing (+outsourcing) Protection Training | Employees and consignees with privacy system access                                      |
| Location Information Protection Training           | Employees in charge of location information managementsystemandservice                   |

## Responsible Advertising

Samsung Electronics has a strict privacy policy for ads served directly through mobile and IoT devices. We use separately and randomly generated ID for each user when servicing personalized ads; this ID may be reset on user request, in which case we will immediately stop using any user information collected under the old ID.

Samsung Electronics gives our mobile and IoT device users the freedom to opt out of receiving targeted ads. Users may refuse or turn off targeted ad settings from their device settings at any time, in which case they will receive generalized ads instead. Also, if we collect and use personal information for targeted ads, we will provide users with a clear notice of purpose and obtain user consent in advance.

## [List of Prohibited Content in Advertisements](https://www.samsung.com/global/sustainability/people/tech-for-all/#AYm-MAbqbyQAIx8Q)

## International Security Certification

Samsung Electronics works to provide our customers with products and services safe from external data breach attempts in addition to protecting our own information assets. To this end, we receive internationally recognized security certifications for our management system and for our major products and infrastructure solutions.

## [International Security Certifications Record](https://www.samsung.com/global/sustainability/people/tech-for-all/#AYUqoM_KDEoAIx_C)

<!-- image -->

## Semiconductor Technology Security

Samsung Electronics recognizes core semiconductor technology protection as a key management issue not only from the company's perspective but also from national and client perspectives. Core semiconductor technologies are designated as South Korea's National Key Technologies and National High-Tech Strategic Technologies and are protected by the Act of Prevention of Divulgence and Protection of Industrial Technology, and the Act of Special Measures for Strengthening the Competitiveness of, and Protecting National High-Tech Strategic Industries. We prevent semiconductor technology security accidents by verifying our security system effectiveness through regular annual inspections. We separately established the National Core Technology Security Management Guidelines and designated executive-level management officers who review the technical security and finalize security processes and protective measures of national core technologies. In order to strengthen client information management, we sign NonDisclosure Agreements (NDAs) with corporate clients, limit client information access to select employees, and apply a mail filtering service (Compliance Guide Service, CPGS) to automatically block external forwarding of emails containing client information.

[Samsung Electronics Semiconductor National Core Technology and National High-Tech Strategic Technology](https://www.samsung.com/global/sustainability/people/tech-for-all/#AYUqoWTaDGIAIx_C)

<!-- image -->

## Robust Security Environment

## Samsung Knox Platform

Samsung Knox is a security platform that prevents hacking and unauthorized access through a multi-layer security system from the chipset to operating system (OS) to application stages. Data clients store in our products are protected in real-time on the Knox platform from boot-up. Samsung Knox is being expanded throughout all of our products from smartphones, tablets, and smart TVs to smart home appliances, IoT, and 5G devices.

## Samsung Knox Vault Solution

Samsung Knox Vault is a solution that secures applications and user information from attacks that exploit Android security vulnerabilities. In a first, the Galaxy S25 series saw the Personal Data Engine (PDE) that analyzes user specific data applied, and information analyzed from the PDE is secured by Knox Vault and safely stored on device.  In order to reinforce an easy and comfortable AI HOME experience, Knox Vault installations have been expanded to not only Samsung Electronics' mobile device products but also to our screen-installed smart home appliances, like the Bespoke AI Family Hub refrigerator and the Bespoke AI Combo.

## Mobile Security Updates

Samsung Electronics provides regular security updates for our products and services. Security update support time period for Galaxy mobile devices is for up to 7 years. We work with not only Android OS and chipset partners but also with over 200 mobile device carriers world wide to provide security patch updates to billions of Galaxy devices. We also established security standards for all Android devices, and are working with more than 1,000 partners and various security research communities to provide users with the safest mobile experience.

※   Android OS upgrade and security update availability and timing may vary by product and market.

54

[Samsung Knox Security Principles](https://www.samsung.com/global/sustainability/people/tech-for-all/#AYUqn4SqDBwAIx_C)

## Product Quality &amp; Safety

## Governance

At Samsung Electronics, the Head of the Global CS Center serves as the chief officer responsible for enterprise-wide Customer Satisfaction (CS) initiatives, ensuring customer safety and delivering flawless quality by managing and supervising the company's quality assurance system. In 2024, we established the "Quality Innovation Committee," the company's top-level quality decision-making body chaired by the CEO. This initiative aims to fundamentally resolve market quality issues and strengthen enterprise-wide quality management. The committee focuses on thoroughly reviewing quality risks of new products and addressing quality-related issues and improvement measures.

The Global CS Center and business unit quality organizations conduct real-time monitoring to prevent product quality and customer safety issues proactively. In the event of an issue, they operate product-specific regular meetings and PL (Product Liability) prevention and response processes to ensure swift root cause analysis and preventive measures.

## Quality Innovation Committee

| Interval   | Monthly                                                                                                                       |
|------------|-------------------------------------------------------------------------------------------------------------------------------|
| Members    | CEO(Committee Head), CFO, CTO, Business Unit Heads                                                                            |
| Secretary  | Global CSCenter Head                                                                                                          |
| Attendees  | Business unit development/manufacturing/CS team leaders, Production Technology Research Institute Director, etc.              |
| Agenda     | · Review of quality risks fornewmodels · Inspection of process quality status · Review of initial market quality after launch |

## Strategy

Samsung Electronics prioritizes customer safety and product quality from our products' planning and development stages. In the event of issues during product use, we provide prompt solutions and convenient services. Based on the vision of "Perfection in Quality and Service for the Best Customer Experience", we declared a quality management code of conduct and actively practice customer-centric management.

<!-- image -->

## VI S I O N

Perfection in Quality and Service for the Best Customer Experience

## T H E M E

<!-- image -->

## Quality

<!-- image -->

## Service

Establishment &amp; operation of global service system Establishment &amp; operation of global service system

## Quality Management Code of Conduct

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## Customer-centric

·   We add value to our customers by listening to their real and potential needs and incorporating them into our products.

## Fidelity to the Basics

·   Quality is our conscience and is never compromised, so we strictly adhere to our rules and processes.

## Professional mindset

·   With a zero-defect quality mindset, we practice accountability: quality is in my hands.

## Creating luxury goods

·   We embody luxury quality with our commitment to use the Samsung logo only on products of attractive quality.

## Customer creations

·   We resolve customer VOCs quickly, accurately, and compassionately to create lifelong customers based on trust and confidence.

<!-- image -->

## Risk Management

Samsung Electronics ensures product safety and quality from the planning stage through development, procurement, manufacturing, and other lifecycle evaluations, including safety, compatibility, usability, and serviceability, before launch. We especially strengthened our quality assurance system by establishing a three-stage Gating system led by enterprise-wide dedicated teams across the pre-development, commercialization, and mass production preparation phases.

## 3 Stage Gating System

<!-- image -->

·   Blocking Potential Risks of New Technologies Through Pre-Qualification Approval

·   Commercialization Enhancing Sample Analysis and Field Verification with Key Module Partner Companies

·   Strengthening Quality Assurance Systems for New Product Quality Assurance

In 2024, we established a Quality Auditing Group to analyze root causes of quality failures and implement preventive measures by improving work processes and systems, preventing future recurrence in future models.

## Activities

## Product Quality &amp; Safety Expert Training

Samsung Electronics enhances the quality and product safety understanding and capabilities of our Korean and global employees by offering courses based on the CS School education roadmap at Samsung Electronics University (SEU). These courses include product reliability, Fault Tree Analysis, Failure Mode and Effects Analysis, Product Liability preventive design, and battery/power safety to support employee skill development.

We also support training for obtaining international certifications such as the American Society for Quality's Certified Quality Engineer, Certified Reliability Engineer, and Certified Fire and Explosion Investigator to cultivate product quality and safety experts.

<!-- image -->

55

## Ensuring Product Safety

Samsung Electronics operates an internationally accredited testing laboratory to ensure product safety, with qualifications in product safety, communication standards, and electromagnetic compatibility assessments. To effectively respond to newly established standards in various countries, we expand our equipment investment and enhance our technological capabilities.

In particular, to prevent damage expansion in the event of product failure or component malfunction, we apply dual safety design to products and components. We also conduct safety verification by considering scenarios where customers may use products in abnormal ways or harsh environments. For major components with a high risk of accidents, such as large batteries, power supplies, and chargers, we perform separate intensive safety inspections.

## Supporting Safe Product Use for Child Users

Samsung Electronics supports child protection features across various products, including mobile devices, TVs, and home appliances, to ensure the safety of child users. For mobile devices, child users are restricted in downloading apps, making in-app purchases, and accessing web content based on parental settings. Through collaboration with Google, we provide features such as usage time management for mobile devices and apps, School Time to limit mobile device use during school hours, and contact management that allows new contact registrations only with parental approval 1) .

For smart TVs, parents can restrict content usage based on viewing age or rating and block access to specific channels or apps. This feature is also available on Family Hub refrigerators with screen displays. Restricted content or apps can only be accessed by entering a password set by the parents.

As of June 2025, the child account service is supported in 55 countries, including Korea, the United States, China, Europe (32 countries), Latin America (5 countries), and the Middle East and Africa (15 countries).

1) Contact management feature supported on select watch models

## Ensuring Product Quality

Samsung Electronics operates a quality assurance system throughout the entire product lifecycle to secure the highest level of quality. Documented standards are applied to all tasks and processes, and quality-related inspections and improvements are continuously conducted for purchasing partner companies.

## Development Stage

Samsung Electronics operates a Customer Satisfaction (CS) certification system for new products, which involves evaluating performance, reliability, safety, and other factors at each development stage. Only products that meet all evaluation criteria are released to the market. During the development of new products, we use the Product Lifecycle Management system to manage past failure cases and issues from the planning stage of new product development, preventing recurrence of similar problems. Additionally, durability reliability and real-use tests are conducted using new verification methods for new technologies and features, and production is only approved if customer-required quality standards are met.

## Purchasing Stage

For components produced and supplied by suppliers, we use the Supplier Quality Control Innovation(SQCI) system for quality management. Based on a three-strike supplier quality warning system, penalties such as adjusting supplier volumes or halting transactions are applied in cases of quality incidents, hazardous substance occurrences, or poor quality evaluation grades.

## Quality Warning System for Suppliers

| Count   | Action                                                                   |
|---------|--------------------------------------------------------------------------|
| 1st     | Issue Warning Notice Based on Supplier Quality Warning Criteria          |
| 2nd     | Implement Purchase Order Block for the InvolvedItemforaMinimum of3Months |
| 3rd     | Suspend Transactions with SupplierforaMinimumof6Months                   |

## Manufacturing Stage

Samsung Electronics operates as an ISO 9001 certified company based on the International Quality Management System. We conduct internal inspections annually at all manufacturing sites worldwide, both Korean and global. We evaluate quality levels and assurance systems to ensure consistent production of high-quality products that meet customer satisfaction through the Samsung Electronics Quality Awards (SQA) system and conduct Target Sampling Inspections (TSI) 1) on products with high probability of defects.

1)    An approach used to overcome limitations of traditional sampling methods; automatically extracts and inspects products with a high probability of defects by systematically analyzing the correlation between market defects and process inspection data, enabling preemptive prediction of defect occurrence probabilities.

## Sales Stage

We manage global market quality-related information in real-time through the Quality Information Network of Global Samsung (QINGS) information system. Should quality issues arise, early warnings, production halts, and other emergency improvement measures are implemented, and relevant departments collaborate to swiftly develop and implement solutions.

## Quality Assurance System Across the Product Lifecycle

<!-- image -->

Quality assessment at each development stage (CS Certification System)

· Identify potential risks in new products

- Make improvements before mass production

Supplier quality control for parts (SQCI System) ·   Conduct supplier quality assessments &amp; incoming parts inspections ·   Implement quality warning system for suppliers failing to meet quality standards

Innovation of process and outgoing quality at manufacturing sites (SQA System, etc.)

·   Evaluate quality levels &amp; assurance systems through SQA system · Strengthen inspections for business sites with quality issues · Perform TSI on products with higher likelihood of defects

Collection, analysis, and improvement of market defect data (QINGS Information System)

-   Analyze real-time market quality data through Market Quality Analysis System
-   Collaborate with relevant business units to promptly develop response measures should issues arise

56

## Customer Service

Samsung Electronics aims to maximize customer satisfaction by providing the best possible service to our customers and responding swiftly and effectively to their needs. We established a customer service operation system to manage product services status in realtime and increased repair accuracy and response speed by integrating AI analysis technology into our system.

## Service Channels

As of the end of 2024, Samsung Electronics operates 12,925 service centers in 217 countries to support product repairs. Beyond this, we provide various consultation channels where customers can submit service requests and share their opinions about products. Detailed instructions for using each channel are available on Samsung.com. Needs/requirements collected via specialized consultation channels such as chatbot support, remote support, email support, phone support, and sign language support are shared internally across departments to improve products and services.

| SamsungElectronics Service Channels    | SamsungElectronics Service Channels                                                                                                                                                     |
|----------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Service Requests and Product Inquiries | ·ContactCenter -Phone/Chat/EmailSupport,RemoteConsultation · Website CustomerSupportSelf -Diagnosis, Usage Instructions · Store Visit - Galaxy Consultant 1) ·SamsungMembersApplication |
| Product Repair                         | · CustomerService Center Visits · HomeVisit, Pickup Repairs, etc.                                                                                                                       |

1)   Galaxy smartphone experts with specialized knowledge of Galaxy products, providing a range of services from product feature consultations and experiences to Smart Academy

## Self-Repairs

Samsung Electronics operates a customer self-repair program to expand repair options for customers by providing genuine parts, repair tools, and repair manuals. Since July 2021, we supported self-repair for models sold after this date. The program was launched in the United States in 2022 and in Korea, Europe, Latin America, and other regions in 2023. Repair manuals can be easily downloaded from the Samsung Electronics Service Website. Self-repair parts and tools are available through Samsung Service Centers and the Consumables Shop on the Samsung Electronics Service website in Korea, while overseas customers can purchase them through the Samsung Electronics Service Website.

[Customer self-repair](https://www.samsungsvc.co.kr/info/self-repair)

## Improve Service Quality

## Efforts to Provide Standardized Services

Samsung Electronics creates guidelines for operating service centers and call centers and shares them globally through our Work Standard System to ensure standardized services across all domestic and international locations. Each regional site conducts training using manuals tailored to local market characteristics based on global guidelines.

Additionally, we regularly evaluate service centers to assess the application of service standards, technical capabilities, repair equipment, infrastructure, material management, and financial health. Improvement goals are set for service centers of various sizes, and incentives such as fee adjustments or awards for outstanding centers are provided based on achievement levels.

| SamsungElectronics Service Standard   | SamsungElectronics Service Standard                                                                                                                                         |
|---------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Service Standard                      | Details                                                                                                                                                                     |
| Standard operating manualfor services | · Operations manuals by service process: Contact center, service intake, technical training, troubleshooting, results reporting, Happy Call, billing, claims handling, etc. |
| In-store service guide                | · Guide to adding in-store services features: in-store service definitions, service features, layout, etc.                                                                  |
| Technical guides                      | · Technical guide for product repair                                                                                                                                        |

## Service Training

Samsung Electronics operates training programs for service center managers and repair technicians to ensure consistent quality in repair services. These programs cover topics such as product operation principles, structural understanding, new repair technologies, and customer service skills. Training is conducted through remote video sessions or in-person classes, tailored to the characteristics of each country and product. Technicians can access training videos and technical materials through the company's internal system for self-study. In 2024, the Samsung Business Academy, a system for managing overseas service technical training, offered 5,940 courses, with a total of 42,249 participants completing the training. Additionally, we provide repair authorization training for newly hired technicians and those with repair authorization expiring within three months. As of the end of December 2024, 90% of the 31,825 global repair technicians had successfully obtained their repair authorization.

## Customer Communication

## Customer VOC Response

Samsung Electronics diversifies our Voice of Customer (VOC) acquisition channels, including call centers, websites, emails, and external sites, to collect and address various customer concerns related to product purchase, usage, and repairs. We establish and operate procedures for each VOC channel and use a global VOC integrated management system to collect and share VOCs in real-time across departments for analysis and utilization. This ensures swift and effective resolution of customer issues.

## Customer VOC Response Process

<!-- image -->

## Customer Satisfaction Surveys

Samsung Electronics regularly conducts customer satisfaction surveys through means like email and the Samsung Electronics Service Website for customers who have experienced our services. The survey results are shared with relevant departments, and improvement activities are implemented for areas with low satisfaction or insufficient competitiveness. In 2024, we established a platform for consultation satisfaction surveys, and in 2025, we plan to build a repair satisfaction survey platform to systematically manage consultation and repair satisfaction levels.

<!-- image -->

57

<!-- image -->

We practice responsible management for a sustainable future.

Compliance &amp; Ethics

59

## Compliance &amp; Ethics

## Governance

Samsung Electronics manages our compliance &amp; ethics governance structure via our Board of Directors and affiliated committees (Management Committee, Sustainability Committee, Audit Committee, Related Party Transactions Committee, etc.) to realize responsible corporate management. This governance structure helps foster a corporate culture that adheres to compliance &amp; ethics, supporting our sustainable growth.

The corporate Compliance Team operates various compliance and ethical management programs with the Management Advisory Team. The Compliance Team Head (Chief Compliance Officer) attends all Board and Management Committee meetings to support corporate decision making, and reports major issues to the Board in order to increase corporate decision making transparency.

The Samsung Compliance Committee, launched in February 2020, is a separate, independent external organization with the aim of practicing integrity-based management, a Samsung Key Value. This Committee offers various recommendations and opinions to improve compliance monitoring policies and to strengthen compliance monitoring &amp; control functions over seven major member companies 1) of the Samsung group.

1) Samsung Electronics, Samsung C&amp;T, Samsung SDI, Samsung Electro-Mechanics, Samsung SDS, Samsung Life Insurance, and Samsung Fire &amp; Marine Insurance

<!-- image -->

## Strategy

Samsung Electronics practices a fair and transparent management based on compliance and ethics, pursuing continuous growth as a global corporate citizen receiving the trust and support of our internal and external stakeholders. To achieve this, we regularly inspect and assess compliance and ethics activities and train our employees to enhance our internal ethics awareness. We also work to improve our employee evaluation system and operate a reward system to establish a culture of compliance.

<!-- image -->

## Risk Management

Samsung Electronics establishes and implements our own business principles based on compliance and ethics, as well as the Global Anti-Corruption and Bribery Policy .  We also provide guidelines to employees and suppliers to prevent risks related to compliance and ethical management. We adopt a zero-tolerance policy towards corruption and bribery, and do not intentionally ignore or overlook corrupt practices.

<!-- image -->

Additionally, to realize compliance management across all corporate activities, Samsung Electronics utilizes an IT system called CPMS (Compliance Program Management System). The Compliance Team uses this system to manage risks that may arise in key areas such as anti-corruption, fair trade, intellectual property rights, personal data protection, human rights and labor relations, and environmental safety at the preemptive prevention, monitoring, and post-management stages in collaboration with responsible departments.

<!-- image -->

<!-- image -->

59

## Activities

## Compliance and Ethics Audits

Samsung Electronics conducts compliance and ethics audits at all our business sites. Audit results are reported to the Board of Directors at least once a year, and issues requiring improvement are reflected in our management activities.

| Major Audit Activities in2024   | Major Audit Activities in2024                                                    |                                                  |
|---------------------------------|----------------------------------------------------------------------------------|--------------------------------------------------|
| Period                          | Topic Description                                                                | Areas                                            |
| Q1                              | Compliance of patent application process                                         | Technology misuse, trade secrets                 |
| Q1                              | Compliance of third-party production partners in South Korea and overseas        | Technology leakage, product liability            |
| Q2                              | Compliance of online sales sites                                                 | Consumer protection, dark patterns, greenwashing |
| Q2                              | Compliance of Korean development/ sales organizations and overseas sales offices | Fair trade, trade secrets                        |
| Q3                              | Compliance of global manufacturing sites                                         | Technology misuse, anti- corruption              |
| Q3                              | Compliance of external technology sourcing channels                              | Technology misuse, trade secrets                 |
| Q4                              | Risks related to external sponsorships and internal transactions                 | Anti-corruption, fair trade                      |
| Q4                              | Compliance of subsidiaries                                                       | Trade secrets, privacy                           |

## Training Program

We emphasize the importance of compliance and ethical management to all our employees (including contract and part-time employees). Training for compliance and fraud prevention includes items such as anti-corruption and fair trade. Training is conducted at least once a year. Additionally, training on Korea's Improper Solicitation and Graft Act is provided to contractual administrative function employees to support compliance and ethical adherence from all employees. We also provide training customized for employee job functions and for top management to foster leadership and assist with ethical decision making.

1) Improper Solicitation and Graft Act

<!-- image -->

| Compliance Training   | Fraud Prevention Training   |
|-----------------------|-----------------------------|
| 138,414 individuals   | 254,003 individuals         |

## Compliance and Ethics Whistleblowing Channel

Samsung Electronics receives reports through various whistleblowing systems such as internal/external whistleblowing channels, email, telephone, and fax, operating all systems (except telephone) 24/7. Whistleblowing channels provide information on whistleblower protection, and we operate channels in accordance with the principles of whistleblower identity protection and prohibition of disadvantageous measures 1) .

Received reports are investigated thoroughly to confirm relevant facts and necessary actions are taken in accordance with internal standards. If cases of company process violations are confirmed, disciplinary actions against the perpetrators and responsible persons are taken. In addition, for fraudulent reports that are confirmed to be true, disciplinary action is taken depending on the severity of the case, and results are reported to the Audit Committee twice a year to strengthen our transparency.

Using such systems, Samsung Electronics seeks to further strengthen our internal control and ethics management in pursuit of a fair and honest organizational culture.

1)   Content specified in internal regulations of 'confidentiality of whistleblowers and report content' and 'prevention and suspension of any unfavorable dispositions against whistleblowers and investigation supporters, remedial actions for damage, and sanctions on those who perform disadvantageous measures'

<!-- image -->

| Compliance Whistleblowing 1)   | Ethics Whistleblowing 2)   |
|--------------------------------|----------------------------|
| 1,238 cases                    | 930 cases                  |

1) Based on statistics from our compliance microsite (https://sec-compliance.net)

2) Based on statistics from our ethics microsite (https://sec-audit.com)

## Legal Risks, Compliance Control System Effectiveness Assessment

We categorize major violations of laws and regulations in major compliance topics like fair trade, anti-corruption, intellectual property rights, and environment &amp; safety, analyzing their impacts and grouping risks in need of management. We then prioritize and manage major risks by assessing whether company policies/processes related to said risks and related inspections are properly upheld and conducted. We reflect the results of this risk assessment in compliance programs such as employee training. We also evaluate whether our compliance control system is operated in accordance with applicable regulations. Evaluation results are reported to the Board of Directors for transparent management.

## Corruption Risk Review Process

Samsung Electronics operates a systemic risk review process in order to prevent corruption. Our External Sponsorship Council conducts preliminary reviews of all external sponsorships of KRW 10 million or above and reports review results to the Audit Committee. We manage corruption risks in our sponsorship practices by mandating that external sponsorships of KRW 10 million or above in annual amounts receive the Board of Directors' approval.

In addition, the Compliance Team's approval is required for new vendor registration and contract signing in line with the anti-corruption review process. Such processes block the possibility of corruption from the early stages of a transaction, and contribute to maintaining a fair and transparent business environment.

## Evaluation and Awards

We improve upon our employee evaluation system and operate an awards system in order to foster a corporate culture of compliance. We actively encourage compliant and ethical management activities by increasing the weight of compliance items in the evaluation of executives, and include compliance performances in or organizational evaluations so all employees can partake in compliant management. We also directly award employees and organizations contributing to building a culture of compliance through the SEC Annual Awards.

## Samsung Compliance Committee

The Samsung Compliance Committee holds monthly regular meetings and special meetings on demand to strengthen our corporate compliance and transparent management. In these meetings, the Committee reviews various issues including external sponsorships and internal transactions. The Committee also operates a separate whistleblowing channel to receive reports on violations of compliance obligations. In addition, the Committee conducted various activities including visits to Samsung Electronics' complex in Hanoi, Vietnam, and meetings with member company CEOs.

The Samsung Compliance Committee continuously  provides various recommendations and opinions to improve the compliance monitoring system of Samsung member companies, and we prepared and executed implementation plans in response to these recommendations and opinions.

60

## Facts &amp; Figures

Economic Performance Social Performance Environmental Performance Performance by Division

62 63 68 72

## Economic Performance

| KeyFinancial Performance 1)                 | KeyFinancial Performance 1)                 |   2022 |   2023 |   2024 |
|---------------------------------------------|---------------------------------------------|--------|--------|--------|
| Sales                                       | KRW1trillion                                |  302.2 |  258.9 |  300.9 |
| Operating profit                            | KRW1trillion                                |   43.4 |    6.6 |   32.7 |
| Net income                                  | KRW1trillion                                |   55.7 |   15.5 |   34.5 |
| 1) Basedonconsolidated financial statements | 1) Basedonconsolidated financial statements |        |        |        |
| Sales by Division 1)                        |                                             |   2022 |   2023 |   2024 |
| [Sales by division (absolute value)]        | [Sales by division (absolute value)]        |        |        |        |
| DXDivision                                  | KRW1trillion                                |  182.5 |  170.0 |  174.9 |
| DSDivision                                  | KRW1trillion                                |   98.5 |   66.6 |  111.1 |
| SDC                                         | KRW1trillion                                |   34.4 |   31.0 |   29.2 |
| Harman 2)                                   | KRW1trillion                                |   13.2 |   14.4 |   14.3 |
| [Sales by division (percentage)]            | [Sales by division (percentage)]            |        |        |        |
| DXDivision                                  | %                                           |     56 |     60 |     53 |
| DSDivision                                  | %                                           |     30 |     24 |     34 |
| SDC                                         | %                                           |     10 |     11 |      9 |
| Harman                                      | %                                           |      4 |      5 |      4 |
| 1) Basedonnetsales 2) Acquired in 2016      | 1) Basedonnetsales 2) Acquired in 2016      |        |        |        |
| Sales by Region 1)                          |                                             |   2022 |   2023 |   2024 |
| [Sales by region (absolute value)]          | [Sales by region (absolute value)]          |        |        |        |
| Americas                                    | KRW1trillion                                |  119.0 |   92.1 |  118.8 |
| Europe                                      | KRW1trillion                                |   50.3 |   48.1 |   50.1 |
| Korea                                       | KRW1trillion                                |   48.7 |   45.6 |   39.8 |
| Asia and Africa 2)                          | KRW1trillion                                |   84.3 |   73.1 |   92.1 |
| [Sales by region (percentage)]              | [Sales by region (percentage)]              |        |        |        |
| Americas                                    | %                                           |     39 |     35 |     39 |
| Europe                                      | %                                           |     17 |     19 |     17 |
| Korea                                       | %                                           |     16 |     18 |     13 |
| Asia and Africa                             | %                                           |     28 |     28 |     31 |

| Economic Value Distribution                |                                            |   2022 |   2023 |   2024 |
|--------------------------------------------|--------------------------------------------|--------|--------|--------|
| [Suppliers]                                |                                            |        |        |        |
| Purchasing costs                           | KRW1trillion                               |  219.8 |  212.8 |  226.1 |
| [Local communities]                        |                                            |        |        |        |
| CSRcosts                                   | KRW1trillion                               |    0.4 |    0.4 |    0.3 |
| [Shareholders &Investors]                  |                                            |        |        |        |
| Dividends                                  | KRW1trillion                               |    9.8 |    9.8 |    9.8 |
| Dividend payout ratio                      | %                                          |     18 |     68 |     29 |
| [Creditors]                                |                                            |        |        |        |
| Interest costs                             | KRW1trillion                               |    0.8 |    0.9 |    0.9 |
| [Employees]                                |                                            |        |        |        |
| Personnel expenses                         | KRW1trillion                               |   37.6 |   38.0 |   40.5 |
| [Government]                               |                                            |        |        |        |
| Taxes and public duties by region          | KRW1trillion                               |   13.0 |    8.2 |    8.2 |
| Asia                                       | %                                          |   11.0 |   19.1 |   21.2 |
| Korea                                      | %                                          |   74.0 |   58.1 |   36.6 |
| Americas and Europe                        | %                                          |   14.0 |   21.5 |   40.7 |
| Others                                     | %                                          |    1.0 |    1.3 |    1.5 |
| [Percentage of distributed economic value] | [Percentage of distributed economic value] |        |        |        |
| Suppliers 1)                               | %                                          |   79.3 |   78.8 |   79.1 |
| Local communities 2)                       | %                                          |    0.1 |    0.2 |    0.1 |
| Shareholders and Investors 3)              | %                                          |    3.5 |    3.6 |    3.4 |
| Creditors 4)                               | %                                          |    0.3 |    0.3 |    0.3 |
| Employees 5)                               | %                                          |   13.6 |   14.1 |   14.2 |
| Government 6)                              | %                                          |    3.2 |    3.0 |    2.9 |

<!-- image -->

62

## Social Performance

| Compliance andEthics           |             |    2022 |    2023 |    2024 |
|--------------------------------|-------------|---------|---------|---------|
| [Compliance training]          |             |         |         |         |
| Compliance training 1)         | Individuals | 126,867 | 138,742 | 138,414 |
| [Anti-corruption training]     |             |         |         |         |
| Anti-corruption training 2)    | Individuals | 254,045 | 254,511 | 254,003 |
| [Compliance whistleblowing]    |             |         |         |         |
| Compliance whistleblowing 3)   | Cases       |   1,098 |   1,400 |   1,238 |
| [Corruption whistleblowing]    |             |         |         |         |
| Corruption whistleblowing 4)   | Cases       |     999 |     892 |     930 |
| Corruption whistleblowing rate | %           |      13 |      16 |      13 |
| Consumer complaint rate        | %           |      34 |      36 |      30 |
| Others                         | %           |      54 |      49 |      57 |

2) Scope of data collection for anti-corruption training: Employees at our business sites in Korea and other regions

3) Compliance whistleblowing: Based on statistics from our compliance microsite https://sec-compliance.net

4) Corruption whistleblowing: Based on statistics from our ethics microsite https://sec-audit.com

<!-- image -->

| Corporate Citizenship                 |             |      2022 |      2023 |      2024 |
|---------------------------------------|-------------|-----------|-----------|-----------|
| [Employee volunteer hours]            |             |           |           |           |
| Total employee volunteer hours 1)     | Hours       | 1,068,867 |   652,677 |   730,053 |
| Volunteer hours per employee          | Hours       |      3.95 |      2.44 |      2.78 |
| [Cumulative numberofbeneficiaries] 2) |             |           |           |           |
| SamsungSW‧AI Academyfor Youth         | Individuals |     6,250 |     8,550 |    10,750 |
| SamsungDreamClass                     | Individuals |   116,999 |   124,604 |   128,731 |
| SamsungStepping Stone ofHope          | Individuals |    16,760 |    27,065 |    41,703 |
| SamsungBlue Elephant                  | Individuals |   662,142 |   940,029 | 1,340,198 |
| SamsungSolve for Tomorrow             | Individuals | 2,397,255 | 2,619,592 | 2,889,290 |
| SamsungInnovationCampus               | Individuals |   119,807 |   177,619 |   212,850 |

2)   Korean youth education programs jointly operated by all Samsung member companies; programs not supported in 2024 (Samsung Smart School, Samsung Junior SW Academy) are excluded

| SMESupport                             |           |   2022 | 2023   |   2024 |
|----------------------------------------|-----------|--------|--------|--------|
| Beneficiaries of smart factory support | Companies |    268 | 194    |    181 |
| Partner companies in our supply chains | Companies |     35 | 26     |     17 |
| Non-partner companies                  | Companies |    233 | 168 1) |    164 |

| Privacy Protection                                  | Privacy Protection                                  |   2022 |   2023 |   2024 |
|-----------------------------------------------------|-----------------------------------------------------|--------|--------|--------|
| [In-house consulting]                               |                                                     |        |        |        |
| In-house consulting                                 | Cases                                               |  5,858 |  8,302 |  8,170 |
| [Responses to governmentrequest for information] 1) | [Responses to governmentrequest for information] 1) |        |        |        |
| Requests                                            | Cases                                               |    187 |    594 |    400 |
| Responses                                           | Cases                                               |    126 |    456 |    236 |
| Response rate                                       | %                                                   |     67 |     77 |     59 |

1)   Response to government requests for information: Compiled statistical data with regards to warrants issued by Korean courts in accordance with applicable Korean laws

<!-- image -->

63

| EmployeeStatus                                      |             |    2022 |    2023 |    2024 |
|-----------------------------------------------------|-------------|---------|---------|---------|
| Numberofemployees 1)                                | Individuals | 270,278 | 267,860 | 262,647 |
| Global *                                            | Individuals | 152,351 | 147,104 | 137,350 |
| Korea                                               | Individuals | 117,927 | 120,756 | 125,297 |
| [Numberofemployeesbyemploymenttype] 2)              |             |         |         |         |
| Non-fixed-term employees                            | Individuals | 266,613 | 264,525 | 259,434 |
| Fixed-term employees                                | Individuals |   3,665 |   3,335 |   3,213 |
| [Numberofemployeesbyagegroup]                       |             |         |         |         |
| Under 30                                            | Individuals |  83,155 |  72,525 |  63,531 |
| 30s                                                 | Individuals | 111,607 | 113,874 | 114,035 |
| 40andabove                                          | Individuals |  75,516 |  81,461 |  85,081 |
| [Numberofemployeesbyjobtype]                        |             |         |         |         |
| Development                                         | Individuals |  80,423 |  83,729 |  88,984 |
| Manufacturing                                       | Individuals | 117,190 | 109,722 | 105,571 |
| Quality assuranceandEHS                             | Individuals |  19,763 |  21,386 |  18,731 |
| Sales and marketing                                 | Individuals |  24,703 |  25,136 |  23,466 |
| Others                                              | Individuals |  28,199 |  27,887 |  25,895 |
| [Numberofemployeesbyrank]                           |             |         |         |         |
| Working level 3)                                    | Individuals | 182,323 | 174,060 | 164,895 |
| Manager level                                       | Individuals |  86,498 |  92,315 |  96,294 |
| Executive level 4)                                  | Individuals |   1,457 |   1,485 |   1,458 |
| [Numberofemployeesbyregion]                         |             |         |         |         |
| Korea                                               | Individuals | 117,927 | 120,756 | 125,297 |
| Asia (Southeast Asia, Southwest Asia, China, Japan) | Individuals | 106,790 | 100,938 |  95,501 |
| North America and Latin America                     | Individuals |  27,166 |  27,882 |  25,100 |
| Europe                                              | Individuals |  11,709 |  12,001 |  11,500 |
| CIS (Commonwealth of Independent States)            | Individuals |   1,756 |   1,611 |     788 |
| Middle East and Africa                              | Individuals |   4,930 |   4,672 |   4,461 |
| Numberofnon-SamsungElectronicsemployees 5)          | Individuals |  54,586 |  62,250 |  59,693 |
| Men                                                 | Individuals |  32,883 |  36,734 |  35,581 |
| Women                                               | Individuals |  16,786 |  20,383 |  18,604 |
| Others 6)                                           | Individuals |   4,917 |   5,133 |   5,508 |

<!-- image -->

|                                                      |             |   2022 |   2023 |   2024 |
|------------------------------------------------------|-------------|--------|--------|--------|
| [Numberofnon-SamsungElectronics employees by region] |             |        |        |        |
| Korea                                                | Individuals | 38,492 | 43,902 | 42,589 |
| Asia (Southeast Asia, Southwest Asia, China, Japan)  | Individuals |  5,153 |  7,669 |  6,713 |
| North America and Latin America                      | Individuals |  3,654 |  3,711 |  3,667 |
| Europe                                               | Individuals |  5,847 |  5,479 |  5,115 |
| CIS                                                  | Individuals |    579 |    504 |    515 |
| Middle East and Africa                               | Individuals |    861 |    985 |  1,094 |
| [Welfare benefit expenses in Korea andabroad]        |             |        |        |        |
| Welfare benefit expenses in Korea and abroad         | KRW1billion |  6,092 |  6,473 |  6,778 |

1)   Number of employees: As of year end (excluding those dispatched by partner companies, on leave, interns, and full-time students)

- 2)   Fixed-term employees (Number of employees by employment type): Those hired pursuant to the Act on the Protection of Fixed-Term and PartTime Employees at our business sites in Korea and subcontractors and apprentices at our global business sites 2022, 2023 values updated to reflect updated standards
- 3)   Working level employees (Number of employees by rank): Encompassing those opting for flexible work arrangements and those not categorized under the manager and executive levels
- 4)   Executive level employees (Number of employees by rank): Including those at the vice president level or higher (excluding Masters, Fellows, and advisors) at our Korean business sites and at the vice president level and higher at our global business sites (Including global advisors since 2023)
- 5)   Number of non-Samsung Electronics employees: Including those hired or dispatched by partner companies, interns (including those experiencing work for educational or training purposes) at global sites
- 6) Those who chose not to indicate their gender

* "Global" refers to countries excluding Korea

| PercentageofNewFemaleHiresandRetirementRates   | PercentageofNewFemaleHiresandRetirementRates   |   2022 |   2023 |   2024 |
|------------------------------------------------|------------------------------------------------|--------|--------|--------|
| [Percentage of newfemalehires]                 | [Percentage of newfemalehires]                 |        |        |        |
| Korea                                          | %                                              |   27.9 |   28.1 |   29.5 |
| Global                                         | %                                              |   29.4 |   28.4 |   30.0 |
| [Retirement rate] 1)                           |                                                |        |        |        |
| Total retirement rate                          | %                                              |   12.9 |   10.6 |   10.1 |
| Retirement rateofmen 2)                        | %                                              |    7.0 |    5.9 |    6.3 |
| Retirement rateofwomen 2)                      | %                                              |    5.9 |    4.6 |    3.8 |

1)   Retirement rate: Ratio of those who retired during the respective fiscal year to the total number of employees

2)   Retirement rate of men and women: Based on the number of employees in Korea and abroad who chose to indicate their gender

<!-- image -->

64

| Diversity, Equity, andInclusion                     |             |   2022 |   2023 |   2024 |
|-----------------------------------------------------|-------------|--------|--------|--------|
| [Percentage of female employees]                    |             |        |        |        |
| Percentage of female employees 1)                   | %           |   35.1 |   33.7 |   33.1 |
| [Percentage of female employees by job type]        |             |        |        |        |
| Development                                         | %           |   19.2 |   19.2 |   19.7 |
| Manufacturing                                       | %           |   45.1 |   43.0 |   41.8 |
| Quality assuranceandEHS                             | %           |   40.8 |   38.6 |   38.8 |
| Sales and marketing                                 | %           |   33.6 |   34.0 |   35.2 |
| Others                                              | %           |   35.9 |   36.8 |   37.0 |
| [Percentage of female employees by region]          |             |        |        |        |
| Korea                                               | %           |   25.2 |   25.3 |   25.8 |
| Asia (Southeast Asia, Southwest Asia, China, Japan) | %           |   47.0 |   44.2 |   43.1 |
| North America and Latin America                     | %           |   34.4 |   33.6 |   33.6 |
| Europe                                              | %           |   34.0 |   34.0 |   33.3 |
| CIS                                                 | %           |   40.8 |   41.8 |   36.0 |
| Middle East and Africa                              | %           |   19.1 |   20.4 |   18.9 |
| [Percentage of female employees by rank]            |             |        |        |        |
| Working Level                                       | %           |   43.9 |   42.5 |   41.9 |
| Manager Level                                       | %           |   16.9 |   17.6 |   18.2 |
| Executive Level 2)                                  | %           |    6.9 |    7.3 |    7.4 |
| Numberofemployeesonparentalleave 3)                 | Individuals |  4,364 |  4,477 |  4,892 |
| Men                                                 | Individuals |  1,310 |  1,304 |  1,510 |
| Women                                               | Individuals |  3,054 |  3,173 |  3,382 |
| [Rate of return to workafter parental leave] 4)     |             |        |        |        |
| Men                                                 | %           |   96.5 |   97.7 |   96.6 |
| Women                                               | %           |   98.9 |   99.0 |   99.5 |

<!-- image -->

|                                              | 2022        |   2023 |       |   2024 |
|----------------------------------------------|-------------|--------|-------|--------|
| [In-house daycare centersmaximumcapacity]    |             |        |       |        |
| In-house daycare centers maximumcapacity 5)  | Individuals |  2,628 | 2,642 |  2,937 |
| Numberofin-house daycare centers 6)          | Count       |     11 |    11 |     12 |
| [Numberofemployeeswithdisabilities]          |             |        |       |        |
| Numberofemployees with disabilities 7)       | Individuals |  1,732 | 1,931 |  1,999 |
| [Percentage of employees with disabilities]  |             |        |       |        |
| Percentage of employees with disabilities 8) | %           |    1.6 |   1.8 |    1.9 |

1) Percentage of female employees: Based on the total number of employees

- 2)   Executive level employees: Including those at the vice president level or higher (excluding Masters, Fellows, and advisors) at our Korean business sites and at the vice president level and higher at our global business sites (Including global advisors since 2023)
- 3)   Number of employees on parental leave: Based on the number of employees in Korea (those who used parental leave during the same year since 2024)
- 4) Rate of return to work after parental leave: Based on the number of employees at business sites in Korea
- 5)   In-house daycare centers maximum capacity: Based on our business sites in Korea; limited to Samsung Electronics operated daycare centers excluding Samsung Display operated daycare centers
- 6)   Number of in-house daycare centers: Based on our business sites in Korea; limited to Samsung Electronics operated daycare centers excluding Samsung Display operated daycare centers
- 7)   Number of employees with disabilities: Based on the number of employees in Korea (including those hired by our subsidiary standard workplace for people with disabilities since 2023)
- 8)   Percentage of employees with disabilities: Based on the number of employees in Korea, as reported to the Korea Employement Agency for Persons with Disabilities (including those hired by our subsidiary standard workplace for people with disabilities since 2023)

| Safety andHealth   |       | 2022   | 2023   | 2024   |
|--------------------|-------|--------|--------|--------|
| LTIR 1)            | %     | 0.033  | 0.023  | 0.022  |
| Supplier LTIR 2)   | %     | 0.046  | 0.064  | 0.035  |
| Major incidents    | Count | -      | -      | -      |

1)   LTIR (Lost-Time Injuries Rate): Based on accidents resulting in one or more days of absence and workplace accidents (excluding daily life)

2)   Supplier LTIR (Lost-Time Injuries Rate): Based on accidents resulting in one or more days of absence and workplace accidents (excluding daily life) that occurred at Korean suppliers stationed at our sites

<!-- image -->

65

| CareerDevelopment                                   |               |   2022 |   2023 |   2024 |
|-----------------------------------------------------|---------------|--------|--------|--------|
| Numberoftraining sessions                           | 10,000 cases  |    914 |    950 |    936 |
| Global                                              | 10,000 cases  |    407 |    487 |    522 |
| Korea                                               | 10,000 cases  |    508 |    463 |    414 |
| [Hours of training per employee] 1)                 |               |        |        |        |
| Global                                              | hours         |   52.1 |   58.2 |   66.8 |
| Korea                                               | hours         |   70.5 |   77.5 |   61.2 |
| [Average hours of training by gender]               |               |        |        |        |
| Men                                                 | hours         |   61.1 |   66.0 |   61.6 |
| Women                                               | hours         |   58.3 |   68.6 |   69.0 |
| [Average hours of trainingbyemploymenttype]         |               |        |        |        |
| Regular employees                                   | hours         |   60.5 |   67.3 |   64.5 |
| Non-regular employees 2)                            | hours         |   40.3 |   42.4 |   42.3 |
| [Training expenses]                                 |               |        |        |        |
| Total training expenses 3)                          | KRW100million |  1,853 |  2,090 |  2,404 |
| Training expenses per employee 4)                   | KRW1,000      |  1,571 |  1,731 |  1,919 |
| Ratio of training expenses to sales 5)              | %             |   0.07 |   0.08 |   0.08 |
| Ratio of training expenses to personnel expenses 6) | %             |    0.5 |    0.5 |    0.6 |
| [Re-employmentthroughtheCareer Consulting           | Center]       |        |        |        |
| Re-employment applicants 7)                         | Individuals   |  8,246 |  8,838 |  9,300 |
| Re-employed 8)                                      | Cases         |  7,286 |  7,653 |  8,001 |
| Rate of Re-employment                               | %             |   88.4 |   86.6 |   86.0 |

<!-- image -->

| Sustainable Supply Chain                                                                           |               |   2022 |   2023 |   2024 |
|----------------------------------------------------------------------------------------------------|---------------|--------|--------|--------|
| [Global network]                                                                                   |               |        |        |        |
| Global number of suppliers 1)                                                                      | Companies     |  2,131 |  2,515 |  2,503 |
| [Comprehensive supplier evaluation]                                                                |               |        |        |        |
| Percentage of evaluated suppliers 2)                                                               | %             |     89 |     92 |     92 |
| Percentage of suppliers rated outstanding                                                          | %             |     62 |     71 |     75 |
| Percentage of suppliers with environmentalmanagement system (ISO 14001, etc.) certification 3)     | %             |     90 |     87 |     90 |
| Percentage of suppliers with health and safety managementsystem (ISO 45001, etc.) certification 4) | %             |     50 |     51 |     59 |
| [Global Purchasing CodeofConductcompliance]                                                        |               |        |        |        |
| Korean SMEsuppliers paid 100%within 10 days                                                        | Companies     |    589 |    574 |    579 |
| [Supplier incentives]                                                                              |               |        |        |        |
| Supplier incentives                                                                                | KRW100million |    931 |    650 |    394 |
| Companiesparticipating in supplier training 5)                                                     | Companies     |  1,381 |  1,739 |  1,754 |
| First-tier suppliers                                                                               | Companies     |    865 |  1,114 |  1,061 |
| Sub-suppliers                                                                                      | Companies     |    516 |    625 |    693 |
| Employeesparticipating in supplier training 6)                                                     | Individuals   | 22,924 | 32,566 | 34,235 |
| First-tier suppliers                                                                               | Individuals   | 20,722 | 30,417 | 32,244 |
| Sub-suppliers                                                                                      | Individuals   |  2,202 |  2,149 |  1,991 |
| Innovation Support for First-tier Suppliers 7)                                                     | Companies     |     66 |     91 |    137 |
| Global                                                                                             | Companies     |      5 |      3 |     14 |
| Korea                                                                                              | Companies     |     61 |     88 |    132 |
| Win-WinFundsupport                                                                                 | KRW100million |  9,942 | 10,359 | 10,640 |
| First-tier suppliers                                                                               | KRW100million |  6,997 |  6,953 |  7,315 |
| Sub-suppliers                                                                                      | KRW100million |  2,945 |  3,406 |  3,325 |

<!-- image -->

66

| Transparency in Responsible Minerals SourcingManagement                          | Transparency in Responsible Minerals SourcingManagement                          | Transparency in Responsible Minerals SourcingManagement                          | 2022                                                                             | 2022                                                                             | 2023                                                                             | 2023                                                                             | 2024                                                                             |
|----------------------------------------------------------------------------------|----------------------------------------------------------------------------------|----------------------------------------------------------------------------------|----------------------------------------------------------------------------------|----------------------------------------------------------------------------------|----------------------------------------------------------------------------------|----------------------------------------------------------------------------------|----------------------------------------------------------------------------------|
| On-site audits of suppliers 1)                                                   | Companies                                                                        | Companies                                                                        | 438                                                                              | 438                                                                              | 315                                                                              | 315                                                                              | 202                                                                              |
| 1) On-site audits of suppliers aimed at eradicating the use of conflict minerals | 1) On-site audits of suppliers aimed at eradicating the use of conflict minerals | 1) On-site audits of suppliers aimed at eradicating the use of conflict minerals | 1) On-site audits of suppliers aimed at eradicating the use of conflict minerals | 1) On-site audits of suppliers aimed at eradicating the use of conflict minerals | 1) On-site audits of suppliers aimed at eradicating the use of conflict minerals | 1) On-site audits of suppliers aimed at eradicating the use of conflict minerals | 1) On-site audits of suppliers aimed at eradicating the use of conflict minerals |
| SupplyChainWorkEnvironmentManagement                                             | SupplyChainWorkEnvironmentManagement                                             | SupplyChainWorkEnvironmentManagement                                             | 2022                                                                             | 2022                                                                             | 2023                                                                             | 2023                                                                             | 2024                                                                             |
| First-tier suppliers                                                             | Companies                                                                        | Companies                                                                        | 121                                                                              | 121                                                                              | 93                                                                               | 93                                                                               | 90                                                                               |
| SupplierThird-PartyAuditComplianceRatebyArea 1)                                  | SupplierThird-PartyAuditComplianceRatebyArea 1)                                  | 2022                                                                             | 2023                                                                             | 2023                                                                             |                                                                                  |                                                                                  | 2024                                                                             |
|                                                                                  |                                                                                  |                                                                                  | First-tier                                                                       | Second-tier                                                                      |                                                                                  | First-tier                                                                       | Second-tier                                                                      |
| [Labor andhumanrights]                                                           |                                                                                  |                                                                                  |                                                                                  |                                                                                  |                                                                                  |                                                                                  |                                                                                  |
| Freely chosen employment 2)                                                      | %                                                                                | 98                                                                               | 99                                                                               | 100                                                                              |                                                                                  | 98                                                                               | 96                                                                               |
| Guarantee of freedomofmovement                                                   | %                                                                                | 100                                                                              | 99                                                                               |                                                                                  | 100                                                                              | 98                                                                               | 100                                                                              |
| Prohibition of child labor                                                       | %                                                                                | 100                                                                              | 100                                                                              | 100                                                                              |                                                                                  | 100                                                                              | 100                                                                              |
| Protection of underage workers                                                   | %                                                                                | 100                                                                              | 99                                                                               | 100                                                                              |                                                                                  | 100                                                                              | 97                                                                               |
| Working hours                                                                    | %                                                                                | 93                                                                               | 85                                                                               | 78                                                                               |                                                                                  | 93                                                                               | 93                                                                               |
| Guarantee of at leastonedayoffperweek                                            | %                                                                                | 97                                                                               | 96                                                                               | 95                                                                               |                                                                                  | 98                                                                               | 97                                                                               |
| Wagesandbenefits 3)                                                              | %                                                                                | 96                                                                               | 95                                                                               | 92                                                                               |                                                                                  | 93                                                                               | 86                                                                               |
| Humanetreatment                                                                  | %                                                                                | 100                                                                              | 99                                                                               | 100                                                                              |                                                                                  | 99                                                                               | 99                                                                               |
| Non-discrimination 4)                                                            | %                                                                                | 100                                                                              | 100                                                                              | 100                                                                              |                                                                                  | 100                                                                              | 92                                                                               |
| Freedom of association 5)                                                        | %                                                                                | 98                                                                               | 99                                                                               | 100                                                                              |                                                                                  | 99                                                                               | 99                                                                               |
| [Safety andHealth]                                                               |                                                                                  |                                                                                  |                                                                                  |                                                                                  |                                                                                  |                                                                                  |                                                                                  |
| Occupational safety                                                              | %                                                                                | 95                                                                               | 96                                                                               | 100                                                                              |                                                                                  | 98                                                                               | 92                                                                               |
| Emergency preparedness                                                           | %                                                                                | 94                                                                               | 98                                                                               | 96                                                                               |                                                                                  | 95                                                                               | 87                                                                               |
| Occupational injury and illness                                                  | %                                                                                | 98                                                                               | 99                                                                               | 100                                                                              |                                                                                  | 99                                                                               | 100                                                                              |
| Physically demanding work                                                        | %                                                                                | 97                                                                               | 99                                                                               | 100                                                                              |                                                                                  | 99                                                                               | 94                                                                               |
| Machine safeguarding                                                             | %                                                                                | 98                                                                               | 96                                                                               | 100                                                                              |                                                                                  | 99                                                                               | 98                                                                               |
| Sanitation, food, and housing                                                    | %                                                                                | 99                                                                               | 99                                                                               | 100                                                                              |                                                                                  | 98                                                                               | 94                                                                               |

| SupplierThird-PartyAuditComplianceRatebyArea 1)   | SupplierThird-PartyAuditComplianceRatebyArea 1)   |   2022 |            | 2023        | 2024       | 2024        |
|---------------------------------------------------|---------------------------------------------------|--------|------------|-------------|------------|-------------|
|                                                   |                                                   |        | First-tier | Second-tier | First-tier | Second-tier |
| [Environment]                                     |                                                   |        |            |             |            |             |
| Pollution prevention                              | %                                                 |     99 | 98         | 100         | 99         | 88          |
| Hazardous substances                              | %                                                 |     96 | 98         | 100         | 97         | 98          |
| Wastewater and solid waste                        | %                                                 |     98 | 99         | 100         | 98         | 95          |
| Air emissions                                     | %                                                 |     99 | 99         | 94          | 99         | 98          |
| Materials restrictions                            | %                                                 |    100 | 100        | 100         | 100        | 100         |
| [Ethics]                                          |                                                   |        |            |             |            |             |
| Corporate ethics                                  | %                                                 |    100 | 98         | 100         | 98         | 97          |
| Prohibition of ill-gotten gains                   | %                                                 |    100 | 100        | 100         | 99         | 91          |
| Information disclosure                            | %                                                 |    100 | 100        | 100         | 100        | 100         |
| Intellectual property                             | %                                                 |     99 | 100        | 100         | 100        | 85          |
| Confidentiality and prohibition of retaliation    | %                                                 |    100 | 100        | 100         | 99         | 97          |
| Privacy protection                                | %                                                 |    100 | 100        | 100         | 100        | 100         |
| [ManagementSystem]                                |                                                   |        |            |             |            |             |
| Will of compliance                                | %                                                 |     98 | 100        | 100         | 98         | 94          |
| Managementresponsibility                          | %                                                 |     95 | 99         | 100         | 97         | 74          |
| Risk assessment                                   | %                                                 |     92 | 100        | 100         | 97         | 64          |
| Training                                          | %                                                 |     98 | 99         | 100         | 94         | 76          |
| Communication                                     | %                                                 |     97 | 100        | 100         | 98         | 77          |
| Employee feedback                                 | %                                                 |    100 | 99         | 100         | 99         | 95          |
| Remedial action                                   | %                                                 |     95 | 97         | 92          | 92         | 77          |
| Managementofbusiness improvement targets          | %                                                 |     93 | 97         | 100         | 94         | 79          |

<!-- image -->

67

## Environmental Performance

| GHGEmissionManagement(Scope1and2) 1), 2)   | GHGEmissionManagement(Scope1and2) 1), 2)   | 2022   | 2023   |   2024 |
|--------------------------------------------|--------------------------------------------|--------|--------|--------|
| (Market based) GHGemissions                | 1,000 tonnes CO₂e                          | 15,053 | 13,291 | 14,889 |
| Direct emissions (Scope 1)                 | 1,000 tonnes CO₂e                          | 5,972  | 3,733  |  4,725 |
| Indirect emissions (Scope 2)               | 1,000 tonnes CO₂e                          | 9,081  | 9,558  | 10,164 |
| (Regionbased)GHGemissions                  | 1,000tonnesCO₂e                            | 19,892 | 18,303 | 19,736 |
| Direct emissions (Scope 1)                 | 1,000 tonnes CO₂e                          | 5,972  | 3,733  |  4,725 |
| Indirect emissions (Scope 2)               | 1,000 tonnes CO₂e                          | 13,920 | 14,570 | 15,011 |
| GHGemissions intensity 3), 4)              | Tonne CO₂e/ KRW100million                  | 5      | 6      |      5 |
| GHGemissionsbysource 4)                    | 1,000tonnesCO₂e                            | 15,053 | 13,291 | 14,889 |
| CO₂                                        | 1,000 tonnes CO₂e                          | 10,336 | 10,778 | 11,415 |
| CH₄                                        | 1,000 tonnes CO₂e                          | 3      | 3      |      4 |
| N₂O                                        | 1,000 tonnes CO₂e                          | 530    | 540    |    265 |
| HFCs                                       | 1,000 tonnes CO₂e                          | 679    | 314    |    564 |
| PFCs                                       | 1,000 tonnes CO₂e                          | 3,333  | 1,533  |    913 |
| SF₆                                        | 1,000 tonnes CO₂e                          | 173    | 124    |    484 |
| NF₃ 1)                                     | 1,000 tonnes CO₂e                          | -      | -      |  1,245 |

1)   Calculations conducted for Korean and overseas manufacturing subsidiaries. Starting in 2024, emissions from refrigerants, wastewater, newly designated gas, and leakage included in calculations. NF3 (one of seven greenhouse gases according to international standards) emissions newly disclosed in the 2025 Sustainability Report. 2024 (market based) GHG emissions calculated with 2023 standards decreased by 242 thousand tonnes CO₂e to 13,049 thousand tonnes CO₂e.

2) 2024 GHG emissions: Calculated based on country-specific electric and fuel emission coefficients, the IPCC Guideline, and ISO 14064

3)   GHG emissions intensity: GHG emissions from business sites (Scope 1 and 2) / Sales (sales of DX division (absolute value) + sales of DS division (absolute value), KRW 100 million)

4) Market-based GHG emission

## Scope 3 Calculation Methodology by Category

| Category                                                           | Calculation Methodology                                                                                                                                                                     |
|--------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1. Purchased products andservices                                  | Hybrid methodusingsupplier-specific andspend-based data; - supplier-specific methodapplied to over 90%oftotal spend.                                                                        |
| 2. Capital goods                                                   | Supplier-specific data applied for semiconductor equipment; other capital goods estimated using spend-based method.                                                                         |
| 3. Fuel- andenergy-related activities not included in Scope 1 or 2 | Calculated based onenergy consumption at global manufacturing sites; applied country- andfuel- specific emission factors.                                                                   |
| 4. Upstreamtransportationand distribution                          | Hybrid methodapplied depending ontransportsegment - Korean domestic transport (supplier-specific), international transport (distance-specific), non-Korean inland transport (cost-specific) |
| 5. Wastegenerated in operations                                    | Waste-type-specificmethod                                                                                                                                                                   |
| 6. Business travel                                                 | Distance-based calculation by travelmode                                                                                                                                                    |
| 7.Employeecommuting                                                | Distance-based calculationbycommutingmode                                                                                                                                                   |

<!-- image -->

| GHGEmissionManagement(Scope3) 1),2)                                    | GHGEmissionManagement(Scope3) 1),2)   |    2022 |    2023 |    2024 |
|------------------------------------------------------------------------|---------------------------------------|---------|---------|---------|
| Other indirect emissions (Scope 3)                                     | 1,000tonnesCO₂e                       | 115,960 | 106,971 | 105,612 |
| Purchased products and services                                        | 1,000 tonnes CO₂e                     |  13,540 |  11,514 |  10,827 |
| Capital goods                                                          | 1,000 tonnes CO₂e                     |   2,155 |   3,059 |   2,249 |
| Fuel- and energy-related activities not included in Scope 1 or Scope 2 | 1,000 tonnes CO₂e                     |   2,538 |   2,962 |   2,786 |
| Upstream transportation and distribution                               | 1,000 tonnes CO₂e                     |   5,332 |   4,085 |   4,084 |
| Waste Generated in Operations                                          | 1,000 tonnes CO₂e                     |     173 |     164 |     153 |
| Business travel                                                        | 1,000 tonnes CO₂e                     |      89 |     108 |     153 |
| Employee commuting                                                     | 1,000 tonnes CO₂e                     |     322 |     298 |     293 |
| Upstream leased assets                                                 | 1,000 tonnes CO₂e                     |      67 |      15 |      12 |
| Downstream transportation and distribution                             | 1,000 tonnes CO₂e                     |      46 |      41 |      80 |
| Processing of sold products                                            | 1,000 tonnes CO₂e                     |     161 |      98 |     321 |
| Use of sold products                                                   | 1,000 tonnes CO₂e                     |  90,171 |  83,116 |  82,714 |
| End of life treatment of sold products                                 | 1,000 tonnes CO₂e                     |   1,206 |   1,339 |   1,721 |
| Downstream leased assets                                               | 1,000 tonnes CO₂e                     |       1 |       3 |       1 |
| Investments                                                            | 1,000 tonnes CO₂e                     |     159 |     169 |     218 |

2)   For some Scope 3 categories (e.g. use of sold products), the calculation methods/standards (e.g. calculation automation, application of latest emission factors) and data consistency have been improved. Previously reported 2022/2023 data has been revised and disclosed accordingly.

| Category                                    | Calculation Methodology                                                                                                                                                                                                    |
|---------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 8. Upstreamleased assets                    | Spend-based methodapplied for small-scale/short-term lease contracts                                                                                                                                                       |
| 9. Downstreamtransportationand distribution | Distance-basedmethod                                                                                                                                                                                                       |
| 10. Processing of sold products             | Estimated based onaverage electricity consumption during downstreamprocessing of sold product                                                                                                                              |
| 11. Useof sold products                     | Calculated lifetime use-phase emissions using labeled energy consumptionfor eachproductsold globally.                                                                                                                      |
| 12. Endoflife treatment of sold products    | Estimated based onmaterial composition of sold products andwastetreatment-specific emission factors.                                                                                                                       |
| 13. Downstreamleasedassets                  | Estimated using average electricity consumption by downstreamleased asset type                                                                                                                                             |
| 14. Franchises                              | Nofranchise operations                                                                                                                                                                                                     |
| 15. Investments                             | Hybrid methodapplied depending onequity share - Investee with equal to or greater than 20%ownership: supplier-specificmethod - Investee with less than 20%ownership: combination of supplier-specificandspend-basedmethods |

<!-- image -->

68

| EnergyManagement                 |                    |   2022 |   2023 |   2024 |
|----------------------------------|--------------------|--------|--------|--------|
| Energyconsumptionatbusinesssites | GWh                | 35,177 | 36,399 | 38,772 |
| Electricity                      | GWh                | 28,316 | 29,956 | 32,083 |
| Korea                            | GWh                | 21,360 | 23,217 | 25,111 |
| China                            | GWh                |  3,409 |  3,304 |  3,451 |
| India                            | GWh                |    148 |    161 |    171 |
| Southeast Asia                   | GWh                |  1,581 |  1,522 |  1,663 |
| Americas                         | GWh                |  1,635 |  1,579 |  1,514 |
| Europe                           | GWh                |    135 |    126 |    121 |
| Africa and Middle East           | GWh                |     48 |     47 |     53 |
| Others 1)                        | GWh                |  6,861 |  6,443 |  6,688 |
| Energy intensity 2)              | MWh/ KRW100million |   12.5 |   15.4 |   13.5 |
| Renewable energy consumption     | GWh                |  8,704 |  9,289 | 10,069 |
| Renewable energy transition rate | %                  |   30.7 |   31.0 |   31.4 |

| Product Energy EfficiencyImprovement 1)   | Product Energy EfficiencyImprovement 1)   |   2022 |   2023 |   2024 |
|-------------------------------------------|-------------------------------------------|--------|--------|--------|
| Product energy consumption reduction rate | %                                         |   16.4 |   25.1 |   31.5 |

| Resource Efficiency of Products         |        |    2022 |    2023 |    2024 |
|-----------------------------------------|--------|---------|---------|---------|
| [Recycled plastic]                      |        |         |         |         |
| Cumulative use 1)                       | Tonnes | 409,117 | 567,056 | 768,811 |
| Amountusedbyyear                        | Tonnes |  98,826 | 157,939 | 201,755 |
| Percentage of recycled plastics used 2) | %      |    13.9 |    25.0 |    31.0 |
| [Recycled packaging]                    |        |         |         |         |
| Recycled packaging 3)                   | Tonnes |  13,011 |  15,273 |  16,399 |

3) Recycled packaging: based on data collected in Korea

| Amountofe-WasteCollectedandRecycled                 |        |      2022 |      2023 |      2024 |
|-----------------------------------------------------|--------|-----------|-----------|-----------|
| Cumulative amount of e-waste collected 1)           | Tonnes | 5,698,008 | 6,297,161 | 6,908,516 |
| Amountofe-wastecollected                            | Tonnes |   598,572 |   599,153 |   611,354 |
| Asia and Oceania                                    | Tonnes |   220,357 |   235,197 |   250,057 |
| Americas                                            | Tonnes |    45,842 |    54,014 |    59,405 |
| Europe                                              | Tonnes |   332,374 |   309,942 |   301,893 |
| Amountofe-wastecollected by year andproduct type 2) | Tonnes |   132,681 |   140,162 |   141,582 |
| Heat exchanger                                      | Tonnes |    75,879 |    89,754 |    75,085 |
| Display                                             | Tonnes |    10,644 |    12,840 |    11,282 |
| Telecommunications service equipment                | Tonnes |     1,930 |     2,155 |     2,178 |
| Other electric and electronics equipment            | Tonnes |    44,228 |    35,414 |    53,037 |
| Amountofmaterials recovered for recycling 3)        | Tonnes |   111,406 |   117,025 |   118,150 |
| Scrap metals                                        | Tonnes |    57,763 |    61,422 |    61,677 |
| Nonferrous metals                                   | Tonnes |    11,996 |    12,356 |    13,281 |
| Synthetic resin                                     | Tonnes |    33,157 |    35,752 |    35,909 |
| Glass                                               | Tonnes |     4,068 |     3,183 |     3,311 |
| Others                                              | Tonnes |     4,422 |     4,312 |     3,972 |

1) Cumulative amount of e-waste collected from 2009

2)   Amount of e-waste collected by year and product type: Based on data collected in Korea

3) Amount of materials recovered for recycling: Based on data collected in Korea

69

| WasteManagement                        |        |      2022 |      2023 |      2024 |
|----------------------------------------|--------|-----------|-----------|-----------|
| Amountofwastegenerated                 | Tonnes | 1,413,365 | 1,314,923 | 1,348,979 |
| General waste                          | Tonnes |   931,929 |   881,175 |   910,510 |
| Hazardous waste 1)                     | Tonnes |   481,436 |   433,748 |   438,469 |
| Amountofwastetreated                   | Tonnes | 1,413,365 | 1,314,923 | 1,348,979 |
| Recovered for recycling                | Tonnes | 1,364,367 | 1,276,662 | 1,318,188 |
| Incineration (off-site)                | Tonnes |    25,479 |    31,007 |    26,331 |
| Landfill (off-site)                    | Tonnes |    14,927 |     4,622 |     1,695 |
| Others                                 | Tonnes |     8,593 |     2,632 |     2,766 |
| Percentageofwasterecoveredforrecycling | %      |        97 |        97 |        98 |

| WaterManagement                 |              |    2022 |    2023 |    2024 |
|---------------------------------|--------------|---------|---------|---------|
| Water Intake                    | 1,000 tonnes | 172,811 | 177,361 | 188,540 |
| Municipal water (surface water) | 1,000 tonnes | 172,112 | 176,575 | 187,639 |
| Groundwater                     | 1,000 tonnes |     698 |     786 |     902 |
| Wastewater discharge            | 1,000 tonnes | 136,118 | 142,995 | 152,109 |
| Water reused                    | 1,000 tonnes | 116,590 | 122,891 | 125,463 |
| [Ultra-pure water reused]       |              |         |         |         |
| Supply                          | 1,000 tonnes |  70,989 |  71,487 |  74,784 |
| Recovery                        | 1,000 tonnes |  24,731 |  22,004 |  23,025 |
| Suppliers' water consumption 1) | 1,000 tonnes |  94,814 |  97,482 |  88,467 |

| ChemicalSubstanceManagement 1)      | 2022             | 2023   | 2024   |
|-------------------------------------|------------------|--------|--------|
| Chemical consumption 2)             | 1,000 tonnes 578 | 518    | 551    |
| Major hazardous substances leakages | Cases -          | -      | -      |

| WorkplaceEnvironmentManagement                                     | WorkplaceEnvironmentManagement                                     | 2022   |   2023 |   2024 |
|--------------------------------------------------------------------|--------------------------------------------------------------------|--------|--------|--------|
| Investment inEHS                                                   | KRW100million                                                      | 21,836 | 20,284 | 23,488 |
| Violations of environment-related laws and regulations 1)          | Cases                                                              | 2      |      1 |      2 |
| 1) For details please refer to pg. 74 of the Sustainability Report | 1) For details please refer to pg. 74 of the Sustainability Report |        |        |        |
| PollutantManagement                                                | PollutantManagement                                                | 2022   |   2023 |   2024 |
| [Air pollutant emissions]                                          |                                                                    |        |        |        |
| NOx                                                                | Tonnes                                                             | 785    |    720 |    729 |
| SOx                                                                | Tonnes                                                             | 35     |     43 |     35 |
| NH₃                                                                | Tonnes                                                             | 95     |    125 |    104 |
| HF                                                                 | Tonnes                                                             | 19     |     16 |     14 |
| PM 1)                                                              | Tonnes                                                             | 207    |    142 |     90 |
| Volatile organic compoundemissions                                 | Tonnes                                                             | 394    |    398 |    492 |
| [Water pollutant discharge]                                        |                                                                    |        |        |        |
| TOC(Korea) 2)                                                      | Tonnes                                                             | -      |    294 |    319 |
| COD(Global)                                                        | Tonnes                                                             | 846    |    534 |    649 |
| BOD                                                                | Tonnes                                                             | 313    |    412 |    427 |
| SS                                                                 | Tonnes                                                             | 411    |    931 |    816 |
| F                                                                  | Tonnes                                                             | 576    |    626 |    488 |
| Heavy metals                                                       | Tonnes                                                             | 16     |     17 |     11 |
| Consumption of ozone depleting substances (CFC-eq) 3)              | Tonnes                                                             | 2      |      1 |    0.3 |

1) Previous dust emission disclosure standard changed

2) Applied data separately into TOC (Korea) and COD (Global) starting from 2023

3) Scope of data collection: Korea

## [Available Water Resources by Region]

|                   |              |   Water intake |   Water intake | Water intake               | Water intake               | Water intake               | Water intake                                                              | Water intake                                                              | Water intake                                                              | Water intake                                                              | Water intake                                                              | Water discharge   |   Water discharge | Water discharge                             | Water discharge                             | Water discharge   | Water discharge   | Water discharge                             |                                             |                                             |                                      |
|-------------------|--------------|----------------|----------------|----------------------------|----------------------------|----------------------------|---------------------------------------------------------------------------|---------------------------------------------------------------------------|---------------------------------------------------------------------------|---------------------------------------------------------------------------|---------------------------------------------------------------------------|-------------------|-------------------|---------------------------------------------|---------------------------------------------|-------------------|-------------------|---------------------------------------------|---------------------------------------------|---------------------------------------------|--------------------------------------|
|                   |              |                |                | Total Intake Water sources | Total Intake Water sources | Total Intake Water sources | Intake from third-party (local governments, water utility companies, etc) | Intake from third-party (local governments, water utility companies, etc) | Intake from third-party (local governments, water utility companies, etc) | Intake from third-party (local governments, water utility companies, etc) | Intake from third-party (local governments, water utility companies, etc) | Total discharge   |                   | Direct discharge into freshwater ecosystems | Direct discharge into freshwater ecosystems | discharge by      | discharge by      | Treatmentand third-party Amountofwater used | Treatmentand third-party Amountofwater used | Treatmentand third-party Amountofwater used |                                      |
| Region            |              |                |                | Surface                    | Surface                    | Water Groundwater          | Water Groundwater                                                         | Surface                                                                   | Surface                                                                   | Water Groundwater 1)                                                      | Water Groundwater 1)                                                      |                   |                   |                                             |                                             | agencies          | agencies          |                                             |                                             |                                             | Basins                               |
|                   |              |           2023 |           2024 | 2023                       | 2024                       | 2023                       | 2024                                                                      | 2023                                                                      | 2024                                                                      | 2023                                                                      | 2024                                                                      | 2023              |              2024 | 2023                                        | 2024                                        | 2023              | 2024              | 2023                                        | 2024                                        | 2023                                        | 2024                                 |
| Korea             | 1,000 tonnes |        139,527 |        148,251 | 139,210                    | 147,855                    | -                          | -                                                                         | -                                                                         | -                                                                         | 317                                                                       | 396                                                                       | 113,198           |           119,996 | 60,225                                      | 59,116                                      | 52,973            | 60,880            | 26,318                                      | 28,255                                      | 94,231                                      | 101,690 4 including the HanRiver     |
| China             | 1,000 tonnes |         16,386 |         17,498 | 16,386                     | 17,498                     | -                          | -                                                                         | -                                                                         | -                                                                         | -                                                                         | -                                                                         | 13,309            |            13,756 | -                                           | -                                           | 13,309            | 13,756            | 3,076                                       | 3,742                                       | 21,537                                      | 16,459 3 including theHuangHe        |
| Europe            | 1,000 tonnes |            256 |            239 | 243                        | 219                        | -                          | -                                                                         | -                                                                         | -                                                                         | 13                                                                        | 19                                                                        | 171               |               174 | -                                           | -                                           | 171               | 174               | 85                                          | 65                                          | -                                           | River - 3 including the Danube River |
| Russia            | 1,000 tonnes |             19 |             21 | 17                         | 18                         | -                          | -                                                                         | -                                                                         | -                                                                         | 2                                                                         | 4                                                                         | 17                |                21 | -                                           | -                                           | 17                | 21                | 2                                           | -                                           | 18                                          | 12 Volga River                       |
| Southeast Asia    | 1,000 tonnes |         10,470 |         12,225 | 10,470                     | 12,225                     | -                          | -                                                                         | -                                                                         | -                                                                         | -                                                                         | -                                                                         | 8,448             |            10,273 | 230                                         | 236                                         | 8,218             | 10,037            | 2,022                                       | 1,951                                       | 2,763                                       | 1,912 4 including theHong River      |
| Southwest Asia    | 1,000 tonnes |            489 |            496 | 384                        | 393                        | -                          | -                                                                         | -                                                                         | -                                                                         | 106                                                                       | 103                                                                       | 178               |               240 | -                                           | -                                           | 178               | 240               | 311                                         | 256                                         | 243                                         | 245 2 including the Ganges River     |
| North America     | 1,000 tonnes |          9,675 |          9,168 | 9,675                      | 9,168                      | -                          | -                                                                         | -                                                                         | -                                                                         | -                                                                         | -                                                                         | 7,364             |             7,184 | -                                           | -                                           | 7,364             | 7,184             | 2,312                                       | 1,984                                       | 4,093                                       | 5,139 4 including the Colorado River |
| Central and South | 1,000 tonnes |            360 |            396 | 11                         | 16                         | -                          | -                                                                         | -                                                                         | -                                                                         | 349                                                                       | 380                                                                       | 158               |               248 | 140                                         | 217                                         | 18                | 31                | 202                                         | 148                                         | 7                                           | 7 2 including theAmazon              |
| America Africa    | 1,000 tonnes |            179 |            248 | 179                        | 248                        | -                          | -                                                                         | -                                                                         | -                                                                         | -                                                                         | -                                                                         | 152               |               217 | -                                           | -                                           | 152               | 217               | 27                                          | 31                                          | -                                           | River - 2 including the Nile River   |
| Total             | 1,000 tonnes |        177,361 |        188,540 | 176,575                    | 187,639                    | -                          | -                                                                         | -                                                                         | -                                                                         | 786                                                                       | 902                                                                       | 142,995           |           152,109 | 60,595                                      | 59,569                                      | 82,400            | 92,540            | 34,356                                      | 36,431                                      | 122,891                                     | 125,463                              |

## Performance by Division

|                                          |                                          | 2022        | 2022        | 2023        | 2023        | 2024        | 2024        |
|------------------------------------------|------------------------------------------|-------------|-------------|-------------|-------------|-------------|-------------|
| GHGEmissionManagement(Scope1and2) 1), 2) | GHGEmissionManagement(Scope1and2) 1), 2) | DX Division | DS Division | DX Division | DS Division | DX Division | DS Division |
| (Marketbased)GHGemissions                | 1,000tonnesCO₂e                          | 366         | 14,687      | 313         | 12,978      | 342         | 14,546      |
| Direct emissions (Scope 1)               | 1,000 tonnes CO₂e                        | 254         | 5,718       | 211         | 3,522       | 236         | 4,489       |
| Indirect emissions (Scope 2)             | 1,000 tonnes CO₂e                        | 112         | 8,969       | 102         | 9,456       | 106         | 10,058      |
| GHGemissionbysource 3)                   | 1,000tonnesCO₂e                          | 366         | 14,687      | 313         | 12,978      | 342         | 14,546      |
| CO₂                                      | 1,000 tonnes CO₂e                        | 364         | 9,971       | 311         | 10,467      | 314         | 11,101      |
| CH₄                                      | 1,000 tonnes CO₂e                        | 1           | 2           | 0.5         | 2           | 1           | 3           |
| N₂O                                      | 1,000 tonnes CO₂e                        | 1           | 529         | 1           | 539         | 1           | 264         |
| HFCs                                     | 1,000 tonnes CO₂e                        | -           | 679         | -           | 314         | 26          | 538         |
| PFCs                                     | 1,000 tonnes CO₂e                        | -           | 3,333       | 0.2         | 1,532       | 0.3         | 912         |
| SF₆                                      | 1,000 tonnes CO₂e                        | -           | 173         | -           | 124         | -           | 484         |
| NF₃                                      | 1,000 tonnes CO₂e                        | -           | -           | -           | -           | -           | 1,245       |

1)   Calculations conducted for Korean and overseas manufacturing subsidiaries. Starting in 2024, emissions from refrigerants, wastewater, newly designated gas, and leakage included in calculations. NF3 (one of seven greenhouse gases according to international standards) emissions newly disclosed in the 2025 Sustainability Report.

2) 2024 GHG emissions: Calculated based on country specific GHG management guidelines, the IPCC Guidelines, and ISO 14064 3) Market-based GHG emission

|                                                               |                                        | 2022        | 2022        | 2023        | 2023        | 2024        | 2024        |
|---------------------------------------------------------------|----------------------------------------|-------------|-------------|-------------|-------------|-------------|-------------|
| GHGEmission Management(Scope 3) 1), 2)                        | GHGEmission Management(Scope 3) 1), 2) | DX Division | DS Division | DX Division | DS Division | DX Division | DS Division |
| Otherindirectemissions(Scope3)                                | 1,000tonnesCO₂e                        | 100,051     | 15,910      | 90,360      | 16,611      | 82,713      | 22,900      |
| Purchasedproductsandservices                                  | 1,000 tonnes CO₂e                      | 10,074      | 3,466       | 8,017       | 3,497       | 7,122       | 3,705       |
| Capital goods                                                 | 1,000 tonnes CO₂e                      | 424         | 1,731       | 396         | 2,663       | 304         | 1,945       |
| Fuel- andenergy-relatedactivities notincludedinScope1orScope2 | 1,000 tonnes CO₂e                      | 387         | 2,151       | 395         | 2,567       | 389         | 2,398       |
| Upstream transportation and distribution                      | 1,000 tonnes CO₂e                      | 5,094       | 238         | 3,912       | 173         | 3,901       | 183         |
| Waste generated in operations                                 | 1,000 tonnes CO₂e                      | 27          | 146         | 42          | 122         | 35          | 118         |
| Business travel                                               | 1,000 tonnes CO₂e                      | 70          | 19          | 79          | 29          | 112         | 41          |
| Employee commuting                                            | 1,000 tonnes CO₂e                      | 231         | 91          | 216         | 82          | 208         | 85          |
| Upstream leased assets                                        | 1,000 tonnes CO₂e                      | 13          | 53          | 12          | 3           | 9           | 3           |
| Downstream transportation and distribution                    | 1,000 tonnes CO₂e                      | 37          | 9           | 35          | 6           | 72          | 7           |
| Processing of sold products                                   | 1,000 tonnes CO₂e                      | -           | 161         | -           | 98          | 154         | 167         |
| Use of sold products                                          | 1,000 tonnes CO₂e                      | 82,360      | 7,812       | 75,760      | 7,356       | 68,496      | 14,218      |
| End of life treatment of sold products                        | 1,000 tonnes CO₂e                      | 1,200       | 6           | 1,338       | 1           | 1,719       | 2           |
| Downstream leased assets                                      | 1,000 tonnes CO₂e                      | 1           | 1           | 2           | 1           | 1           | 1           |
| Investments                                                   | 1,000 tonnes CO₂e                      | 133         | 26          | 156         | 13          | 191         | 27          |

1)   Internal calculation standard of 14 categories has been set in 2022 and all the categories have been assured by an independent 3rd party. Data used for calculating some Scope 3 emissions (purchased goods and services, capital goods) are calculated based on previous year's data when suppliers' emissions data was available.

2)   For some Scope 3 categories (e.g. use of sold products), the calculation methods/standards (e.g. calculation automation, application of latest emission factors) and data consistency have been improved. Previously reported '22/23 data has been revised and disclosed accordingly.

72

|                                      |     | 2022        | 2022        | 2023        | 2023        | 2024        | 2024        |
|--------------------------------------|-----|-------------|-------------|-------------|-------------|-------------|-------------|
| EnergyManagement                     |     | DX Division | DS Division | DX Division | DS Division | DX Division | DS Division |
| Energy consumption at business sites | GWh | 4,327       | 30,850      | 4,015       | 32,384      | 4,180       | 34,592      |
| Electricty                           | GWh | 3,067       | 25,249      | 2,914       | 27,042      | 3,088       | 28,996      |
| Others 1)                            | GWh | 1,260       | 5,601       | 1,101       | 5,342       | 1,092       | 5,596       |
| Renewable energy consumption         | GWh | 2,856       | 5,849       | 2,720       | 6,569       | 2,884       | 7,184       |
| Renewable energy transition rate     | %   | 93.1        | 23.2        | 93.4        | 24.3        | 93.4        | 24.8        |

1) Others (Energy consumption at business sites): Steam, LNG, LPG, petrol, diesel

|                                           | 2022   | 2022        | 2023        | 2023                    | 2024        | 2024        |
|-------------------------------------------|--------|-------------|-------------|-------------------------|-------------|-------------|
| Product Energy EfficiencyImprovement 1)   |        | DX Division | DS Division | DX Division DS Division | DX Division | DS Division |
| Product energy consumption reduction rate | %      | 16.4        | -           | 25.1 -                  | 31.5        | -           |

1)   Product energy consumption reduction rate for each year relative to 2019 identical performance/specification models for 7 major product categories

|                                         |        | 2022        | 2022        | 2023        | 2023        | 2024        | 2024        |
|-----------------------------------------|--------|-------------|-------------|-------------|-------------|-------------|-------------|
| Resource Efficiency of Products         |        | DX Division | DS Division | DX Division | DS Division | DX Division | DS Division |
| [Recycled plastic]                      |        |             |             |             |             |             |             |
| Cumulative use 1)                       | Tonnes | 409,117     | -           | 567,056     | -           | 768,811     | -           |
| Amountusedbyyear                        | Tonnes | 98,826      | -           | 157,939     | -           | 201,755     | -           |
| Percentage of recycled plastics used 2) | %      | 13.9        | -           | 25.0        | -           | 31.0        | -           |
| [Recycled packaging]                    |        |             |             |             |             |             |             |
| Recycled packaging 3)                   | Tonnes | 13,011      | -           | 15,273      | -           | 16,399      | -           |

1) Cumulative use : from 2009

2) Percentage of recycled plastic used: amount of recycled plastic used / total amount of plastic used

3) Recycled packaging; based on data collected in Korea

|                                        |        | 2022        | 2022        | 2023        | 2023        | 2024        | 2024        |
|----------------------------------------|--------|-------------|-------------|-------------|-------------|-------------|-------------|
| WasteManagement                        |        | DX Division | DS Division | DX Division | DS Division | DX Division | DS Division |
| Amountofwastegenerated                 | Tonnes | 329,861     | 1,083,504   | 307,325     | 1,007,598   | 322,144     | 1,026,835   |
| General waste                          | Tonnes | 274,126     | 657,803     | 254,748     | 626,427     | 271,040     | 639,470     |
| Hazardous waste 1)                     | Tonnes | 55,735      | 425,701     | 52,577      | 381,171     | 51,104      | 387,365     |
| Amountofwastetreated                   | Tonnes | 329,861     | 1,083,504   | 307,325     | 1,007,598   | 322,144     | 1,026,835   |
| Recovered for recycling                | Tonnes | 308,670     | 1,055,697   | 284,484     | 992,177     | 303,953     | 1,014,235   |
| Incineration (off-site)                | Tonnes | 7,069       | 18,410      | 18,509      | 12,499      | 15,629      | 10,702      |
| Landfill (off-site)                    | Tonnes | 13,809      | 1,118       | 3,920       | 702         | 1,077       | 618         |
| Others                                 | Tonnes | 314         | 8,279       | 412         | 2,220       | 1,485       | 1,281       |
| Percentageofwasterecoveredforrecycling | %      | 94          | 97          | 93          | 98          | 94          | 99          |

1) Hazardous waste: Based on monitoring standards of individual countries where our business sites are located

|                                                     |                                     | 2022        | 2022        | 2023        | 2023        | 2024        | 2024        |
|-----------------------------------------------------|-------------------------------------|-------------|-------------|-------------|-------------|-------------|-------------|
| Amountofe-WasteCollectedandRecycled                 | Amountofe-WasteCollectedandRecycled | DX Division | DS Division | DX Division | DS Division | DX Division | DS Division |
| Cumulative amountofe-waste collected 1)             | Tonnes                              | 5,698,008   | -           | 6,297,161   | -           | 6,908,516   | -           |
| Amountofe-wastecollected                            | Tonnes                              | 598,572     | -           | 599,153     | -           | 611,354     | -           |
| Asia and Oceania                                    | Tonnes                              | 220,357     | -           | 235,197     | -           | 250,057     | -           |
| Americas                                            | Tonnes                              | 45,842      | -           | 54,014      | -           | 59,405      | -           |
| Europe                                              | Tonnes                              | 332,374     | -           | 309,942     | -           | 301,893     | -           |
| Amountofe-wastecollected by year andproduct type 2) | Tonnes                              | 132,681     | -           | 140,162     | -           | 141,582     | -           |
| Heat exchanger                                      | Tonnes                              | 75,879      | -           | 89,754      | -           | 75,085      | -           |
| Display                                             | Tonnes                              | 10,644      | -           | 12,840      | -           | 11,282      | -           |
| Telecommunications service equipment                | Tonnes                              | 1,930       | -           | 2,155       | -           | 2,178       | -           |
| Other electric and electronics equipment            | Tonnes                              | 44,228      | -           | 35,414      | -           | 53,037      | -           |
| Amountofmaterialsrecoveredforrecycling 3)           | Tonnes                              | 111,406     | -           | 117,025     | -           | 118,150     | -           |
| Scrap metals                                        | Tonnes                              | 57,763      | -           | 61,422      | -           | 61,677      | -           |
| Nonferrous metals                                   | Tonnes                              | 11,996      | -           | 12,356      | -           | 13,281      | -           |
| Synthetic resin                                     | Tonnes                              | 33,157      | -           | 35,752      | -           | 35,909      | -           |
| Glass                                               | Tonnes                              | 4,068       | -           | 3,183       | -           | 3,311       | -           |
| Others                                              | Tonnes                              | 4,422       | -           | 4,312       | -           | 3,972       | -           |

1) Cumulative amount of e-waste collected from 2009

2)   Amount of e-waste collected by year and product type: Based on data collected in Korea

3) Amount of materials recovered for recycling: Based on data collected in Korea

73

|                                 |              | 2022        | 2022        | 2023        | 2023        | 2024        | 2024        |
|---------------------------------|--------------|-------------|-------------|-------------|-------------|-------------|-------------|
| WaterManagement                 |              | DX Division | DS Division | DX Division | DS Division | DX Division | DS Division |
| Water intake                    | 1,000 tonnes | 18,823      | 153,988     | 17,270      | 160,090     | 18,961      | 169,580     |
| Municipal water (surface water) | 1,000 tonnes | 18,124      | 153,988     | 16,485      | 160,090     | 18,059      | 169,580     |
| Groundwater                     | 1,000 tonnes | 698         | -           | 786         | -           | 902         | -           |
| Wastewater discharge            | 1,000 tonnes | 12,682      | 123,436     | 13,042      | 129,953     | 15,446      | 136,663     |
| Water reused                    | 1,000 tonnes | 3,483       | 113,108     | 3,470       | 119,421     | 2,737       | 122,726     |
| [Ultra-pure water reused]       |              |             |             |             |             |             |             |
| Supply                          | 1,000 tonnes | 2,219       | 68,770      | 2,098       | 69,389      | 2,361       | 72,423      |
| Recovery                        | 1,000 tonnes | -           | 24,731      | -           | 22,004      | -           | 23,025      |
| Suppliers' water consumption 1) | 1,000 tonnes | 63,236      | 31,578      | 65,783      | 31,699      | 56,535      | 31,932      |

1)   Suppliers' water consumption: based on water consumption for Samsung Electronics product manufacturing by the top 90% of suppliers in terms of transaction scale

|                                         |              | 2022        | 2022        | 2023        | 2023        | 2024        | 2024        |
|-----------------------------------------|--------------|-------------|-------------|-------------|-------------|-------------|-------------|
| ChemicalSubstanceManagement 1)          |              | DX Division | DS Division | DX Division | DS Division | DX Division | DS Division |
| Chemical substance use 2)               | 1,000 tonnes | 6           | 572         | 6           | 512         | 6           | 545         |
| Discharge of major hazardous substances | Cases        | -           | -           | -           | -           | -           | -           |

1) Scope of data collection: Korea

2)   Chemicals consumption: calculation criteria changed to PRTR standard starting from 2018 *PRTR: Pollutant Release and Transfer Register, dealing with chemical substance emission and transfer information

|                                                        | 2022          | 2022         | 2023        | 2023        | 2024        | 2024        |
|--------------------------------------------------------|---------------|--------------|-------------|-------------|-------------|-------------|
| WorkplaceEnvironmentManagement                         | DX Division   | DS Division  | DX Division | DS Division | DX Division | DS Division |
| Investment inEHS                                       | KRW100million | 1,248 20,588 | 1,117       | 19,167      | 1,304       | 22,184      |
| Violations of environment-related laws and regulations | Cases         | 2 -          | 1           | -           | -           | 2 1)        |

1)   1.   Samsung Electronics received a fine of 6 million KRW for violating Article 31, Section 1 (Reporting on Subcontracting of Hazardous Chemical Handling) of the Chemical Substances Control Act, related to the potassium hydroxide contact incident that occurred at the Cheonan site on September 19, 2024. The fine was voluntarily paid. To prevent recurrence, we are taking measures such as conducting a full review of subcontracting reports for all production equipment installation and maintenance companies, in compliance with relevant regulations.

2.   On 18 June 2021, the Texas Commission on Environmental Quality (TCEQ) issued a Notice of Corrective Action regarding a failure to report on wafer shredding equipment at the Samsung Austin Semiconductor LLC. (SAS) subsidiary of Samsung Electronics' DS Division. On 10 June 2022, the TCEQ issued a Notice of Corrective Action regarding the wastewater spill at SAS. TCEQ issued a fine of 93K USD to SAS on 8 March 2024, taking into account that SAS independently obtained environmental certification and performed internal management actions for the wafer shredding equipment while actively carrying out remediation activities to address the wastewater spillage as soon as SAS became aware of the incident. SAS paid the fine in full. SAS developed and deployed preventive measures (pre-evaluation systems, development of monitoring, control systems).

|                                                       |        | 2022        | 2022        | 2023        | 2023        | 2024        | 2024        |
|-------------------------------------------------------|--------|-------------|-------------|-------------|-------------|-------------|-------------|
| PollutantManagement                                   |        | DX Division | DS Division | DX Division | DS Division | DX Division | DS Division |
| [Air pollutant emissions]                             |        |             |             |             |             |             |             |
| NOx                                                   | Tonnes | 33          | 752         | 46          | 674         | 23          | 706         |
| SOx                                                   | Tonnes | 1           | 34          | 2           | 41          | 0.3         | 35          |
| NH₃                                                   | Tonnes | 2           | 93          | 0.5         | 125         | 1           | 103         |
| HF                                                    | Tonnes | -           | 19          | 0.03        | 16          | 0.02        | 13          |
| PM 1)                                                 | Tonnes | 143         | 64          | 72          | 69          | 33          | 58          |
| Volatile organic compoundemissions                    | Tonnes | 10          | 384         | 7           | 391         | 6           | 486         |
| [Water pollutant discharge]                           |        |             |             |             |             |             |             |
| TOC(Korea) 2)                                         | Tonnes | -           | -           | 2           | 292         | 1           | 318         |
| COD(Global)                                           | Tonnes | 286         | 560         | 433         | 101         | 512         | 137         |
| BOD                                                   | Tonnes | 85          | 228         | 161         | 251         | 133         | 294         |
| SS                                                    | Tonnes | 154         | 257         | 206         | 725         | 185         | 631         |
| F                                                     | Tonnes | 2           | 574         | 1           | 625         | 2           | 486         |
| Heavy metals                                          | Tonnes | 1           | 15          | 2           | 15          | 2           | 9           |
| Consumption of ozone depleting substances (CFC-eq) 3) | Tonnes | 2           | 0.2         | 1           | -           | 0.2         | 0.2         |

1) Previous dust emission disclosure standard changed

2) Apply data separately into TOC (Korea) and COD (Global) starting from 2023

3) Scope of data collection: Korea Reported content in the 2025 Sustainability Report may have slight discrepancies between the total values and individual item values due to rounding to the nearest unit decimal place.

<!-- image -->

74

## Appendix

| Independent Assurance Report                              |   76 |
|-----------------------------------------------------------|------|
| Verification Statement on                                 |   77 |
| Verification Statement on Scope 3 Greenhouse Gas Emission |   78 |
| GRI Index                                                 |   80 |
| TCFD Index                                                |   82 |
| SASB Index                                                |   84 |
| About This Report                                         |   86 |

<!-- image -->

## Independent Assurance Report

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

77

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

78

<!-- image -->

<!-- image -->

<!-- image -->

79

## GRI Index

| Topic                         | No.                        | Disclosure                                                                | Page                                                                                                                | Notes                                                                            |
|-------------------------------|----------------------------|---------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------|
| GRI 2: Universal Standards    | GRI 2: Universal Standards | GRI 2: Universal Standards                                                | GRI 2: Universal Standards                                                                                          | GRI 2: Universal Standards                                                       |
| The                           | 2-1                        | Organizational details                                                    | 5, 87                                                                                                               |                                                                                  |
| organization                  | 2-2                        | Entities included in the organization's sustainability reporting          | 5, 87                                                                                                               |                                                                                  |
| and its reporting             | 2-3                        | Reporting period, frequency and contact point                             | 87                                                                                                                  |                                                                                  |
| practices                     | 2-4                        | Restatements of information                                               | -                                                                                                                   | Disclose the changes to the report                                               |
|                               | 2-5                        | External assurance                                                        | 76                                                                                                                  | Disclose the changes to the report                                               |
| Activities and workers        | 2-6                        | Activities, value chain and other business relationship                   | 7, 45-50                                                                                                            | Disclose the changes to the report                                               |
| Activities and workers        | 2-7                        | Employees                                                                 | 64-65                                                                                                               | Disclose the changes to the report                                               |
| Activities and workers        | 2-8                        | Workers whoarenot employees                                               | 64                                                                                                                  | Disclose the changes to the report                                               |
| Governance                    | 2-9                        | Governance structure and composition                                      | -                                                                                                                   | Disclose the changes to the report                                               |
| Governance                    | 2-10                       | Nomination and selection of the highest governance body                   | -                                                                                                                   | Disclose the changes to the report                                               |
| Governance                    | 2-11                       | Chair of the highest governance body                                      | -                                                                                                                   | Disclose the changes to the report                                               |
| Governance                    | 2-12                       | Role of the highest governance body in overseeing the managementofimpacts | -                                                                                                                   | Annual Business Report 276~286p                                                  |
| Governance                    | 2-13                       | Delegation of responsibility for managing impacts                         | -                                                                                                                   | (Ⅵ. Corporate Governance, 1. Board                                               |
| Governance                    | 2-14                       | Role of the highest governance body in sustainability reporting           | -                                                                                                                   | of Directors)                                                                    |
| Governance                    | 2-15                       | Conflicts of interest                                                     | 59-60                                                                                                               | Disclose the changes to the report                                               |
| Governance                    | 2-16                       | Communication of critical concerns                                        | 6                                                                                                                   | Disclose the changes to the report                                               |
| Governance                    | 2-17                       | Collective knowledge of the highest governance body                       | -                                                                                                                   | Disclose the changes to the report                                               |
| Governance                    | 2-18                       | Evaluation of the performance of the highest governance body              | -                                                                                                                   | Annual Business Report 308~320p (Ⅷ.Executives and Employees, 2.Remu-             |
| Governance                    | 2-19                       | Remuneration policies                                                     | -                                                                                                                   | Annual Business Report 308~320p (Ⅷ.Executives and Employees, 2.Remu-             |
| Governance                    | 2-20                       | Process to determine remuneration                                         | -                                                                                                                   | neration for Directors)                                                          |
| Governance                    | 2-21                       | Annual total compensation ratio                                           | -                                                                                                                   | This information is not disclosed for manage- mentpurposes.                      |
| Strategy, Policies, Practices | 2-22                       | Statement on sustainable development strategy                             | 4                                                                                                                   |                                                                                  |
| and                           | 2-23                       | Policy commitments                                                        | 9, 35-38,60 OurCompany: 6,8 Planet(DX) :                                                                            |                                                                                  |
| and                           | 2-24                       | Embedding policy commitments                                              | 11-13, 16-17, 18-20 Planet(DS) : 21-23, 27, 29, 32 People : 35-39, 41-43, 45-48, 50-51, 53-55, 57 Principle : 59-60 |                                                                                  |
| and                           | 2-25                       | Processes to remediate negative impacts                                   | 36, 39, 47                                                                                                          |                                                                                  |
| and                           | 2-26                       | Mechanisms for seeking advice and raising concerns                        | 59-60                                                                                                               |                                                                                  |
| and                           | 2-27                       | Compliance with laws and regulations                                      | 74                                                                                                                  | Annual Business Report 346~350p (XI. Other Information, 3. Sanctions and Others) |
| and                           | 2-28                       | Membership associations                                                   | 9, 15, 25                                                                                                           |                                                                                  |
| Stakeholder                   | 2-29                       | Approach to stakeholder engagement                                        | 9                                                                                                                   |                                                                                  |
| Engagement                    | 2-30                       | Collective bargaining agreements                                          | 39,40                                                                                                               |                                                                                  |

Topic No.

GRI 3: Universal Standards

Disclosure on

3-1

Processes to determine material topics

Material

3-2

Topics

3-3

GRI 200 Economy

Economic

201-1

Performance

Market

Presence

Indirect

Economic

Impacts

Anti-corrup-

tion

Anti-

competitive

behavior

Tax List of material topics Management of material topics Direct economic value generated and distributed Financial implications and other risks and opportunities due to climate change Define benefit plan obligations and other retirement plans Ratios of standard entry level wage by gender compared to local minimum wage Infrastructure investments and services supported Significant indirect economic impacts Operations assessed for risks related to corruption Communication and training about anti-corruption policies and procedures Confirmed incidents of corruption and actions taken Legal actions for anti-competitive behavior, anti-trust, and monopoly practices Tax governance, control, and risk management Stakeholder engagement and management of concerns related to tax Country-by-country reporting Disclosure Recycled input materials used Reclaimed products and their packaging materials Energy consumption within the organization Energy intensity Reduction of energy consumption Reductions in energy requirements of products and Interactions with water as a shared resource Manage of water discharge-related impacts Water withdrawal Water discharge Water consumption

Energy

Water and

Effluents

201-2

201-3

202-1

203-1

203-2

205-1

205-2

205-3

206-1

207-2

207-3

207-4

Topic No.

GRI 300  Environmental

Materials

301-2

301-3

302-1

302-3

302-4

302-5

303-1

303-2

303-3

303-4

303-5

Disclosure Page

7-8

8

8

62

12-13, 22-23

-

40, 42

51-52

51-52

59-60

59-60

-

-

-

-

62

Page

69, 73

69, 73

69, 72

68, 69

22-25

15, 25-26, 69, 73

18-19, 29-30

18-19, 29-30

18-19, 29-30

18-19, 29-30,

70-71, 74

18-19, 29-30,

70-71, 74

Notes

Annual Business

Report 84p

(Ⅲ. Financial Affairs, 3.

Notes to consolidated

financial statements)

Annual Business

Report 346-350p

(XI. Other Information,

3. Sanctions and Oth-

ers)

[Sustainability](https://www.samsung.com/global/sustainability/policy-file/AYVhOE-aBDIAIx95/38_Tax-Risk-Management-Policy.pdf)

[Website](https://www.samsung.com/global/sustainability/policy-file/AYVhOE-aBDIAIx95/38_Tax-Risk-Management-Policy.pdf)

[Sustainability](https://www.samsung.com/global/sustainability/policy-file/AYVhOE-aBDIAIx95/38_Tax-Risk-Management-Policy.pdf)

[Website](https://www.samsung.com/global/sustainability/policy-file/AYVhOE-aBDIAIx95/38_Tax-Risk-Management-Policy.pdf)

Notes

80

## GRI Index

| Topic                    | No.                  | Disclosure                                                                                                                               | Page                 | Notes                  |
|--------------------------|----------------------|------------------------------------------------------------------------------------------------------------------------------------------|----------------------|------------------------|
| GRI300 Environmental     | GRI300 Environmental | GRI300 Environmental                                                                                                                     | GRI300 Environmental | GRI300 Environmental   |
| Biodiversity             | 304-1                | Operational sites owned, leased, managedin, or adjacent to, protected areas and areas of high biodiversity value outside protected areas | 29, 31               |                        |
| Biodiversity             | 304-2                | Significant impacts of activities, products, and services on biodiversity                                                                | 19, 29, 31           |                        |
| Biodiversity             | 304-3                | Habitats protected or restored                                                                                                           | 19, 29, 31           |                        |
| Biodiversity             | 304-4                | IUCN Red List species and national conservation list species with habitats in areas affected by operations                               | 31                   | Sustainability Website |
| Emissions                | 305-1                | Direct (Scope 1) GHGemissions                                                                                                            | 68, 72               |                        |
| Emissions                | 305-2                | Energy indirect (Scope 2) GHGemissions                                                                                                   | 68, 72               |                        |
| Emissions                | 305-3                | Other indirect (Scope 3) GHGemissions                                                                                                    | 68, 72               |                        |
| Emissions                | 305-4                | GHGemissions intensity                                                                                                                   | 68                   |                        |
| Emissions                | 305-5                | Reduction of GHGemissions                                                                                                                | 22-25                |                        |
| Emissions                | 305-6                | Emissions of ozone-depleting substances (ODS)                                                                                            | 70, 74               |                        |
| Emissions                | 305-7                | Nitrogen oxides (NOx), Sulfur oxides (SOx), and other significant air emissions                                                          | 70, 74               |                        |
| Waste                    | 306-1                | Waste generation and significant waste-related impacts                                                                                   | 16-17, 27-28         |                        |
| Waste                    | 306-2                | Managementof significant waste-related impacts                                                                                           | 16-17, 27-28         |                        |
| Waste                    | 306-3                | Waste generated                                                                                                                          | 27-28, 70, 73        |                        |
| Waste                    | 306-4                | Waste diverted from disposal                                                                                                             | 16-17, 27-28, 70, 73 |                        |
| Waste                    | 306-5                | Waste directed to disposal                                                                                                               | 27-28, 70, 73        |                        |
| Supplier                 | 308-1                | Newsuppliers that were screened using environmental criteria                                                                             | 46-48, 66            |                        |
| Environmental Assessment | 308-2                | Negative environmental impacts in the supply chain and actions                                                                           | 46-48                |                        |
| Topic                    | No.                  | Disclosure                                                                                                                               | Page                 | Notes                  |
| GRI 400Society           | GRI 400Society       | GRI 400Society                                                                                                                           | GRI 400Society       | GRI 400Society         |
| Employment               | 401-1                | Newemployeehires and employee turnover                                                                                                   | 64                   |                        |
| Employment               | 401-2                | Benefits provided to full-time employees that are not provided to temporary or part-term employees                                       | 40, 44               |                        |
| Employment               | 401-3                | Parental leave                                                                                                                           | 65                   |                        |
| Occupational Health and  | 403-1                | Occupational health and safetymanagementsystem                                                                                           | 43-44                |                        |
| Safety                   | 403-2                | Hazard identification, risk assessment, and incident investigation                                                                       | 43-44                |                        |
| Safety                   | 403-3                | Occupational health services                                                                                                             | 43-44                |                        |
| Safety                   | 403-4                | Worker participation, consultation, and communication on occupational health and safety                                                  | 9, 43-44             |                        |
| Safety                   | 403-5                | Worker training on occupational health and safety                                                                                        | 43-44                |                        |
| Safety                   | 403-6                | Promotion of worker health                                                                                                               | 43-44                |                        |
| Safety                   | 403-7                | Prevention and mitigation of occupational health and safety impacts directly linked by business relationships                            | 43-44                |                        |
| Safety                   | 403-8                | Workers covered by an occupational health and safety managementsystem                                                                    | 43-44                |                        |
| Safety                   | 403-9                | Work-related injuries                                                                                                                    | 65                   |                        |

| Topic                                              | No.            | Disclosure                                                                                                  | Page             | Notes                                                                                           |
|----------------------------------------------------|----------------|-------------------------------------------------------------------------------------------------------------|------------------|-------------------------------------------------------------------------------------------------|
| GRI 400Society                                     | GRI 400Society | GRI 400Society                                                                                              | GRI 400Society   | GRI 400Society                                                                                  |
| Training and Education                             | 404-1          | Average hours of training per year per employee                                                             | 66               |                                                                                                 |
| Training and Education                             | 404-2          | Programs for upgrading employee skills and transition assistance programs                                   | 42, 66           |                                                                                                 |
| Training and Education                             | 404-3          | Percentage of employees receiving regular performance and career development reviews                        | 42               |                                                                                                 |
| Diversity and Equal Opportunity                    | 405-1          | Diversity of governance bodies and employees                                                                | 64               |                                                                                                 |
| Diversity and Equal Opportunity                    | 405-2          | Ratio of basic salaryandremunerationofwomentomen                                                            | 42               |                                                                                                 |
| Non- discrimination                                | 406-1          | Incidents of discrimination and corrective actions taken                                                    | 36-39, 41        |                                                                                                 |
| Freedom of Association and Collective Bar- gaining | 407-1          | Operations and suppliers in which the right to freedom of association and collective bargaining maybeatrisk | 40, 48           |                                                                                                 |
| Child Labor                                        | 408-1          | Operations and suppliers at significant risk for incidents of child                                         | 36, 48-49, 67    |                                                                                                 |
| ForcedorCom- pulsory Labor                         | 409-1          | Operations and suppliers at significant risk for incidents of forced or compulsory labor                    | 36, 48-49, 67    |                                                                                                 |
| Rights of Indig- enous People                      | 411-1          | Incidents of violations involving rights of indigenous peoples                                              |                  | Noapplicable cases occurred                                                                     |
| Local Communities                                  | 413-1          | Operations with local community engagement, impact assessments, and development programs                    | 9, 19, 39, 51-52 |                                                                                                 |
| Supplier Social Assessment                         | 414-1          | Newsuppliers that were screed using social criteria                                                         | 46, 66           |                                                                                                 |
| Supplier Social Assessment                         | 414-2          | Negative social impacts in the supply chain and actions taken                                               | 46-48            |                                                                                                 |
| Public Policy                                      | 415-1          | Political contributions                                                                                     |                  | Use of company funds for political contributions is prohibited by the corporate Code of Conduct |
| Customer Health and Safety                         | 416-2          | Incidents of non-compliance concerning the health and safety impacts of products and services               |                  | Annual Business Report 346-350p (XI. Other Information, 3. Sanctions and Others)                |
| Marketing and Labeling                             | 417-1          | Requirements for product and service information and labeling                                               | -                | Refer to the companies Website                                                                  |
| Marketing and Labeling                             | 417-3          | Incidents of non-compliance concerning marketing communications                                             | -                | Annual Business Report 346-350p (XI. Other Information, 3. Sanctions and Others)                |

·   Statement of Use: Samsung Electronics has reported in accordance with the GRI standards for the covered period (from January 1st to December 31st, 2024).

·   GRI 1 used: GRI 1: Foundation 2021

<!-- image -->

81

## TCFD Index

| Category   |                                                                                                                                                              | OurPerformance                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     | Page                              |
|------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------|
| Governance | a) Describe the board's oversight of climate-related risks and opportunities.                                                                                | TheDXDivisionviewsenvironmentalmatters,includingclimatechange,ascriticalareasdirectlylinkedtobusinessoperationsandfinancialperformance,andtheseareoverseenbythehighest decision-makingbody,theBoardofDirectors.TheBoardestablishesthecompany'sstrategiesandgoalsrelatedtoenvironmentalmanagement,overseesmajoractivities,andparticularly reviewstheseactivitiesthroughtheSustainabilityCommittee,whichiscomposedofindependentdirectors.InSeptember2022,theSustainabilityCommitteeresolvedtheNewEnvironmental Strategy,whichencompasseslongtermclimateresponseandresourcecircularitygoals.Since2023,keyachievementshavebeenincludedinthecommittee'sagendaandreviewedannually.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       | P.11, 21, CDP: M.04               |
|            | b) Describe management's role in assessing and managing climate-related risks and opportunities.                                                             | Theresponsibility andauthority for establishingclimatechangeresponsestrategies,identifyingimplementationtasks,andexecutinginvestmentsliewiththeCEO.Toensureeffective accountability,climate-relatedindicatorsarereflectedintheKPIsofthemanagementteam.WeoperatetheDXDivision'sSustainabilityCouncilandtheDSDivision'sESGManagement Council,ledbyeachdivisionhead,inadditiontocouncilsbyenvironmentaltopicstoestablishenvironmentalmanagementplansandassesstheirperformance.EachDivision'sCouncil operatesseparatecommitteeswhichtopexecutivesinchargeofkeyareasattend. TheDXDivisionisresponsibleforexecutingenvironmentalmanagementplansthroughtheCorporateSustainabilityCenter,GlobalEHSOffice,regionalenvironmentaldedicated organizations,andsustainabilityofficeswithinbusinessunits.Interdepartmentalforumsareconductedtomanageandsupervisegreenhousegas(GHG)emissionreductiontasksthrough theEnvironmentalSafetyCommittee.Additionally,torespondtocarbonemissionsdisclosures,anESGDisclosureTaskForceisoperated,whichestablishescalculationstandardsandbuilds systemsaspartofongoingefforts. TheDSDivisionapprovesandoverseesmajoractivitiesfortheDSDivision'senvironmentalmanagementstrategyandgoalsattheESGManagementCouncil,chairedbytheCEO. Additionally,theDSDivisionestablishesandmanagesdetailedenvironmentalmanagementandimplementationplansbyoperatingpracticalworkinggroupsforeachenvironmental domain,suchastheCarbonReductionCommittee,EnvironmentalConservationCommittee,andReuseExpansionCommittee.Inparticular,theCarbonReductionCommitteemanagesthe entireclimatechangedomain,includingthemanagementofGHGemissions.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         | P.11, 21, CDP: M.02, M.03         |
| Strategy   | a) Describe the climate-related risks and opportunities the orga- nization has identified over the short, medium, and long term.                             | SamsungElectronicsregularly monitorsclimate-relatedriskandopportunitiesacrosstheentirevaluechain.Majorregulatoryrisksareintegratedintothecorporateriskmanagement process,andintheeventofsignificantrisks,theyarediscussedintheSustainabilityCommittee,withrelevantdepartmentsrespondingaccordingly.Inordertomoresystematicallymanage andrespondtoclimate-relatedrisks andopportunities, they are systematically identified in accordancewiththeclimate-related riskandopportunityanalysisprocess.Climatechange scenarios are utilizedtocalculatethefinancialimpacteachriskandopportunityhasonthebusiness. For the DXDivision, keyphysical risks (floods, typhoons, droughts, wildfires,extremeheat)haveimpactsacrosstheshort-,medium-,andlong-term,whiletransitionrisksandopportunities (increaseincostofpurchasingcarboncredits,increaseindemandforlow-carbonproductsandservices)primarilyhaveimpactsinthemedium-tolong-term. For the DSDivision, keyphysical risks (droughts, floods, typhoons, wildfires,extremeheat)haveimpactsacrosstheshort-,medium-,andlong-term,whiletransitionrisks(increaseincost ofpurchasingcarboncredits,increaseinproductioncostduetochangingenergyprices)andopportunities(increaseindemandforlow-carbonproductsandservices,useofrenewable energy)primarilyhaveimpactsinthemedium-tolong-term.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       | P.12-13, P.22-23, CDP: M.02, M.03 |
|            | b) Describe the impact of climate-related risks and opportunities on the organiza- tion's businesses, strategy, and financial planning.                      | SamsungElectronicsconductedaclimatescenarioanalysistosystematically manageclimate-relatedrisks andopportunities,whicharecriticalaspectsofourbusinessoperationsand financial performance.Wecalculatedthefinancial impactsofmajorphysicalrisks andtransition risks andopportunities byclimatescenario. According to the analysis, for the DXDivision, all 3IPCCscenariosusedindicatedthatfloodswouldhavethelargestfinancialimpactofthe5risks(flood,typhoon,drought,wildfire,extreme heat). If climate changeworsensfloodrelatedinundation,theresulting physical damagetoourassetsincludingbuildings,facilities,inventorieswillreducetheirvalueandmaycause financialdamageduetosalesreductionfrommanufacturingdelays.Majortransitionrisksincludedincreasesinthecostofpurchasingcarboncreditsandincreasedcostsduetorising electricitypriceswhilemajortransitionopportunitiesincludedincreasesindemandforlow-carbonproductsandservicesandtheuseofrenewableenergy.Ofthese,inthecaseofincreases in the cost of purchasing carboncredits, potential operational cost increasesfromcarboncreditpurchasesareexpectedshouldcarboncreditpricesincreaseandpaidallocationratesrise. Also,increasesindemandforlow-carbonproductsandservicesareexpectedtoserveaslong-termopportunitiesforsalesincreasesconsideringourcurrentbusinessportfolioandplan. FortheDSDivision,all3IPCCscenariosusedindicatedthatdroughtswouldhavethelargestfinancialimpactof5risks(flood,typhoon,drought,wildfire,extremeheat).Weassessedthat shouldpotentialpricesofwaterriseduetoclimatechange,potentiallossesfrombusinesssiteswithhighwaterdemandwouldbesignificantaswell.Formajortransitionrisks,weanticipate aanincreaseincostofpurchasingcarboncreditsaccordingtocarbonpriceincreases.KoreansitesoperatingundertheEmissionTradingSystem(ETS)mustpaythecorrespondingcostifwe exceedallowedemissions.Furthermore,aspartofeffortstoreducewateruseandconsumption,thecompanyisexpandinginvestmentsinandoperationoffacilitiestoincreasewaterreuse rates.Giventhatthecostsavingsfrompurchasinglesswateraresignificantcomparedtotheinvestment,thisisexpectedtohaveapositivefinancialimpact. | P.12-13, 22-23, CDP: M.03, M.05   |
|            | c) Describe the resilience of the organization's strategy, taking into consideration different climate-related scenarios, including a 2°C or lower scenario. | SamsungElectronicsismakingeffortstounderstandtheinfluenceonitsbusinessof socio-economic changesbyclimate-relatedscenarios,preparingforandenhancingourstrategies against future climate changerelateduncertainties,andanalyzingmajorrisksandopportunitiesbyutilizingthelatestsciencebasedscenarioinaccordancetothelatestclimatechange relatedinternationalagreement.Weselectedhighcarbonemissionandbelow2℃scenarios,forwhichphysicalriskanalysisweusedtheIPCCscenarios(SSP1-2.6,SSP2-4.5,SSP5-8.5) andwhichtransitionriskanalysisweusedtheIEA(NetZeroEmissionsby2050,AnnouncedPledges,StatedPolicies)andNGFS(NetZero2050,NDCs,CurrentPolicies)scenarios.Using suchscenarios serve animportantroleindiversifying ourassessmentofpotentialrisks andopportunities across ourbusiness, strategy, andfinancial plans.Wewillreinforceourbusiness competitiveness in the future bycontinuing to periodically analyze andcalculate risks andopportunities byclimatescenario andrelevantfinancial impacts.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   | P.12-13, 22-23, CDP: M.03, M.05   |

## TCFD Index

| Category            |                                                                                                                                                             | OurPerformance                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            | Page                       |
|---------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------|
| Risk Manage- ment   | a) Describe the organization's pro- cesses for identifying and assessing climate-related risks.                                                             | SamsungElectronics compiled a pool of risks and opportunities related to our business by reviewing global climate change trends and industry responses based on the TCFD recommendations and CDPsuggested climate-related risks and opportunities. Weusedclimate change scenario analysis tools to initially identify major risks and opportunities, and conducted surveys with key internal and external stakeholders to assess the likelihood and impact of potential risks. The scenario analysis tool and survey results were discussed in detail through roundtable discussions with relevant departments, after which a final list of major risks and opportunities regarding climate change was identified.                                                                                                                        | P.12-13, 22-23, CDP: M.02  |
|                     | b) Describe the organization's processes for managing climate-related risks.                                                                                | To manageclimate-related risks, the corporate EHSdepartments monitor energy usage, GHGemissions, renewable energy use, and climate impact. In regular meetings such as the DXDivision's Environmental Safety Meetings and the DSDivision's Carbon Reduction Committee, climate change issues that have occurred or are expected to occur in global sites are discussed, and managementstrategies are decided and implemented. The DXDivision's Sustainability Council and the DSDivision's ESGManagementCouncil discuss climate- related risks and opportunities and makes related decisions. Additionally, to respond to carbon emissions disclosures, an ESGDisclosure Task Force is operated, which establishes calculation standards and builds systems as part of ongoing efforts.                                                   | P.11-13, 22-23, CDP: M.02  |
|                     | c) Describe howprocesses for identifying, assessing, and managing climate-related risks are integrated into the organiza- tion's overall risk management.   | SamsungElectronics integrates climate-related risks and opportunities into our enterprise risk managementsystem for effective management. Should an acute risk such as wind or flood damageoccur, werespond promptly according to the emergency response process to minimize damageandcarry out activities to restore business operations. Additionally, wecontinuously assesses, monitors, and manages climate change-related risks occurring at global sites in accordance with risk managementprocesses and manuals for various fields, including sustainability management, environmental safety, marketing, sales, and compliance. Key risk and opportunity factors are reported to the Sustainability Council and the ESGManagementCouncil, where response plans are reviewed, deliberated on, and regularly monitored and managed. | P.12-13, 22-23, CDP: M.02  |
| Metrics and Targets | a) Disclose the metrics used by the organization to assess climate- related risks and opportunities in line with its strategy and risk managementprocess.   | To assess and managethe risks and opportunities related to climate change, weclosely monitor metrics including GHGemissions, per-unit GHGemissions, energy consumption, renewable energy use, and water consumption of individual business sites as well as the ratio of recycled materials used in products, amount of e-waste collected, and average power consumption of products.                                                                                                                                                                                                                                                                                                                                                                                                                                                     | P.11, 22, 62-68, CDP: M.07 |
|                     | b) Disclose Scope 1 (direct emis- sions), Scope 2 (indirect emis- sions), and Scope 3 (miscella- neous indirect scope)GHG emissions, and the related risks. | Wedisclose our Scope 1, 2 and 3 emissions emissions via the Sustainability Report and CDPReport.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          | P.68, 72, CDP: M.07        |
|                     | c) Describe the targets used by the organizationtomanage climate-related risks and opportunities and performance against targets.                           | SamsungElectronics discloses its goals and performance in managing climate-related risks and opportunities through its Sustainability Report and CDPReport.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               | P.11, 22, CDP: M.07        |

## SASB Index

HARDWARE

## Sustainability Disclosure Topics &amp; Accounting Metrics

|                               | Code         | Accounting Metric                                                                                                                                                                                            | PageandComment                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
|-------------------------------|--------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Product Security              | TC-HW-230a.1 | Description of the approach to identifying and addressing data security risks in products                                                                                                                    | SamsungElectronics performs a control tower role through the Global Privacy TeamHeadasChief Privacy Offi- cer and Information Security Center Headas Chief Information Security Officer, whooversee the Privacy Steering Committee and the Security Council. The company has established 3 core privacy principles and 4 pillars of cyber- security, developing advanced security technologies and applying themto its products accordingly. For details on SamsungElectronics' personal information protection and security status, please refer to pages 53-54 of the Sus- tainability Report. |
| Employee Diversity& Inclusion | TC-HW-330a.1 | Percentage of gender and racial/ethnic group representation for (1) management, (2) technical staff, and (3) all other employees                                                                             | SamsungElectronics discloses the gender ratios of its management, technical staff, and other employees. For moredetailed information on employee status, please refer to pages 64-65 of the Sustainability Report.                                                                                                                                                                                                                                                                                                                                                                               |
| Product Lifecyle Management   | TC-HW-410a.1 | Percentage of products by revenue that contain IEC 62474 declarable substances                                                                                                                               | Wecomplywithglobal regulations (EU RoHS, REACH, TSCA, etc.) and manageinternal rules in line with Korean and international standards. Weconduct rigorous pre-inspection and follow-up managementofall parts and raw materials used in our products. Please refer to P.20, 32-33, 29~30 herein and the Standards for the Control of Substances Used in Products in the Sustainability Website for our efforts to managepotentially hazardous substances.                                                                                                                                          |
| Product Lifecyle Management   | TC-HW-410a.2 | Percentage of eligible products that meet the EPEAT registration criteria or equivalent 1)                                                                                                                   | · Computers: 85.5% · Mobile phones: 85.3% · Tablets: 36.7% · Displays: 32.0%                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| Product Lifecyle Management   | TC-HW-410a.3 | Percentage of eligible products that meet the ENERGYSTAR®criteria 1)                                                                                                                                         | · Audio devices: 60.6% · Computers:100% · Tablets: 61.6%                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| Product Lifecyle Management   | TC-HW-410a.4 | Weight of end-of-life products and e-waste recovered, percentage recycled                                                                                                                                    | SamsungElectronics has selected the operation of its e-waste collection system as a key initiative for promoting a resource circular system and plans to further expand its e-waste collection system to all global sales countries by 2030. For details on the operation and collection status of SamsungElectronics' e-waste system, please refer to pages 16-17, 69, and 73 of the Sustainability Report.                                                                                                                                                                                     |
| Supply Chain Management       | TC-HW-430a.1 | Percentage of Tier 1 supplier facilities audited in the RBAValidated Audit Process (VAP) or equivalent, by (a) all facilities and (b) high-risk facilities                                                   | P.48, 67                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| Supply Chain Management       | TC-HW-430a.2 | Tier 1 suppliers' (1) non-compliance rate with the RBAValidated Audit Process (VAP) or equivalent and (2) associated corrective action rate for (a) priority non-conformances and (b) other non-conformances | P.48, 67                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| Materials Sourcing            | TC-HW-440a.1 | Description of risk managementassociated with the use of critical materials                                                                                                                                  | P.66-67, SamsungElectronics Responsible Minerals Report                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |

1) 2024 data based on sales in North America (U.S. and Canada)

## Activity Metrics

| Code        | Topic                                         | PageandComment                                              |
|-------------|-----------------------------------------------|-------------------------------------------------------------|
| TC-HW-000.A | Numberofunits produced by product category    | P.9-13, 2024 Annual Business Report (II. Business Overview) |
| TC-HW-000.B | Area of manufacturing facilities              | P.9-13, 2024 Annual Business Report (II. Business Overview) |
| TC-HW-000.C | Percentage of production from ownedfacilities | P.9-13, 2024 Annual Business Report (II. Business Overview) |

<!-- image -->

<!-- image -->

## SASB Index

## SEMICONDUCTORS

## Sustainability Disclosure Topics &amp; Accounting Metrics

|                                                     | Code         | Accounting Metric                                                                                                                                                   | PageandComment                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
|-----------------------------------------------------|--------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Greenhouse gas (GHG) Emissions                      | TC-SC-110a.1 | (1) Gross global Scope 1 emissions and (2) amount of total emissions from perfluorinated compounds                                                                  | P.68, P.72                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| Greenhouse gas (GHG) Emissions                      | TC-SC-110a.2 | Discussion of long-term and short-term strategy or plan to manageScope1emissions, emissions reduction targets, and an analysis of performance against those targets | P.21, P.68, P.72                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| EnergyManagement in Manufacturing                   | TC-SC-130a.1 | (1) Total energy consumption, (2) percentage of electricity delivered from grids, and (3) percentage renewable                                                      | P.69, P.73                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| WaterManagement                                     | TC-SC-140a.1 | (1) Total water withdrawn, (2) total water consumed, percentage of each in regions with High or Extremely High Baseline Water Stress                                | P.70-71                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| WasteManagement                                     | TC-SC-150a.1 | Amountof hazardous waste from manufacturing, percentage recycled                                                                                                    | P.69-70, P.73                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| Employee Health and Safety                          | TC-SC-320a.1 | Description of efforts to assess, monitor, and reduce exposure of employees to humanhealth hazards                                                                  | P.43-44                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| Employee Health and Safety                          | TC-SC-320a.2 | Total amount of monetary losses as a result of legal proceedings associated with employee health and safety violations                                              | 2024 Annual Business Report (XI. Other Information) P.346-350                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| Recruiting& Managing a Global &Skilled Workforce    | TC-SC-330a.1 | Percentage of employees that are (1) foreign nationals and (2) located offshore                                                                                     | P.64-65                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| Product Lifecycle Management                        | TC-SC-410a.1 | Percentage of products by revenue that contain IEC 62474 declarable substances                                                                                      | SamsungElectronics complies with global regulations (EU RoHS, REACH, TSCA, etc.) and manageinternal rules in line with Korean and international standards. Additionally, through the Environmental Safety Innovation Day, SamsungElectronics regularly exchanges ideas with its affiliates, such as SDC, SDI, SamsungElectro-Mechanics, and SamsungBioLogics, on topics like net zero, pollution reduction, resource circularity, and water resources to promote eco-friendly activities. For details on SamsungElectronics' hazardous substance managementstatus, please refer to pages 21 and 33 herein and the Standards for the Control of Substances Used in Products in the Sustainability Website for our efforts to managepotentially hazardous substances. |
| Product Lifecycle Management                        | TC-SC-410a.2 | Processor energy efficiency at a system-level: (1) servers, (2) desktops, and (3) laptops                                                                           | N/A                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| Materials Sourcing                                  | TC-SC-440a.1 | Description of risk managementassociated with the use of critical materials                                                                                         | P.66-67, SamsungElectronics Responsible Minerals Report                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| Intellectual Property Protection& Competitive avior | TC-SC-520a.1 | Total amount of monetary losses as a result of legal proceedings associated with anti-competitive behavior regulations                                              | 2024 Annual Business Report (XI. Other Information) P.346-350                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |

## Activity Metrics

| Code        | Topic                                         | PageandComment                                              |
|-------------|-----------------------------------------------|-------------------------------------------------------------|
| TC-SC-000.A | Total production                              | P.9-13, 2024 Annual Business Report (II. Business Overview) |
| TC-SC-000.B | Percentage of production from ownedfacilities | P.9-13, 2024 Annual Business Report (II. Business Overview) |

<!-- image -->

85

<!-- image -->

## About This Report

Samsung Electronics Co., Ltd. publishes its 18th Sustainability Report in 2025 to transparently communicate its achievements in creating economic, social, and environmental value with various stakeholders.

## Reporting Standard

This report aligns with the Global Reporting Initiative (GRI) Standards: Core Option, and reflects the indicators of the UN Sustainable Development Goals (SDGs), Task Force on Climate-Related Financial Disclosures (TCFD), and Sustainability Accounting Standards Board (SASB).

## Covered Activities

This report covers the activities of all of our business sites in Korea and other regions as well as our supply chains. Our consolidated financial performance is reported in accordance with K-IFRS, and our environmental performance is reported based on data collected from 33 manufacturing sites as well as other facilities including sales centers and R&amp;D centers in Korea and other regions. Samsung Electronics headquarters is located at 129 Samsung-ro, Yeongtong-gu, Suwon-si, Gyeonggi-do, Republic of Korea.

## Covered Period

This report illustrates our economic, social, and environmental performance and activities from January 1st to December 31st, 2024. Performance as of June 2025 has been included in some areas. The report provides quantitative data of the last three years to illustrate recent YoY trends.

## Reporting Cycle

Annual - previous edition published in June 2024.

## Third-Party Assurance

Anjin Deloitte, an independent assurance provider, conducted a thirdparty verification to ensure confidence in the report making process and information disclosed, as per the ISAE3000 verification criteria.

## Related information

-   Samsung Electronics Website

http://www.samsung.com/sec

-   Samsung Electronics Sustainability Website

https://www.samsung.com/global/sustainability/main/

·   Samsung Electronics IR Website

http://www.samsung.com/sec/ir

-   Samsung Newsroom

http://news.samsung.com/kr

http://news.samsung.com/global

## For More Information

·   Samsung Electronics Corporate Sustainability Center

-   Address:   129 Samsung-ro, Yeongtong-gu, Suwon-si,

Gyeonggi-do (16677)

-   Email: sustainability.sec@samsung.com

## Reference

[·   Annual Business Report](https://www.samsung.com/global/ir/reports-disclosures/business-report/)

<!-- image -->

- [  Corporate Governance Report](https://www.samsung.com/global/ir/reports-disclosures/corporate-governance-report/)
- [  Responsible Minerals Report](https://www.samsung.com/global/sustainability/policy-file/AYVhOraaBIcAIx95/Responsible_Minerals_Report_en.pdf)
- [  Global Code of Conduct](https://www.samsung.com/global/ir/governance-csr/global-code-of-conduct/)

<!-- image -->

[· Guidelines on the Global Code of Conduct](https://www.samsung.com/global/sustainability/policy-file/AYVhQ7HaBZsAIx95/26_SAMSUNG_business_conduct_guidelines_2016.pdf)

## Forward-Looking Statement

Certain statements made in our Sustainability Report, including those related to our sustainability targets and strategies, may constitute forward-looking statements under applicable laws. This Report contains forward-looking statements that reflect Samsung's current views with respect to future events and performance. These statements involve risks and uncertainties.

You can identify forward-looking statements by the fact that they do not relate strictly to current or historic facts. Examples of forward-looking statements include information concerning Samsung's outlook and guidance, as well as any other statement that does not directly relate to any historical or current fact. In some cases, you can identify forward-looking statements by terminology such as "may," "will," "could," "should," "forecasts," "expects," "intends," "plans," 'aims to', 'goals,' 'trying to,' "anticipates," "projects," "outlook," "believes," "estimates," "predicts," "potential," "continue," "preliminary," 'strategy,' or the negative of these terms or other comparable terminology.

Although we believe that the expectations reflected in the forward-looking statements are reasonable, we can give you no assurance these expectations will prove to have been correct. These statements are being provided for the purpose of assisting readers in understanding our approach to key sustainability topics, strategies and initiatives, and in obtaining a better understanding of our anticipated operating environment. Readers are cautioned that such information may not be appropriate for other purposes.

Forward-looking statements in this document may include, but are not limited to: statements regarding Samsung's greenhouse gas emissions, energy consumption, water consumption, and other environmental targets, external sustainability commitments and operational strategies. Many risks, contingencies and uncertainties could cause actual results to differ materially from Samsung's forward-looking statements.

Such factors may include, but is not limited to, the following: statements related to the expected effects on our business of geopolitical events, global economic conditions, fluctuations in cost and availability of raw materials, our ability to maintain favorable supplier relationships and arrangements, economic and political conditions in the markets we serve, foreign exchange rates and fluctuations in such rates, fluctuations in tax rates, the impact of future legislation, the impact of environmental regulations, unexpected business disruptions, the effectiveness of our internal control over financial reporting, the results of governmental investigations, and the unpredictability of existing and possible future litigation. Unlisted factors may present significant additional obstacles to the realization of forward-looking statements.

This Report also includes forward-looking statements regarding our sustainability; safety and health; cybersecurity; culture; diversity, equity, and inclusion; community engagement; and related goals, commitments and strategies.

Our actual future results, including the achievement of our targets, goals or commitments, could differ materially from our projected results as the result of changes in circumstances, assumptions not being realized, or other risks, uncertainties and factors.

Although Samsung believes that the forward-looking statements in this Report is based on information, assumptions, and beliefs that are current and reasonable, such forward-looking statements - and the underlying information, assumptions, and beliefs - are necessarily subject to a number of factors, risks, and uncertainties, which could cause actual results to differ materially from management's expectations and plans as set forth in such forward-looking statements. Any forward-looking statement speaks only as of the date on which such statement is made, and Samsung undertakes no obligation to update any forward looking statement, whether as a result of new information, future events or otherwise.

86